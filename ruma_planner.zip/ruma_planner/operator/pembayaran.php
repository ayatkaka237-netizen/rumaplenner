<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isOperator()) {
    $home = match(getRole()) {
        'admin'   => BASE_URL.'admin/dashboard.php',
        'pemilik' => BASE_URL.'pemilik/dashboard.php',
        default   => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}

// Konfirmasi pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $id     = (int)($_POST['id'] ?? 0);
    $jenis  = $_POST['jenis'] ?? '';
    if ($id && in_array($jenis, ['dp','pelunasan'])) {
        if ($jenis === 'dp') {
            $pdo->prepare("UPDATE booking SET status='Confirmed', catatan_admin='DP dikonfirmasi oleh operator.', updated_at=CURRENT_TIMESTAMP WHERE id=?")
                ->execute([$id]);
            setFlash('success', 'DP berhasil dikonfirmasi. Status booking menjadi Confirmed.');
        } else {
            $pdo->prepare("UPDATE booking SET status='Completed', status_pelunasan='Verified', catatan_admin='Pelunasan dikonfirmasi. Pembayaran LUNAS.', updated_at=CURRENT_TIMESTAMP WHERE id=?")
                ->execute([$id]);
            setFlash('success', 'Pelunasan dikonfirmasi. Booking selesai (Completed).');
        }
    }
    header('Location: '.BASE_URL.'operator/pembayaran.php');
    exit();
}

// Booking yang ada bukti pembayaran & belum dikonfirmasi
$needDP = $pdo->query("SELECT b.*, u.nama as nama_client, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id WHERE b.bukti_pembayaran IS NOT NULL AND b.status='Pending' ORDER BY b.created_at DESC")->fetchAll();
$needLunas = $pdo->query("SELECT b.*, u.nama as nama_client, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id WHERE b.bukti_pelunasan IS NOT NULL AND b.status='Confirmed' ORDER BY b.created_at DESC")->fetchAll();
$verified = $pdo->query("SELECT b.*, u.nama as nama_client, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id WHERE b.status IN ('Completed','Confirmed') ORDER BY b.updated_at DESC LIMIT 10")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Konfirmasi Pembayaran — Operator</title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <h3 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:4px;">Konfirmasi Pembayaran</h3>
    <p class="text-muted mb-4">Verifikasi bukti transfer DP dan pelunasan dari client</p>
    <?php showFlash(); ?>

    <!-- Tab -->
    <ul class="nav nav-tabs mb-4" id="payTab">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabDP">
            Menunggu Konfirmasi DP <span class="badge bg-warning text-dark ms-1"><?= count($needDP) ?></span>
        </button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabLunas">
            Menunggu Konfirmasi Lunas <span class="badge bg-primary ms-1"><?= count($needLunas) ?></span>
        </button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabDone">
            Sudah Diverifikasi
        </button></li>
    </ul>

    <div class="tab-content">
    <!-- TAB DP -->
    <div class="tab-pane fade show active" id="tabDP">
        <?php if (empty($needDP)): ?>
        <div class="text-center py-5 text-muted"><i class="bi bi-check-circle" style="font-size:3rem;opacity:.3;"></i><p class="mt-3">Tidak ada bukti DP yang perlu dikonfirmasi</p></div>
        <?php else: ?>
        <div class="row g-3">
        <?php foreach ($needDP as $b): ?>
        <div class="col-md-6">
            <div class="bg-white rounded-xl p-4 shadow-sm">
                <div class="d-flex justify-content-between mb-2">
                    <div><div class="fw-bold"><?= htmlspecialchars($b['nama_client']) ?></div>
                    <small class="text-muted"><?= htmlspecialchars($b['kode_booking']) ?></small></div>
                    <span class="badge bg-warning text-dark">Menunggu</span>
                </div>
                <div class="small text-muted mb-1"><?= htmlspecialchars($b['nama_paket']) ?> · <?= date('d M Y', strtotime($b['tanggal_acara'])) ?></div>
                <div style="font-family:var(--font-display);color:var(--maroon);font-size:1.1rem;font-weight:700;margin-bottom:12px;"><?= formatRupiah($b['total_harga'] * 0.3) ?> <small style="font-size:0.7rem;color:#aaa;">DP 30%</small></div>
                <img src="<?= UPLOAD_URL_BAYAR.htmlspecialchars($b['bukti_pembayaran']) ?>" class="img-thumbnail w-100 mb-3" style="max-height:160px;object-fit:cover;">
                <form method="POST" class="d-flex gap-2">
                    <?= csrfField() ?>
                    <input type="hidden" name="id" value="<?= $b['id'] ?>">
                    <input type="hidden" name="jenis" value="dp">
                    <button type="submit" class="btn btn-success flex-grow-1 btn-sm"><i class="bi bi-check-circle me-1"></i>Konfirmasi DP</button>
                    <a href="<?= BASE_URL ?>operator/booking-detail.php?id=<?= $b['id'] ?>" class="btn btn-outline-maroon btn-sm">Detail</a>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- TAB LUNAS -->
    <div class="tab-pane fade" id="tabLunas">
        <?php if (empty($needLunas)): ?>
        <div class="text-center py-5 text-muted"><i class="bi bi-check-circle" style="font-size:3rem;opacity:.3;"></i><p class="mt-3">Tidak ada pelunasan yang perlu dikonfirmasi</p></div>
        <?php else: ?>
        <div class="row g-3">
        <?php foreach ($needLunas as $b): ?>
        <div class="col-md-6">
            <div class="bg-white rounded-xl p-4 shadow-sm">
                <div class="d-flex justify-content-between mb-2">
                    <div><div class="fw-bold"><?= htmlspecialchars($b['nama_client']) ?></div>
                    <small class="text-muted"><?= htmlspecialchars($b['kode_booking']) ?></small></div>
                    <span class="badge bg-primary">Pelunasan</span>
                </div>
                <div class="small text-muted mb-1"><?= htmlspecialchars($b['nama_paket']) ?> · <?= date('d M Y', strtotime($b['tanggal_acara'])) ?></div>
                <div style="font-family:var(--font-display);color:var(--maroon);font-size:1.1rem;font-weight:700;margin-bottom:12px;"><?= formatRupiah($b['total_harga'] * 0.7) ?> <small style="font-size:0.7rem;color:#aaa;">Pelunasan 70%</small></div>
                <img src="<?= UPLOAD_URL_BAYAR.htmlspecialchars($b['bukti_pelunasan']) ?>" class="img-thumbnail w-100 mb-3" style="max-height:160px;object-fit:cover;">
                <form method="POST" class="d-flex gap-2">
                    <?= csrfField() ?>
                    <input type="hidden" name="id" value="<?= $b['id'] ?>">
                    <input type="hidden" name="jenis" value="pelunasan">
                    <button type="submit" class="btn btn-success flex-grow-1 btn-sm"><i class="bi bi-check-circle me-1"></i>Konfirmasi Lunas</button>
                    <a href="<?= BASE_URL ?>operator/booking-detail.php?id=<?= $b['id'] ?>" class="btn btn-outline-maroon btn-sm">Detail</a>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- TAB DONE -->
    <div class="tab-pane fade" id="tabDone">
        <div class="bg-white rounded-xl shadow-sm">
        <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead style="background:var(--maroon-pale);"><tr><th>Kode</th><th>Client</th><th>Paket</th><th>Total</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($verified as $v): ?>
            <tr>
                <td><code><?= htmlspecialchars($v['kode_booking']) ?></code></td>
                <td><?= htmlspecialchars($v['nama_client']) ?></td>
                <td><?= htmlspecialchars($v['nama_paket']) ?></td>
                <td style="color:var(--maroon);font-weight:600;"><?= formatRupiah($v['total_harga']) ?></td>
                <td><span class="badge bg-<?= $v['status']==='Completed'?'success':'primary' ?>"><?= $v['status'] ?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        </div>
    </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
