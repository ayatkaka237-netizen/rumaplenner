<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isOperator()) {
    $home = match(getRole()) {
        'admin'   => BASE_URL.'admin/dashboard.php',
        'pemilik' => BASE_URL.'pemilik/dashboard.php',
        default   => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: '.BASE_URL.'operator/booking.php'); exit(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $status = sanitize($pdo, $_POST['status'] ?? '');
    $catatan = sanitize($pdo, $_POST['catatan_admin'] ?? '');
    $allowed = ['Pending','Confirmed','Completed','Cancelled'];
    if (in_array($status, $allowed)) {
        $pdo->prepare("UPDATE booking SET status=?, catatan_admin=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
            ->execute([$status, $catatan, $id]);
        setFlash('success', 'Status booking berhasil diupdate.');
    }
    header('Location: '.BASE_URL.'operator/booking-detail.php?id='.$id);
    exit();
}

$stmt = $pdo->prepare("SELECT b.*, u.nama as nama_client, u.email, u.no_hp, p.nama_paket, p.kategori, p.harga FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id WHERE b.id=?");
$stmt->execute([$id]);
$b = $stmt->fetch();
if (!$b) { header('Location: '.BASE_URL.'operator/booking.php'); exit(); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Detail Booking — Operator <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <a href="<?= BASE_URL ?>operator/booking.php" class="btn btn-sm btn-outline-maroon mb-2"><i class="bi bi-arrow-left me-1"></i>Kembali</a>
            <h3 style="font-family:var(--font-display);color:var(--maroon);margin:0;">Detail Booking</h3>
        </div>
        <code style="font-size:1rem;"><?= htmlspecialchars($b['kode_booking']) ?></code>
    </div>
    <?php showFlash(); ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <!-- Info Booking -->
            <div class="bg-white rounded-xl p-4 shadow-sm mb-4">
                <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-info-circle me-2"></i>Info Booking</h5>
                <div class="row g-3">
                    <div class="col-md-6"><label class="text-muted small">Nama Mempelai Pria</label><div class="fw-semibold"><?= htmlspecialchars($b['nama_mempelai_pria']) ?></div></div>
                    <div class="col-md-6"><label class="text-muted small">Nama Mempelai Wanita</label><div class="fw-semibold"><?= htmlspecialchars($b['nama_mempelai_wanita']) ?></div></div>
                    <div class="col-md-6"><label class="text-muted small">Paket</label><div class="fw-semibold"><?= htmlspecialchars($b['nama_paket']) ?></div></div>
                    <div class="col-md-6"><label class="text-muted small">Tanggal Acara</label><div class="fw-semibold"><?= date('d M Y', strtotime($b['tanggal_acara'])) ?></div></div>
                    <div class="col-md-6"><label class="text-muted small">Jumlah Tamu</label><div class="fw-semibold"><?= $b['jumlah_tamu'] ?> orang</div></div>
                    <div class="col-md-6"><label class="text-muted small">Total Harga</label><div class="fw-semibold" style="color:var(--maroon);"><?= formatRupiah($b['total_harga']) ?></div></div>
                    <div class="col-12"><label class="text-muted small">Lokasi</label><div class="fw-semibold"><?= htmlspecialchars($b['lokasi']) ?></div></div>
                    <?php if ($b['catatan']): ?><div class="col-12"><label class="text-muted small">Catatan</label><div><?= nl2br(htmlspecialchars($b['catatan'])) ?></div></div><?php endif; ?>
                </div>
            </div>
            <!-- Bukti Pembayaran -->
            <div class="bg-white rounded-xl p-4 shadow-sm mb-4">
                <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-credit-card me-2"></i>Bukti Pembayaran</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="fw-semibold mb-2 small" style="color:var(--maroon);">Bukti DP (30%) — <?= formatRupiah($b['total_harga']*0.3) ?></div>
                        <?php if ($b['bukti_pembayaran']): ?>
                        <img src="<?= UPLOAD_URL_BAYAR.htmlspecialchars($b['bukti_pembayaran']) ?>" class="img-thumbnail w-100" style="max-height:180px;object-fit:cover;" alt="Bukti DP">
                        <?php else: ?><div class="text-center p-3 rounded" style="background:#fff3cd;font-size:0.82rem;color:#856404;">Belum upload bukti DP</div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <div class="fw-semibold mb-2 small" style="color:var(--maroon);">Bukti Pelunasan (70%) — <?= formatRupiah($b['total_harga']*0.7) ?></div>
                        <?php if (!empty($b['bukti_pelunasan'])): ?>
                        <img src="<?= UPLOAD_URL_BAYAR.htmlspecialchars($b['bukti_pelunasan']) ?>" class="img-thumbnail w-100" style="max-height:180px;object-fit:cover;" alt="Bukti Lunas">
                        <?php else: ?><div class="text-center p-3 rounded" style="background:var(--maroon-pale);font-size:0.82rem;color:#aaa;">Belum upload pelunasan</div><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Update Status -->
        <div class="col-lg-4">
            <div class="bg-white rounded-xl p-4 shadow-sm">
                <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-arrow-repeat me-2"></i>Update Status</h5>
                <div class="mb-3 text-center">
                    <?php $badges=['Pending'=>'warning','Confirmed'=>'primary','Completed'=>'success','Cancelled'=>'danger']; $cl=$badges[$b['status']]??'secondary'; ?>
                    <span class="badge bg-<?= $cl ?>" style="font-size:1rem;padding:10px 20px;"><?= htmlspecialchars($b['status']) ?></span>
                </div>
                <form method="POST">
                    <?= csrfField() ?>
                    <div class="mb-3">
                        <label class="form-label">Ubah Status</label>
                        <select name="status" class="form-select">
                            <?php foreach (['Pending','Confirmed','Completed','Cancelled'] as $s): ?>
                            <option value="<?= $s ?>" <?= $b['status']===$s?'selected':'' ?>><?= $s ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Catatan untuk Client</label>
                        <textarea name="catatan_admin" class="form-control" rows="3"><?= htmlspecialchars($b['catatan_admin'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-maroon w-100"><i class="bi bi-check-circle me-1"></i>Simpan</button>
                </form>
                <hr>
                <div class="mb-2">
                    <div class="text-muted small mb-1">Info Client</div>
                    <div class="fw-semibold"><?= htmlspecialchars($b['nama_client']) ?></div>
                    <div class="small text-muted"><?= htmlspecialchars($b['email']) ?></div>
                    <div class="small text-muted"><?= htmlspecialchars($b['no_hp'] ?? '-') ?></div>
                </div>
                <a href="https://wa.me/<?= preg_replace('/[^0-9]/','', $b['no_hp'] ?? '') ?>?text=<?= urlencode('Halo '.$b['nama_client'].', kami dari Ruma Planner ingin mengkonfirmasi booking Anda dengan kode '.$b['kode_booking'].'.') ?>" target="_blank" class="btn btn-sm w-100" style="background:#25D366;color:#fff;">
                    <i class="bi bi-whatsapp me-1"></i>Chat via WhatsApp
                </a>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
