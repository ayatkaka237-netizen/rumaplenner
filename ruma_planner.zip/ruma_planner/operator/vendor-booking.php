<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isOperator()) {
    $home = match(getRole()) {
        'admin'   => BASE_URL.'admin/dashboard.php',
        'pemilik' => BASE_URL.'pemilik/dashboard.php',
        default   => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $id = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($id && in_array($action, ['confirm','cancel'])) {
        $status = $action === 'confirm' ? 'confirmed' : 'cancelled';
        $pdo->prepare("UPDATE vendor_booking SET status=? WHERE id=?")->execute([$status, $id]);
        setFlash('success', 'Status booking vendor diupdate.');
    }
    header('Location: '.BASE_URL.'operator/vendor-booking.php');
    exit();
}

$list = $pdo->query("SELECT vb.*, v.nama AS vendor_nama, vk.nama AS kategori, u.nama AS nama_user, u.no_hp FROM vendor_booking vb JOIN vendor v ON vb.id_vendor=v.id JOIN vendor_kategori vk ON v.id_kategori=vk.id JOIN users u ON vb.id_user=u.id ORDER BY vb.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Booking Vendor — Operator</title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <h3 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:4px;">Booking Vendor</h3>
    <p class="text-muted mb-4">Konfirmasi permintaan booking vendor dari client</p>
    <?php showFlash(); ?>
    <div class="bg-white rounded-xl p-4 shadow-sm">
    <div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead style="background:var(--maroon-pale);"><tr><th>Vendor</th><th>Kategori</th><th>Client</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($list as $vb): ?>
        <tr>
            <td class="fw-semibold"><?= htmlspecialchars($vb['vendor_nama']) ?></td>
            <td><span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= htmlspecialchars($vb['kategori']) ?></span></td>
            <td><?= htmlspecialchars($vb['nama_user']) ?><br><small class="text-muted"><?= htmlspecialchars($vb['no_hp'] ?? '') ?></small></td>
            <td><?= date('d M Y', strtotime($vb['tanggal'])) ?></td>
            <td><?php $cls=['pending'=>'warning','confirmed'=>'success','cancelled'=>'danger']; ?>
                <span class="badge bg-<?= $cls[$vb['status']] ?? 'secondary' ?>"><?= ucfirst($vb['status']) ?></span>
            </td>
            <td>
                <?php if ($vb['status'] === 'pending'): ?>
                <form method="POST" class="d-inline">
                    <?= csrfField() ?><input type="hidden" name="id" value="<?= $vb['id'] ?>">
                    <input type="hidden" name="action" value="confirm">
                    <button type="submit" class="btn btn-success btn-sm"><i class="bi bi-check"></i></button>
                </form>
                <form method="POST" class="d-inline">
                    <?= csrfField() ?><input type="hidden" name="id" value="<?= $vb['id'] ?>">
                    <input type="hidden" name="action" value="cancel">
                    <button type="submit" class="btn btn-danger btn-sm"><i class="bi bi-x"></i></button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
