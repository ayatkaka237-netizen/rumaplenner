<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isOperator()) {
    $home = match(getRole()) {
        'admin'   => BASE_URL.'admin/dashboard.php',
        'pemilik' => BASE_URL.'pemilik/dashboard.php',
        default   => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}

$total_booking  = $pdo->query("SELECT COUNT(*) FROM booking")->fetchColumn();
$pending        = $pdo->query("SELECT COUNT(*) FROM booking WHERE status='Pending'")->fetchColumn();
$confirmed      = $pdo->query("SELECT COUNT(*) FROM booking WHERE status='Confirmed'")->fetchColumn();
$pending_bayar  = $pdo->query("SELECT COUNT(*) FROM booking WHERE bukti_pembayaran IS NOT NULL AND status='Pending'")->fetchColumn();
$pending_lunas  = $pdo->query("SELECT COUNT(*) FROM booking WHERE bukti_pelunasan IS NOT NULL AND status='Confirmed'")->fetchColumn();
$recent = $pdo->query("SELECT b.*, u.nama as nama_client, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id ORDER BY b.created_at DESC LIMIT 8")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard Operator — <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 style="font-family:var(--font-display);color:var(--maroon);margin:0;">Dashboard Operator</h3>
            <p class="text-muted mb-0">Selamat datang, <?= htmlspecialchars($_SESSION['nama']) ?></p>
        </div>
        <span class="badge" style="background:var(--maroon);font-size:0.85rem;padding:8px 16px;">
            <i class="bi bi-person-badge me-1"></i>Operator
        </span>
    </div>
    <?php showFlash(); ?>

    <!-- Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-calendar-check" style="font-size:2rem;color:var(--maroon);"></i>
                <div style="font-size:2rem;font-family:var(--font-display);color:var(--maroon);font-weight:700;"><?= $total_booking ?></div>
                <div class="text-muted small">Total Booking</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-clock" style="font-size:2rem;color:#f59e0b;"></i>
                <div style="font-size:2rem;font-family:var(--font-display);color:#f59e0b;font-weight:700;"><?= $pending ?></div>
                <div class="text-muted small">Booking Pending</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-upload" style="font-size:2rem;color:#3b82f6;"></i>
                <div style="font-size:2rem;font-family:var(--font-display);color:#3b82f6;font-weight:700;"><?= $pending_bayar ?></div>
                <div class="text-muted small">Menunggu Verif. DP</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-cash-coin" style="font-size:2rem;color:#10b981;"></i>
                <div style="font-size:2rem;font-family:var(--font-display);color:#10b981;font-weight:700;"><?= $pending_lunas ?></div>
                <div class="text-muted small">Menunggu Verif. Lunas</div>
            </div>
        </div>
    </div>

    <!-- Notif penting -->
    <?php if ($pending_bayar > 0 || $pending_lunas > 0): ?>
    <div class="alert alert-warning mb-4">
        <i class="bi bi-exclamation-triangle me-2"></i>
        Ada <strong><?= $pending_bayar ?></strong> bukti DP dan <strong><?= $pending_lunas ?></strong> bukti pelunasan yang perlu diverifikasi.
        <a href="<?= BASE_URL ?>operator/pembayaran.php" class="alert-link ms-2">Verifikasi Sekarang →</a>
    </div>
    <?php endif; ?>

    <!-- Recent Booking -->
    <div class="bg-white rounded-xl p-4 shadow-sm">
        <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;">Booking Terbaru</h5>
        <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead style="background:var(--maroon-pale);">
                <tr><th>Kode</th><th>Client</th><th>Paket</th><th>Tanggal Acara</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
            <?php foreach ($recent as $r): ?>
            <tr>
                <td><code><?= htmlspecialchars($r['kode_booking']) ?></code></td>
                <td><?= htmlspecialchars($r['nama_client']) ?></td>
                <td><?= htmlspecialchars($r['nama_paket']) ?></td>
                <td><?= date('d M Y', strtotime($r['tanggal_acara'])) ?></td>
                <td><?php
                    $badges = ['Pending'=>'warning','Confirmed'=>'primary','Completed'=>'success','Cancelled'=>'danger'];
                    $cl = $badges[$r['status']] ?? 'secondary';
                    echo '<span class="badge bg-'.$cl.'">'.htmlspecialchars($r['status']).'</span>';
                ?></td>
                <td><a href="<?= BASE_URL ?>operator/booking-detail.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-maroon">Detail</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
