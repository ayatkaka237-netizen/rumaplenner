<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isOperator()) {
    $home = match(getRole()) {
        'admin'   => BASE_URL.'admin/dashboard.php',
        'pemilik' => BASE_URL.'pemilik/dashboard.php',
        default   => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}

$statuses = ['Pending','Confirmed','Completed','Cancelled'];
$filter_status = in_array($_GET['status'] ?? '', $statuses) ? $_GET['status'] : '';

if ($filter_status) {
    $stmtBook = $pdo->prepare("SELECT b.*, u.nama as nama_client, u.no_hp, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id WHERE b.status=? ORDER BY b.created_at DESC");
    $stmtBook->execute([$filter_status]);
} else {
    $stmtBook = $pdo->query("SELECT b.*, u.nama as nama_client, u.no_hp, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id ORDER BY b.created_at DESC");
}
$bookings = $stmtBook->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Booking — Operator <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <h3 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;">Data Booking</h3>
    <?php showFlash(); ?>
    <div class="d-flex gap-2 flex-wrap mb-4">
        <a href="booking.php" class="btn btn-sm <?= !$filter_status?'btn-maroon':'btn-outline-secondary' ?>">Semua</a>
        <?php foreach ($statuses as $s): ?>
        <a href="booking.php?status=<?= $s ?>" class="btn btn-sm <?= $filter_status===$s?'btn-maroon':'btn-outline-secondary' ?>"><?= $s ?></a>
        <?php endforeach; ?>
    </div>
    <div class="bg-white rounded-xl p-4 shadow-sm">
    <div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead style="background:var(--maroon-pale);">
            <tr><th>Kode</th><th>Client</th><th>Mempelai</th><th>Paket</th><th>Tgl Acara</th><th>Total</th><th>Bukti DP</th><th>Status</th><th>Aksi</th></tr>
        </thead>
        <tbody>
        <?php if (empty($bookings)): ?>
        <tr><td colspan="9" class="text-center text-muted py-4">Tidak ada data</td></tr>
        <?php else: ?>
        <?php foreach ($bookings as $b): ?>
        <tr>
            <td><strong style="color:var(--maroon);font-size:0.78rem;"><?= htmlspecialchars($b['kode_booking']) ?></strong></td>
            <td><div style="font-size:0.88rem;"><?= htmlspecialchars($b['nama_client']) ?></div>
                <div style="font-size:0.75rem;color:#999;"><?= htmlspecialchars($b['no_hp'] ?? '') ?></div></td>
            <td style="font-size:0.83rem;"><?= htmlspecialchars($b['nama_mempelai_pria']) ?> &<br><?= htmlspecialchars($b['nama_mempelai_wanita']) ?></td>
            <td><span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= htmlspecialchars($b['nama_paket']) ?></span></td>
            <td style="font-size:0.83rem;"><?= date('d M Y', strtotime($b['tanggal_acara'])) ?></td>
            <td style="font-size:0.83rem;font-weight:600;color:var(--maroon);"><?= formatRupiah($b['total_harga']) ?></td>
            <td>
                <?php if ($b['bukti_pembayaran']): ?>
                <a href="<?= UPLOAD_URL_BAYAR.htmlspecialchars($b['bukti_pembayaran']) ?>" target="_blank" class="btn btn-sm btn-outline-success"><i class="bi bi-image me-1"></i>Lihat</a>
                <?php else: ?><span class="badge bg-secondary">Belum</span><?php endif; ?>
            </td>
            <td><?php $cls=['Pending'=>'warning','Confirmed'=>'primary','Completed'=>'success','Cancelled'=>'danger']; ?>
                <span class="badge bg-<?= $cls[$b['status']]??'secondary' ?>"><?= $b['status'] ?></span></td>
            <td><a href="booking-detail.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-maroon"><i class="bi bi-eye me-1"></i>Detail</a></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
