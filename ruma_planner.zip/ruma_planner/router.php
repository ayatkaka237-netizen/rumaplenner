<?php
/**
 * Router untuk PHP Built-in Web Server
 * Jalankan dengan: php -S localhost:8080 router.php
 */

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Sajikan file statis langsung (CSS, JS, gambar, dll)
if ($uri !== '/' && file_exists(__DIR__ . $uri)) {
    $ext = strtolower(pathinfo($uri, PATHINFO_EXTENSION));
    $mimes = [
        'css'  => 'text/css',
        'js'   => 'application/javascript',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'gif'  => 'image/gif',
        'webp' => 'image/webp',
        'ico'  => 'image/x-icon',
        'svg'  => 'image/svg+xml',
        'woff' => 'font/woff',
        'woff2'=> 'font/woff2',
        'ttf'  => 'font/ttf',
    ];
    if (isset($mimes[$ext])) {
        header('Content-Type: ' . $mimes[$ext]);
        readfile(__DIR__ . $uri);
        return true;
    }
    return false; // PHP menangani file .php
}

// Beranda
if ($uri === '/') {
    require __DIR__ . '/index.php';
    return true;
}

// Jika file .php ada langsung
if (file_exists(__DIR__ . $uri . '.php')) {
    require __DIR__ . $uri . '.php';
    return true;
}

// 404 - halaman tidak ditemukan
http_response_code(404);
require __DIR__ . '/404.php';
return true;
