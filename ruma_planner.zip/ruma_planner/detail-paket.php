<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: ' . BASE_URL . 'paket.php'); exit(); }

$stmt = $pdo->prepare("SELECT * FROM paket WHERE id=? AND is_active=1");
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { header('Location: ' . BASE_URL . 'paket.php'); exit(); }

$fasilitas = explode('|', $p['fasilitas']);

// Map keyword fasilitas → slug vendor
// Hanya fasilitas yang BENAR-BENAR punya vendor yang boleh di-map
$fasilitasVendorMap = [
    // MUA
    'MUA'           => 'mua',
    'Make Up'       => 'mua',
    'Makeup'        => 'mua',
    'Rias'          => 'mua',
    // Photographer
    'Foto'          => 'photographer',
    'Fotografer'    => 'photographer',
    'Photography'   => 'photographer',
    // Videografer
    'Video'         => 'videografer',
    'Videografer'   => 'videografer',
    'Cinematic'     => 'videografer',
    // MC
    'MC'            => 'mc',
    // Catering
    'Catering'      => 'catering',
    'Katering'      => 'catering',
    // Dekorasi / Pelaminan / Bunga (semua ini vendor Dekorasi)
    'Dekorasi'      => 'dekorasi',
    'Pelaminan'     => 'dekorasi',
    'Bunga'         => 'dekorasi',
    // Musik
    'Musik'         => 'musik',
    'Band'          => 'musik',
    'Live Music'    => 'musik',
    'Hiburan'       => 'musik',
    // Gedung
    'Gedung'        => 'gedung',
    'Ballroom'      => 'gedung',
    'Venue'         => 'gedung',
];

// Fasilitas yang TIDAK punya vendor (murni layanan WO sendiri)
$fasilitasTanpaVendor = [
    'Sound System','Lighting','Koordinator','Undangan','Konsultasi',
    'Dokumentasi Anggaran','Wedding Planner','Rundown','Timeline',
    'Koordinator Hari H','Tim Lapangan',
];

function getFasilitasSlug($fasilitasName, $map, $exclude) {
    // Cek dulu apakah ini fasilitas yang dikecualikan
    foreach ($exclude as $ex) {
        if (stripos($fasilitasName, $ex) !== false) return null;
    }
    foreach ($map as $keyword => $slug) {
        if (stripos($fasilitasName, $keyword) !== false) return $slug;
    }
    return null;
}

// Semua vendor dikelompokkan per slug
$allVendors = $pdo->query("
    SELECT v.*, vk.nama AS nama_kategori, vk.slug AS kategori_slug, vk.icon AS kategori_icon
    FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id
    WHERE v.is_active=1 ORDER BY v.rating DESC
")->fetchAll();

$vendorBySlug = [];
foreach ($allVendors as $vd) {
    $vendorBySlug[$vd['kategori_slug']][] = $vd;
}

// Booked dates paket ini (dari booking tabel)
$bookedPaket = $pdo->prepare("SELECT tanggal_acara, status FROM booking WHERE id_paket=? AND status NOT IN ('cancelled')");
$bookedPaket->execute([$id]);
$bookedDates = [];
foreach ($bookedPaket->fetchAll() as $b) {
    $bookedDates[$b['tanggal_acara']] = $b['status'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($p['nama_paket']) ?> — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <style>
    /* ── Fasilitas Item ── */
    .fasilitas-item {
        display:flex; align-items:flex-start; gap:10px;
        padding:14px 16px; border-radius:var(--radius);
        background:var(--maroon-pale);
        border:2px solid transparent;
        transition:var(--transition);
        position:relative;
        user-select:none;
    }
    .fasilitas-item.has-vendor {
        cursor:pointer;
        border-color:rgba(105,27,27,0.15);
    }
    .fasilitas-item.has-vendor:hover {
        background:#fde8e8;
        border-color:var(--maroon);
        box-shadow:var(--shadow-sm);
    }
    .fasilitas-item.vendor-selected {
        border-color:var(--maroon) !important;
        background:#fde8e8;
    }
    .vendor-hint-tag {
        position:absolute; top:8px; right:10px;
        font-size:0.67rem; color:var(--maroon);
        font-weight:700; display:flex; align-items:center; gap:3px;
        background:rgba(105,27,27,0.08); padding:2px 8px; border-radius:50px;
    }
    .selected-vendor-label {
        font-size:0.72rem; color:var(--maroon); font-weight:600;
        margin-top:3px; display:none;
    }
    .fasilitas-item.vendor-selected .selected-vendor-label { display:block; }

    /* ── Kalender ── */
    .calendar-box {
        background:#fff; border-radius:var(--radius-lg);
        border:1px solid rgba(105,27,27,0.1); overflow:hidden;
    }
    .cal-nav {
        display:flex; align-items:center; justify-content:space-between;
        padding:14px 18px; background:linear-gradient(135deg,var(--maroon-dark),var(--maroon)); color:#fff;
    }
    .cal-nav h6 { margin:0; font-family:var(--font-display); font-size:1.05rem; }
    .cal-nav button {
        background:rgba(255,255,255,0.18); border:none; color:#fff;
        width:30px; height:30px; border-radius:50%; cursor:pointer; font-size:0.9rem;
        transition:var(--transition);
    }
    .cal-nav button:hover { background:rgba(255,255,255,0.35); }
    .cal-grid {
        display:grid; grid-template-columns:repeat(7,1fr);
        gap:3px; padding:12px;
    }
    .cal-day-name {
        text-align:center; font-size:0.65rem; font-weight:700;
        color:#aaa; padding:4px 0; text-transform:uppercase;
    }
    .cal-day {
        text-align:center; padding:8px 2px; border-radius:8px;
        font-size:0.78rem; cursor:pointer; transition:all .15s;
        border:2px solid transparent; line-height:1;
    }
    .cal-day.avail   { background:#d4edda; color:#155724; border-color:#b8ddc8; }
    .cal-day.avail:hover { background:#28a745; color:#fff; border-color:#28a745; }
    .cal-day.full    { background:#f8d7da; color:#721c24; border-color:#f1b0b7; cursor:not-allowed; }
    .cal-day.pending { background:#fff3cd; color:#856404; border-color:#ffeaa7; cursor:not-allowed; }
    .cal-day.past    { opacity:.3; cursor:not-allowed; }
    .cal-day.empty   { opacity:0; pointer-events:none; }
    .cal-day.selected { background:var(--maroon) !important; color:#fff !important; border-color:var(--maroon) !important; font-weight:700; }
    .cal-day.today   { box-shadow:0 0 0 2px var(--gold); font-weight:700; }
    .cal-legend { display:flex; gap:14px; flex-wrap:wrap; padding:0 12px 12px; }
    .cal-legend span { font-size:0.72rem; display:flex; align-items:center; gap:5px; }
    .dot { width:11px; height:11px; border-radius:3px; display:inline-block; }

    /* ── Vendor Picker Modal ── */
    .vendor-picker-modal .modal-dialog { max-width:700px; }
    .vendor-picker-modal .modal-header {
        background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));
        color:#fff; border:none; padding:18px 24px;
    }
    .vendor-picker-modal .modal-title { font-family:var(--font-display); font-size:1.35rem; }
    .vendor-picker-modal .btn-close { filter:invert(1); opacity:.8; }
    .vp-card {
        border:2px solid rgba(105,27,27,0.1); border-radius:var(--radius);
        padding:14px; cursor:pointer; transition:var(--transition); background:#fff; position:relative;
    }
    .vp-card:hover { border-color:var(--maroon); box-shadow:var(--shadow-sm); transform:translateY(-2px); }
    .vp-card.active { border-color:var(--maroon); background:var(--maroon-pale); }
    .vp-check {
        position:absolute; top:10px; right:10px;
        width:22px; height:22px; border-radius:50%;
        background:var(--maroon); color:#fff;
        display:none; align-items:center; justify-content:center; font-size:0.75rem;
    }
    .vp-card.active .vp-check { display:flex; }
    .vp-icon {
        width:52px; height:52px; border-radius:10px; flex-shrink:0;
        background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));
        display:flex; align-items:center; justify-content:center;
    }
    .vp-icon i { font-size:1.3rem; color:rgba(255,255,255,0.55); }

    /* ── Summary bar ── */
    .summary-bar {
        background:#fff; border:2px solid var(--maroon-pale);
        border-radius:var(--radius-lg); padding:18px 20px; margin-top:20px;
    }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <nav aria-label="breadcrumb" class="mb-3">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Beranda</a></li>
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>paket.php">Paket</a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($p['nama_paket']) ?></li>
            </ol>
        </nav>
        <h1><?= htmlspecialchars($p['nama_paket']) ?></h1>
    </div>
</div>

<section class="section-padding">
<div class="container">
<div class="row g-5">

    <!-- ══ LEFT PANEL ══════════════════════════════════ -->
    <div class="col-lg-5">

        <!-- Foto -->
        <div class="paket-card-img rounded-xl" style="height:300px;">
            <?php if ($p['foto'] && file_exists(UPLOAD_PAKET . $p['foto'])): ?>
                <img src="<?= UPLOAD_URL_PAKET . htmlspecialchars($p['foto']) ?>" alt="<?= htmlspecialchars($p['nama_paket']) ?>" style="border-radius:var(--radius-lg);">
            <?php else: ?>
                <div class="paket-card-img-placeholder" style="border-radius:var(--radius-lg);">
                    <i class="bi bi-house-heart" style="font-size:5rem;color:rgba(255,255,255,0.3);display:block;"></i>
                </div>
            <?php endif; ?>
            <span class="badge-kategori"><?= htmlspecialchars($p['kategori']) ?></span>
        </div>

        <!-- Harga & Stats -->
        <div class="form-card mt-4">
            <div id="displayHarga" class="paket-harga mb-0"><?= formatRupiah($p['harga']) ?></div>
            <div style="font-size:0.8rem;color:#aaa;" id="hargaLabel">Harga dasar paket</div>

            <!-- Vendor addon total -->
            <div id="addonSection" style="display:none;">
                <div id="addonLines" style="font-size:0.8rem;color:#666;margin-top:6px;"></div>
                <hr style="margin:10px 0;">
                <div class="d-flex justify-content-between align-items-center">
                    <strong style="font-size:0.85rem;">Total Estimasi</strong>
                    <strong id="totalEstimasi" style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);"></strong>
                </div>
            </div>

            <hr>
            <div class="row text-center g-0 mb-3">
                <div class="col-6 p-2">
                    <i class="bi bi-people-fill" style="font-size:1.3rem;color:var(--maroon);"></i>
                    <div style="font-size:1.15rem;font-weight:700;color:var(--maroon);"><?= $p['max_tamu'] ?></div>
                    <div style="font-size:0.73rem;color:#999;">Maks. Tamu</div>
                </div>
                <div class="col-6 p-2" style="border-left:1px solid var(--maroon-pale);">
                    <i class="bi bi-star-fill" style="font-size:1.3rem;color:var(--gold);"></i>
                    <div style="font-size:1.15rem;font-weight:700;color:var(--maroon);"><?= count($fasilitas) ?></div>
                    <div style="font-size:0.73rem;color:#999;">Fasilitas</div>
                </div>
            </div>

            <div class="d-grid gap-2">
                <a href="<?= isLoggedIn() ? BASE_URL . 'client/form-booking.php?paket=' . $p['id'] : BASE_URL . 'login.php' ?>"
                   class="btn btn-maroon">
                    <i class="bi bi-heart me-2"></i>Pesan Paket Ini
                </a>
                <a href="kontak.php" class="btn btn-outline-maroon">
                    <i class="bi bi-chat me-2"></i>Tanya Dahulu
                </a>
            </div>
            <?php if (!isLoggedIn()): ?>
            <p class="text-center mt-2" style="font-size:0.78rem;color:#aaa;">
                <i class="bi bi-lock me-1"></i>Perlu <a href="login.php" style="color:var(--maroon);">login</a> untuk memesan
            </p>
            <?php endif; ?>
        </div>

        <!-- ══ KALENDER KETERSEDIAAN ══ -->
        <div class="form-card mt-4" id="kalender">
            <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:4px;">
                <i class="bi bi-calendar3 me-2"></i>Cek Ketersediaan
            </h5>
            <p style="font-size:0.8rem;color:#aaa;margin-bottom:16px;">
                Pilih tanggal untuk melihat apakah paket ini masih tersedia
            </p>

            <div class="calendar-box">
                <div class="cal-nav">
                    <button id="calPrev" onclick="calPrev()">&#8249;</button>
                    <h6 id="calTitle"></h6>
                    <button id="calNext" onclick="calNext()">&#8250;</button>
                </div>
                <div class="cal-grid" id="calGrid"></div>
                <div class="cal-legend">
                    <span><span class="dot" style="background:#d4edda;border:1px solid #b8ddc8;"></span>Tersedia</span>
                    <span><span class="dot" style="background:#f8d7da;border:1px solid #f1b0b7;"></span>Full Booked</span>
                    <span><span class="dot" style="background:#fff3cd;border:1px solid #ffeaa7;"></span>Pending</span>
                    <span><span class="dot" style="background:var(--maroon);"></span>Dipilih</span>
                </div>
            </div>

            <!-- Result setelah pilih tanggal -->
            <div id="calResult" style="display:none;" class="mt-3 p-3 rounded-xl">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div style="font-size:0.75rem;color:#aaa;">Tanggal dipilih</div>
                        <div style="font-family:var(--font-display);font-size:1.1rem;color:var(--maroon);font-weight:600;" id="calResultDate"></div>
                    </div>
                    <span id="calResultBadge"></span>
                </div>
                <div class="mt-2" id="calResultAction"></div>
            </div>
        </div>

        <!-- DP Info -->
        <div class="mt-4 p-4 rounded-xl" style="background:linear-gradient(135deg,var(--maroon),var(--maroon-light));color:#fff;">
            <h6 style="font-family:var(--font-display);font-size:1.05rem;margin-bottom:12px;">
                <i class="bi bi-credit-card me-2" style="color:var(--gold);"></i>Informasi Pembayaran
            </h6>
            <div class="row">
                <div class="col-6">
                    <div style="font-size:0.75rem;opacity:0.75;">Down Payment (30%)</div>
                    <div style="font-family:var(--font-display);font-size:1rem;color:var(--gold);font-weight:700;"><?= formatRupiah($p['harga'] * 0.3) ?></div>
                </div>
                <div class="col-6">
                    <div style="font-size:0.75rem;opacity:0.75;">Pelunasan (70%)</div>
                    <div style="font-family:var(--font-display);font-size:1rem;color:var(--gold);font-weight:700;"><?= formatRupiah($p['harga'] * 0.7) ?></div>
                </div>
            </div>
            <p style="font-size:0.75rem;opacity:0.65;margin-top:10px;margin-bottom:0;">* DP dibayarkan saat booking. Pelunasan H-7 acara.</p>
        </div>
    </div>

    <!-- ══ RIGHT PANEL ══════════════════════════════════ -->
    <div class="col-lg-7">
        <span class="section-subtitle" style="display:block;"><?= htmlspecialchars($p['kategori']) ?> Package</span>
        <h2 style="font-family:var(--font-display);font-size:2.5rem;color:var(--maroon);">
            <?= htmlspecialchars($p['nama_paket']) ?>
        </h2>
        <div class="divider-gold" style="margin:14px 0 22px;"></div>

        <p style="color:#555;line-height:1.9;font-size:0.95rem;margin-bottom:28px;">
            <?= nl2br(htmlspecialchars($p['deskripsi'])) ?>
        </p>

        <!-- Fasilitas -->
        <h5 style="font-family:var(--font-display);color:var(--maroon);font-size:1.25rem;margin-bottom:6px;">
            <i class="bi bi-check2-circle me-2" style="color:var(--gold);"></i>Yang Anda Dapatkan
        </h5>
        <p style="font-size:0.8rem;color:#aaa;margin-bottom:14px;">
            <i class="bi bi-hand-index me-1" style="color:var(--maroon);"></i>
            Fasilitas bertanda <span style="background:rgba(105,27,27,0.08);color:var(--maroon);padding:1px 7px;border-radius:50px;font-size:0.7rem;font-weight:700;">Pilih Vendor</span> dapat diklik untuk memilih vendor pilihan Anda
        </p>

        <div class="row g-2">
        <?php foreach ($fasilitas as $idx => $f):
            $f    = trim($f);
            $slug = getFasilitasSlug($f, $fasilitasVendorMap, $fasilitasTanpaVendor);
            $has  = $slug && !empty($vendorBySlug[$slug]);
        ?>
        <div class="col-md-6">
            <div class="fasilitas-item <?= $has ? 'has-vendor' : '' ?>"
                 id="fi-<?= $idx ?>"
                 <?= $has ? "onclick=\"openPicker('".htmlspecialchars($slug)."','".htmlspecialchars(addslashes($f))."',$idx)\"" : '' ?>>
                <i class="bi bi-check-circle-fill" style="color:var(--maroon);margin-top:2px;min-width:16px;flex-shrink:0;"></i>
                <div>
                    <span style="font-size:0.88rem;"><?= htmlspecialchars($f) ?></span>
                    <div class="selected-vendor-label" id="svl-<?= $idx ?>"></div>
                </div>
                <?php if ($has): ?>
                <span class="vendor-hint-tag"><i class="bi bi-people"></i> Pilih Vendor</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        </div>

        <!-- Vendor Selection Summary -->
        <div id="vendorSummary" class="summary-bar" style="display:none;">
            <h6 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:14px;">
                <i class="bi bi-list-check me-2"></i>Vendor yang Anda Pilih
            </h6>
            <div id="summaryRows"></div>
            <div class="d-flex gap-2 mt-3">
                <a href="<?= isLoggedIn() ? BASE_URL . 'client/form-booking.php?paket=' . $p['id'] : BASE_URL . 'login.php' ?>"
                   class="btn btn-maroon btn-sm flex-grow-1">
                    <i class="bi bi-heart me-1"></i>Lanjut Pesan dengan Vendor Ini
                </a>
                <button onclick="resetAll()" class="btn btn-outline-maroon btn-sm" title="Reset semua">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </button>
            </div>
        </div>
    </div>

</div><!-- /row -->
</div><!-- /container -->
</section>

<!-- ═════════════════════════════════════════════════
     VENDOR PICKER MODAL
════════════════════════════════════════════════════ -->
<div class="modal fade vendor-picker-modal" id="vpModal" tabindex="-1">
<div class="modal-dialog modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <div>
            <div style="font-size:0.7rem;opacity:0.7;letter-spacing:1px;text-transform:uppercase;">Pilih vendor untuk</div>
            <div class="modal-title" id="vpTitle">—</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body p-3" id="vpBody"></div>
    <div class="modal-footer" style="background:var(--off-white);">
        <button type="button" class="btn btn-outline-maroon btn-sm" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-maroon btn-sm" onclick="confirmPick()">
            <i class="bi bi-check-circle me-1"></i>Pilih Vendor Ini
        </button>
    </div>
</div>
</div>
</div>

<?php include 'includes/footer.php'; ?>
<a href="https://wa.me/6281234567890?text=<?= urlencode('Halo, saya ingin bertanya mengenai paket wedding Ruma Planner.') ?>" target="_blank" class="wa-float"><i class="bi bi-whatsapp"></i></a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
// ─── DATA ─────────────────────────────────────────────────
const vendorData  = <?= json_encode($vendorBySlug, JSON_UNESCAPED_UNICODE) ?>;
const bookedDates = <?= json_encode($bookedDates,  JSON_UNESCAPED_UNICODE) ?>;
const basePaket   = <?= (int)$p['harga'] ?>;

// ─── KALENDER ─────────────────────────────────────────────
const MONTHS = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
let calYear  = new Date().getFullYear();
let calMonth = new Date().getMonth();
let calSel   = null;

function renderCal(y, m) {
    document.getElementById('calTitle').textContent = MONTHS[m] + ' ' + y;
    const grid = document.getElementById('calGrid');
    grid.innerHTML = '';
    ['Min','Sen','Sel','Rab','Kam','Jum','Sab'].forEach(d => {
        const el = document.createElement('div');
        el.className = 'cal-day-name'; el.textContent = d; grid.appendChild(el);
    });
    const firstDay = new Date(y, m, 1).getDay();
    const days = new Date(y, m+1, 0).getDate();
    const today = new Date(); today.setHours(0,0,0,0);
    for (let i = 0; i < firstDay; i++) {
        const el = document.createElement('div'); el.className = 'cal-day empty'; grid.appendChild(el);
    }
    for (let d = 1; d <= days; d++) {
        const el  = document.createElement('div');
        const ds  = y+'-'+String(m+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');
        const dt  = new Date(y, m, d);
        el.textContent = d;
        if (dt < today) {
            el.className = 'cal-day past';
        } else if (bookedDates[ds] === 'confirmed' || bookedDates[ds] === 'paid') {
            el.className = 'cal-day full'; el.title = 'Full Booked';
        } else if (bookedDates[ds] === 'pending') {
            el.className = 'cal-day pending'; el.title = 'Pending';
        } else {
            el.className = 'cal-day avail'; el.title = 'Tersedia';
            el.onclick = () => pickDate(ds, el);
        }
        if (ds === calSel) el.classList.add('selected');
        if (d === today.getDate() && m === today.getMonth() && y === today.getFullYear())
            el.classList.add('today');
        grid.appendChild(el);
    }
}
function calPrev() { calMonth--; if (calMonth<0){calMonth=11;calYear--;} renderCal(calYear,calMonth); }
function calNext() { calMonth++; if (calMonth>11){calMonth=0;calYear++;} renderCal(calYear,calMonth); }

function pickDate(ds, el) {
    calSel = ds;
    renderCal(calYear, calMonth);
    const [y,m,d] = ds.split('-');
    const label = d + ' ' + MONTHS[parseInt(m)-1] + ' ' + y;
    const status = bookedDates[ds];
    const res = document.getElementById('calResult');
    const resDate = document.getElementById('calResultDate');
    const resBadge = document.getElementById('calResultBadge');
    const resAction = document.getElementById('calResultAction');
    res.style.display = 'block';
    resDate.textContent = label;
    if (!status) {
        res.style.background = '#d4edda';
        resBadge.innerHTML = '<span class="availability-badge avail-green"><i class="bi bi-circle-fill me-1" style="font-size:0.45rem;"></i>Tersedia</span>';
        resAction.innerHTML = `<a href="<?= isLoggedIn() ? BASE_URL.'client/form-booking.php?paket='.$p['id'].'&tanggal=' : BASE_URL.'login.php?ref=detail-paket.php?id='.$p['id'].'#tanggal=' ?>${ds}" class="btn btn-maroon btn-sm"><i class="bi bi-calendar-check me-1"></i>Booking Tanggal Ini</a>`;
    } else if (status === 'pending') {
        res.style.background = '#fff3cd';
        resBadge.innerHTML = '<span class="availability-badge avail-yellow"><i class="bi bi-clock me-1"></i>Pending</span>';
        resAction.innerHTML = '<small style="color:#856404;">Tanggal ini sedang dalam proses booking oleh calon pelanggan lain.</small>';
    } else {
        res.style.background = '#f8d7da';
        resBadge.innerHTML = '<span class="availability-badge avail-red"><i class="bi bi-x-circle me-1"></i>Full Booked</span>';
        resAction.innerHTML = '<small style="color:#721c24;">Maaf, tanggal ini sudah dipesan. Silakan pilih tanggal lain.</small>';
    }
}
renderCal(calYear, calMonth);

// ─── VENDOR PICKER ────────────────────────────────────────
let selectedVendors = {};  // { idx: {id, nama, harga, satuan, fasilitas} }
let curSlug = null, curLabel = null, curIdx = null, tempPick = null;
const vpModal = new bootstrap.Modal(document.getElementById('vpModal'));

function openPicker(slug, label, idx) {
    curSlug = slug; curLabel = label; curIdx = idx;
    tempPick = selectedVendors[idx] || null;
    document.getElementById('vpTitle').textContent = label;
    const vendors = vendorData[slug] || [];
    const body = document.getElementById('vpBody');
    if (!vendors.length) {
        body.innerHTML = '<div class="text-center py-5 text-muted"><i class="bi bi-emoji-frown" style="font-size:2.5rem;opacity:.3;"></i><p class="mt-3">Belum ada vendor tersedia</p></div>';
    } else {
        body.innerHTML = '<div class="row g-3">' + vendors.map(v => {
            const sel = tempPick && tempPick.id == v.id;
            const hargaStr = v.harga_mulai > 0
                ? `<span style="color:var(--maroon);font-weight:700;font-size:0.82rem;">+ ${fmtRp(v.harga_mulai)}</span> <small style="color:#aaa;font-size:0.72rem;">${escH(v.harga_satuan)}</small>`
                : `<span style="color:#28a745;font-weight:600;font-size:0.8rem;"><i class="bi bi-check-circle me-1"></i>Sudah termasuk paket</span>`;
            const badge = v.badge ? `<span style="background:var(--gold);color:#fff;padding:2px 8px;border-radius:50px;font-size:0.65rem;font-weight:700;">${escH(v.badge)}</span>` : '';
            return `<div class="col-12">
              <div class="vp-card ${sel?'active':''}" onclick="pickVendor(this,${v.id},'${escJs(v.nama)}',${v.harga_mulai},'${escJs(v.harga_satuan)}')">
                <div class="vp-check"><i class="bi bi-check"></i></div>
                <div class="d-flex gap-3 align-items-start">
                  <div class="vp-icon"><i class="bi ${escH(v.kategori_icon)}"></i></div>
                  <div class="flex-grow-1 min-w-0">
                    <div class="d-flex align-items-center gap-2 flex-wrap mb-1">
                      <strong style="font-size:0.92rem;">${escH(v.nama)}</strong>${badge}
                    </div>
                    <div style="color:var(--gold);font-size:0.75rem;margin-bottom:5px;">
                      ${'★'.repeat(Math.round(v.rating))}${'☆'.repeat(5-Math.round(v.rating))}
                      <span style="color:#aaa;"> ${v.rating} (${v.total_review} ulasan)</span>
                    </div>
                    <p style="font-size:0.78rem;color:#666;margin-bottom:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">${escH(v.deskripsi)}</p>
                    <div class="d-flex justify-content-between flex-wrap gap-2 align-items-center">
                      <div>${hargaStr}</div>
                      <small style="color:#aaa;font-size:0.72rem;"><i class="bi bi-geo-alt me-1"></i>${escH(v.lokasi)}</small>
                    </div>
                  </div>
                </div>
              </div>
            </div>`;
        }).join('') + '</div>';
    }
    vpModal.show();
}

function pickVendor(el, id, nama, harga, satuan) {
    document.querySelectorAll('.vp-card').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    tempPick = { id, nama, harga, satuan };
}

function confirmPick() {
    if (!tempPick) { vpModal.hide(); return; }
    selectedVendors[curIdx] = { ...tempPick, fasilitas: curLabel };
    const item = document.getElementById('fi-' + curIdx);
    item.classList.add('vendor-selected');
    document.getElementById('svl-' + curIdx).textContent = '→ ' + tempPick.nama;
    updateSummary();
    vpModal.hide();
}

function updateSummary() {
    const keys = Object.keys(selectedVendors);
    const el = document.getElementById('vendorSummary');
    const rows = document.getElementById('summaryRows');
    const addonLines = document.getElementById('addonLines');
    const addonSec = document.getElementById('addonSection');
    if (!keys.length) { el.style.display='none'; addonSec.style.display='none'; return; }

    let total = basePaket, rowsHtml = '', addonHtml = '';
    keys.forEach(i => {
        const sv = selectedVendors[i];
        total += sv.harga;
        rowsHtml += `<div class="d-flex justify-content-between align-items-center py-2" style="border-bottom:1px solid rgba(105,27,27,0.08);">
          <div><div style="font-size:0.72rem;color:#aaa;">${escH(sv.fasilitas)}</div>
          <div style="font-weight:600;font-size:0.88rem;color:var(--maroon);">${escH(sv.nama)}</div></div>
          <div style="font-size:0.82rem;color:var(--maroon);">${sv.harga > 0 ? '+'+fmtRp(sv.harga) : 'Termasuk'}</div>
        </div>`;
        if (sv.harga > 0) addonHtml += `<div>+ ${escH(sv.nama)}: ${fmtRp(sv.harga)}</div>`;
    });
    rows.innerHTML = rowsHtml;
    el.style.display = 'block';
    if (addonHtml) {
        addonLines.innerHTML = addonHtml;
        document.getElementById('totalEstimasi').textContent = fmtRp(total);
        addonSec.style.display = 'block';
    }
}

function resetAll() {
    selectedVendors = {};
    document.querySelectorAll('.fasilitas-item').forEach(e => e.classList.remove('vendor-selected'));
    document.querySelectorAll('[id^="svl-"]').forEach(e => e.textContent = '');
    document.getElementById('vendorSummary').style.display = 'none';
    document.getElementById('addonSection').style.display = 'none';
}

// helpers
function fmtRp(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }
function escH(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function escJs(s) { return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }
</script>
</body>
</html>
