<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isPemilik()) {
    $home = match(getRole()) {
        'admin'    => BASE_URL.'admin/dashboard.php',
        'operator' => BASE_URL.'operator/dashboard.php',
        default    => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}

$total_booking   = $pdo->query("SELECT COUNT(*) FROM booking")->fetchColumn();
$total_client    = $pdo->query("SELECT COUNT(*) FROM users WHERE role='client'")->fetchColumn();
$total_vendor    = $pdo->query("SELECT COUNT(*) FROM vendor WHERE is_active=1")->fetchColumn();
$pendapatan      = $pdo->query("SELECT COALESCE(SUM(total_harga),0) FROM booking WHERE status='Completed'")->fetchColumn();
$dp_masuk        = $pdo->query("SELECT COALESCE(SUM(total_harga*0.3),0) FROM booking WHERE status IN('Confirmed','Completed')")->fetchColumn();
$pending         = $pdo->query("SELECT COUNT(*) FROM booking WHERE status='Pending'")->fetchColumn();
$completed       = $pdo->query("SELECT COUNT(*) FROM booking WHERE status='Completed'")->fetchColumn();

// Pendapatan per bulan (6 bulan terakhir)
$bulanan = $pdo->query("SELECT strftime('%Y-%m', tanggal_acara) as bln, COUNT(*) as total, SUM(total_harga) as pendapatan FROM booking WHERE status='Completed' GROUP BY bln ORDER BY bln DESC LIMIT 6")->fetchAll();

// Paket terlaris
$paketLaris = $pdo->query("SELECT p.nama_paket, COUNT(b.id) as total FROM booking b JOIN paket p ON b.id_paket=p.id GROUP BY b.id_paket ORDER BY total DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard Pemilik — <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 style="font-family:var(--font-display);color:var(--maroon);margin:0;">Dashboard Pemilik</h3>
            <p class="text-muted mb-0">Selamat datang, <?= htmlspecialchars($_SESSION['nama']) ?></p>
        </div>
        <span class="badge" style="background:var(--gold);color:#fff;font-size:0.85rem;padding:8px 16px;">
            <i class="bi bi-star-fill me-1"></i>Pemilik
        </span>
    </div>

    <!-- Stats utama -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-cash-stack" style="font-size:2rem;color:var(--gold);"></i>
                <div style="font-size:1.4rem;font-family:var(--font-display);color:var(--maroon);font-weight:700;margin-top:4px;"><?= formatRupiah($pendapatan) ?></div>
                <div class="text-muted small">Total Pendapatan</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-calendar-check" style="font-size:2rem;color:var(--maroon);"></i>
                <div style="font-size:2rem;font-family:var(--font-display);color:var(--maroon);font-weight:700;"><?= $total_booking ?></div>
                <div class="text-muted small">Total Booking</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-people-fill" style="font-size:2rem;color:#3b82f6;"></i>
                <div style="font-size:2rem;font-family:var(--font-display);color:#3b82f6;font-weight:700;"><?= $total_client ?></div>
                <div class="text-muted small">Total Client</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <i class="bi bi-shop" style="font-size:2rem;color:#10b981;"></i>
                <div style="font-size:2rem;font-family:var(--font-display);color:#10b981;font-weight:700;"><?= $total_vendor ?></div>
                <div class="text-muted small">Total Vendor Aktif</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Paket Terlaris -->
        <div class="col-lg-5">
            <div class="bg-white rounded-xl p-4 shadow-sm h-100">
                <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-trophy me-2"></i>Paket Terlaris</h5>
                <?php foreach ($paketLaris as $i => $pl): ?>
                <div class="d-flex align-items-center gap-3 mb-3 p-2 rounded" style="background:var(--off-white);">
                    <div style="width:32px;height:32px;border-radius:50%;background:var(--maroon);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;flex-shrink:0;"><?= $i+1 ?></div>
                    <div class="flex-grow-1">
                        <div class="fw-semibold" style="font-size:0.9rem;"><?= htmlspecialchars($pl['nama_paket']) ?></div>
                        <div class="text-muted" style="font-size:0.75rem;"><?= $pl['total'] ?> booking</div>
                    </div>
                    <div style="font-family:var(--font-display);color:var(--maroon);font-weight:700;"><?= $pl['total'] ?>x</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <!-- Rekap Status -->
        <div class="col-lg-7">
            <div class="bg-white rounded-xl p-4 shadow-sm h-100">
                <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-bar-chart me-2"></i>Rekap Booking</h5>
                <div class="row g-3 mb-4">
                    <div class="col-4 text-center p-3 rounded" style="background:#fff3cd;">
                        <div style="font-size:1.8rem;font-weight:700;color:#f59e0b;"><?= $pending ?></div>
                        <div class="small text-muted">Pending</div>
                    </div>
                    <div class="col-4 text-center p-3 rounded" style="background:#dbeafe;">
                        <div style="font-size:1.8rem;font-weight:700;color:#3b82f6;"><?= $total_booking - $pending - $completed ?></div>
                        <div class="small text-muted">Proses</div>
                    </div>
                    <div class="col-4 text-center p-3 rounded" style="background:#d1fae5;">
                        <div style="font-size:1.8rem;font-weight:700;color:#10b981;"><?= $completed ?></div>
                        <div class="small text-muted">Selesai</div>
                    </div>
                </div>
                <div class="p-3 rounded" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:#fff;">
                    <div style="font-size:0.8rem;opacity:.75;">DP yang sudah masuk</div>
                    <div style="font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--gold);"><?= formatRupiah($dp_masuk) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
