<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isPemilik()) {
    $home = match(getRole()) {
        'admin'    => BASE_URL.'admin/dashboard.php',
        'operator' => BASE_URL.'operator/dashboard.php',
        default    => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}
$vendors = $pdo->query("SELECT v.*, vk.nama AS nama_kategori FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id ORDER BY vk.urutan, v.rating DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Vendor — Pemilik</title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head><body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <h3 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:4px;">Data Vendor</h3>
    <p class="text-muted mb-4">Statistik performa vendor (hanya baca)</p>
    <div class="bg-white rounded-xl p-4 shadow-sm">
    <div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead style="background:var(--maroon-pale);"><tr><th>Vendor</th><th>Kategori</th><th>Harga Mulai</th><th>Rating</th><th>Total Booking</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($vendors as $v): ?>
        <tr>
            <td><div class="fw-semibold"><?= htmlspecialchars($v['nama']) ?></div>
                <small class="text-muted"><?= htmlspecialchars($v['lokasi']) ?></small></td>
            <td><span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= htmlspecialchars($v['nama_kategori']) ?></span></td>
            <td style="color:var(--maroon);font-weight:600;"><?= formatRupiah($v['harga_mulai']) ?></td>
            <td><span style="color:var(--gold);">★</span> <?= number_format($v['rating'],1) ?> <small class="text-muted">(<?= $v['total_review'] ?>)</small></td>
            <td><span class="badge bg-primary"><?= $v['total_booking'] ?>x</span></td>
            <td><?= $v['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-danger">Nonaktif</span>' ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div></div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
