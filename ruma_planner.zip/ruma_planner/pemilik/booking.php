<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isPemilik()) {
    $home = match(getRole()) {
        'admin'    => BASE_URL.'admin/dashboard.php',
        'operator' => BASE_URL.'operator/dashboard.php',
        default    => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}
$bookings = $pdo->query("SELECT b.*, u.nama as nama_client, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id ORDER BY b.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Booking — Pemilik</title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head><body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <h3 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:4px;">Data Booking</h3>
    <p class="text-muted mb-4">Lihat semua data booking (hanya baca)</p>
    <div class="bg-white rounded-xl p-4 shadow-sm">
    <div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead style="background:var(--maroon-pale);"><tr><th>Kode</th><th>Client</th><th>Paket</th><th>Tanggal</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($bookings as $b): ?>
        <tr>
            <td><code><?= htmlspecialchars($b['kode_booking']) ?></code></td>
            <td><?= htmlspecialchars($b['nama_client']) ?></td>
            <td><?= htmlspecialchars($b['nama_paket']) ?></td>
            <td><?= date('d M Y', strtotime($b['tanggal_acara'])) ?></td>
            <td style="color:var(--maroon);font-weight:600;"><?= formatRupiah($b['total_harga']) ?></td>
            <td><?php $cls=['Pending'=>'warning','Confirmed'=>'primary','Completed'=>'success','Cancelled'=>'danger']; ?>
                <span class="badge bg-<?= $cls[$b['status']] ?? 'secondary' ?>"><?= $b['status'] ?></span></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div></div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
