<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireStaff();
if (!isPemilik()) {
    $home = match(getRole()) {
        'admin'    => BASE_URL.'admin/dashboard.php',
        'operator' => BASE_URL.'operator/dashboard.php',
        default    => BASE_URL.'index.php',
    };
    header('Location: '.$home); exit();
}

$tahun = (int)($_GET['tahun'] ?? date('Y'));
$laporan = $pdo->prepare("SELECT strftime('%m', tanggal_acara) as bln, COUNT(*) as total_booking, SUM(total_harga) as total_pendapatan, SUM(total_harga*0.3) as total_dp FROM booking WHERE strftime('%Y', tanggal_acara)=? AND status IN ('Confirmed','Completed') GROUP BY bln ORDER BY bln");
$laporan->execute([$tahun]);
$rows = $laporan->fetchAll();

$grandTotal = array_sum(array_column($rows, 'total_pendapatan'));
$grandBooking = array_sum(array_column($rows, 'total_booking'));
$namaBulan = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Laporan Pendapatan — Pemilik</title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div><h3 style="font-family:var(--font-display);color:var(--maroon);margin:0;">Laporan Pendapatan</h3>
        <p class="text-muted mb-0">Rekap booking dan pendapatan per bulan</p></div>
        <form method="GET" class="d-flex gap-2 align-items-center">
            <select name="tahun" class="form-select form-select-sm" onchange="this.form.submit()">
                <?php for($y=date('Y');$y>=2023;$y--): ?>
                <option value="<?= $y ?>" <?= $y==$tahun?'selected':'' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
        </form>
    </div>

    <!-- Summary -->
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <div style="font-size:0.8rem;color:#aaa;text-transform:uppercase;letter-spacing:1px;">Total Pendapatan <?= $tahun ?></div>
                <div style="font-family:var(--font-display);font-size:1.8rem;color:var(--maroon);font-weight:700;"><?= formatRupiah($grandTotal) ?></div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="p-4 bg-white rounded-xl shadow-sm text-center">
                <div style="font-size:0.8rem;color:#aaa;text-transform:uppercase;letter-spacing:1px;">Total Booking <?= $tahun ?></div>
                <div style="font-family:var(--font-display);font-size:1.8rem;color:var(--maroon);font-weight:700;"><?= $grandBooking ?> booking</div>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-xl p-4 shadow-sm">
        <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead style="background:var(--maroon-pale);">
                <tr><th>Bulan</th><th>Total Booking</th><th>Pendapatan</th><th>DP Masuk</th></tr>
            </thead>
            <tbody>
            <?php if (empty($rows)): ?>
            <tr><td colspan="4" class="text-center py-4 text-muted">Belum ada data untuk tahun <?= $tahun ?></td></tr>
            <?php else: ?>
            <?php foreach ($rows as $r): ?>
            <tr>
                <td class="fw-semibold"><?= $namaBulan[$r['bln']] ?? $r['bln'] ?> <?= $tahun ?></td>
                <td><span class="badge bg-primary"><?= $r['total_booking'] ?> booking</span></td>
                <td style="font-family:var(--font-display);color:var(--maroon);font-weight:700;"><?= formatRupiah($r['total_pendapatan']) ?></td>
                <td style="color:#10b981;font-weight:600;"><?= formatRupiah($r['total_dp']) ?></td>
            </tr>
            <?php endforeach; ?>
            <tr style="background:var(--maroon-pale);">
                <td class="fw-bold">TOTAL</td>
                <td class="fw-bold"><?= $grandBooking ?> booking</td>
                <td style="font-family:var(--font-display);color:var(--maroon);font-weight:700;font-size:1.1rem;"><?= formatRupiah($grandTotal) ?></td>
                <td style="color:#10b981;font-weight:700;"><?= formatRupiah(array_sum(array_column($rows,'total_dp'))) ?></td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
