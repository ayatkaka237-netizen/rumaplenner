<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();

// Handle actions
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

// DELETE
if ($action === 'delete' && $id) {
    $stmtFoto = $pdo->prepare("SELECT foto FROM paket WHERE id=?");
    $stmtFoto->execute([$id]);
    $p = $stmtFoto->fetch();
    if ($p && $p['foto'] && file_exists(UPLOAD_PAKET . $p['foto'])) unlink(UPLOAD_PAKET . $p['foto']);
    $pdo->prepare("DELETE FROM paket WHERE id=?")->execute([$id]);
    setFlash('success', 'Paket berhasil dihapus.');
    header('Location: paket.php'); exit();
}

// TOGGLE ACTIVE
if ($action === 'toggle' && $id) {
    $pdo->prepare("UPDATE paket SET is_active = CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?")->execute([$id]);
    setFlash('success', 'Status paket diperbarui.');
    header('Location: paket.php'); exit();
}

// SAVE (add/edit)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $nama_paket = sanitize($pdo, $_POST['nama_paket']);
    $kategori   = sanitize($pdo, $_POST['kategori']);
    $harga      = (float)str_replace(['.', ','], ['', '.'], $_POST['harga']);
    $deskripsi  = sanitize($pdo, $_POST['deskripsi']);
    $fasilitas  = sanitize($pdo, $_POST['fasilitas']);
    $max_tamu   = (int)$_POST['max_tamu'];
    $edit_id    = (int)($_POST['edit_id'] ?? 0);

    $foto_name = sanitize($pdo, $_POST['foto_existing'] ?? '');

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $upload = uploadImage($_FILES['foto'], UPLOAD_PAKET, 'paket');
        if ($upload['success']) {
            if ($foto_name && file_exists(UPLOAD_PAKET . $foto_name)) unlink(UPLOAD_PAKET . $foto_name);
            $foto_name = $upload['filename'];
        }
    }

    if ($edit_id) {
        $stmt = $pdo->prepare("UPDATE paket SET nama_paket=?,kategori=?,harga=?,deskripsi=?,fasilitas=?,max_tamu=?,foto=? WHERE id=?");
        $msg = 'Paket berhasil diperbarui.';
        $stmt->execute([$nama_paket, $kategori, $harga, $deskripsi, $fasilitas, $max_tamu, $foto_name, $edit_id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO paket (nama_paket,kategori,harga,deskripsi,fasilitas,max_tamu,foto) VALUES (?,?,?,?,?,?,?)");
        $msg = 'Paket berhasil ditambahkan.';
        $stmt->execute([$nama_paket, $kategori, $harga, $deskripsi, $fasilitas, $max_tamu, $foto_name]);
    }
    setFlash('success', $msg);
    header('Location: paket.php'); exit();
}

// Get edit data
$edit_data = null;
if ($action === 'edit' && $id) {
    $stmtEdit = $pdo->prepare("SELECT * FROM paket WHERE id=?");
    $stmtEdit->execute([$id]);
    $edit_data = $stmtEdit->fetch();
}

$pakets = $pdo->query("SELECT * FROM paket ORDER BY id DESC")->fetchAll();
$kategori_list = ['Intimate', 'Reguler', 'Premium', 'Exclusive'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Paket — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="admin-main">
    <div class="admin-topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-sm d-lg-none" id="sidebarToggle" style="background:var(--maroon-pale);color:var(--maroon);">
                <i class="bi bi-list fs-5"></i>
            </button>
            <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);font-weight:600;">Kelola Paket Wedding</div>
        </div>
        <button class="btn btn-maroon btn-sm px-4" data-bs-toggle="modal" data-bs-target="#modalPaket">
            <i class="bi bi-plus-circle me-2"></i>Tambah Paket
        </button>
    </div>

    <div class="admin-content">
        <?php showFlash(); ?>

        <div class="admin-table-card">
            <div class="table-header">
                <div class="table-title">Daftar Paket (<?= count($pakets) ?>)</div>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="60">Foto</th>
                            <th>Nama Paket</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Max Tamu</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($pakets as $p): ?>
                    <tr>
                        <td>
                            <?php if ($p['foto'] && file_exists(UPLOAD_PAKET . $p['foto'])): ?>
                                <img src="<?= UPLOAD_URL_PAKET . htmlspecialchars($p['foto']) ?>" 
                                     style="width:50px;height:40px;object-fit:cover;border-radius:6px;">
                            <?php else: ?>
                                <div style="width:50px;height:40px;background:var(--maroon-pale);border-radius:6px;display:flex;align-items:center;justify-content:center;">
                                    <i class="bi bi-house-heart" style="color:var(--maroon);"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= htmlspecialchars($p['nama_paket']) ?></strong></td>
                        <td><span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= $p['kategori'] ?></span></td>
                        <td style="font-weight:600;color:var(--maroon);"><?= formatRupiah($p['harga']) ?></td>
                        <td><?= $p['max_tamu'] ?> tamu</td>
                        <td>
                            <?php if ($p['is_active']): ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Nonaktif</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="paket.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Edit"
                                   data-bs-toggle="modal" data-bs-target="#modalPaket"
                                   onclick="fillEditForm(<?= htmlspecialchars(json_encode($p)) ?>)">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="paket.php?action=toggle&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-warning" title="Toggle Status">
                                    <i class="bi bi-toggle-on"></i>
                                </a>
                                <a href="paket.php?action=delete&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger confirm-delete" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Add/Edit Paket -->
<div class="modal fade" id="modalPaket" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <?= csrfField() ?>
                <input type="hidden" name="edit_id" id="edit_id" value="0">
                <input type="hidden" name="foto_existing" id="foto_existing" value="">
                <div class="modal-header" style="background:var(--maroon);color:white;">
                    <h5 class="modal-title" id="modalPaketTitle">Tambah Paket Baru</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">Nama Paket <span class="text-danger">*</span></label>
                            <input type="text" name="nama_paket" id="fm_nama_paket" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Kategori <span class="text-danger">*</span></label>
                            <select name="kategori" id="fm_kategori" class="form-select" required>
                                <?php foreach ($kategori_list as $k): ?>
                                <option value="<?= $k ?>"><?= $k ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
                            <input type="text" name="harga" id="fm_harga" class="form-control currency-input" placeholder="0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Max Tamu <span class="text-danger">*</span></label>
                            <input type="number" name="max_tamu" id="fm_max_tamu" class="form-control" min="1" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="deskripsi" id="fm_deskripsi" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Fasilitas <span class="text-danger">*</span></label>
                            <textarea name="fasilitas" id="fm_fasilitas" class="form-control" rows="4" 
                                      placeholder="Pisahkan dengan | (pipe). Contoh: Dekorasi|Catering|Foto" required></textarea>
                            <div class="form-text">Pisahkan setiap fasilitas dengan tanda | (pipe)</div>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Foto Paket</label>
                            <input type="file" name="foto" class="form-control file-with-preview" 
                                   data-preview="fotoPreview" accept="image/*">
                            <div class="mt-2">
                                <img id="fotoPreview" src="" alt="Preview" style="max-height:150px;border-radius:8px;display:none;">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-maroon">
                        <i class="bi bi-save me-2"></i>Simpan Paket
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
function fillEditForm(data) {
    document.getElementById('edit_id').value = data.id;
    document.getElementById('fm_nama_paket').value = data.nama_paket;
    document.getElementById('fm_kategori').value = data.kategori;
    document.getElementById('fm_harga').value = parseInt(data.harga).toLocaleString('id-ID');
    document.getElementById('fm_max_tamu').value = data.max_tamu;
    document.getElementById('fm_deskripsi').value = data.deskripsi;
    document.getElementById('fm_fasilitas').value = data.fasilitas;
    document.getElementById('foto_existing').value = data.foto || '';
    document.getElementById('modalPaketTitle').textContent = 'Edit Paket';
}
document.getElementById('modalPaket').addEventListener('hidden.bs.modal', function () {
    document.getElementById('edit_id').value = '0';
    document.getElementById('foto_existing').value = '';
    document.getElementById('modalPaketTitle').textContent = 'Tambah Paket Baru';
    document.getElementById('fotoPreview').style.display = 'none';
    this.querySelector('form').reset();
});
</script>
</body>
</html>
