<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $act = $_POST['act'] ?? '';

    if ($act === 'tambah') {
        $nama     = sanitize($pdo, $_POST['nama'] ?? '');
        $username = sanitize($pdo, $_POST['username'] ?? '');
        $email    = sanitize($pdo, $_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role     = in_array($_POST['role'] ?? '', ['operator','pemilik']) ? $_POST['role'] : 'operator';

        if (!$nama || !$username || !$email || !$password) {
            $error = 'Semua field wajib diisi.';
        } else {
            $cek = $pdo->prepare("SELECT id FROM users WHERE username=? OR email=?");
            $cek->execute([$username, $email]);
            if ($cek->fetch()) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                $pdo->prepare("INSERT INTO users (nama,username,email,password,role) VALUES (?,?,?,?,?)")
                    ->execute([$nama, $username, $email, password_hash($password, PASSWORD_BCRYPT), $role]);
                setFlash('success', 'Staff '.$role.' berhasil ditambahkan.');
                header('Location: '.BASE_URL.'admin/users.php'); exit();
            }
        }
    } elseif ($act === 'delete') {
        $uid = (int)($_POST['uid'] ?? 0);
        if ($uid && $uid !== $_SESSION['user_id']) {
            $pdo->prepare("DELETE FROM users WHERE id=? AND role IN ('operator','pemilik')")->execute([$uid]);
            setFlash('success', 'Staff berhasil dihapus.');
        }
        header('Location: '.BASE_URL.'admin/users.php'); exit();
    }
}

$staffList = $pdo->query("SELECT * FROM users WHERE role IN ('operator','pemilik') ORDER BY role, nama")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kelola Staff — Admin <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head><body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:28px 32px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div><h3 style="font-family:var(--font-display);color:var(--maroon);margin:0;">Kelola Staff</h3>
        <p class="text-muted mb-0">Tambah dan kelola akun Operator & Pemilik</p></div>
        <button class="btn btn-maroon" data-bs-toggle="modal" data-bs-target="#modalTambah">
            <i class="bi bi-person-plus me-1"></i>Tambah Staff
        </button>
    </div>
    <?php showFlash(); ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>

    <!-- Info Role -->
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="p-3 rounded-xl" style="background:#fff;border:2px solid var(--maroon-pale);">
                <div class="d-flex gap-3 align-items-center">
                    <div style="width:44px;height:44px;background:#dbeafe;border-radius:10px;display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-person-badge" style="color:#3b82f6;font-size:1.3rem;"></i>
                    </div>
                    <div><div class="fw-bold">Operator</div>
                    <div class="small text-muted">Kelola booking, konfirmasi pembayaran, kelola booking vendor</div></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="p-3 rounded-xl" style="background:#fff;border:2px solid var(--maroon-pale);">
                <div class="d-flex gap-3 align-items-center">
                    <div style="width:44px;height:44px;background:#fef3c7;border-radius:10px;display:flex;align-items:center;justify-content:center;">
                        <i class="bi bi-star-fill" style="color:var(--gold);font-size:1.3rem;"></i>
                    </div>
                    <div><div class="fw-bold">Pemilik</div>
                    <div class="small text-muted">Lihat laporan, statistik, dan data (hanya baca)</div></div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-xl p-4 shadow-sm">
        <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead style="background:var(--maroon-pale);"><tr><th>Nama</th><th>Username</th><th>Email</th><th>Role</th><th>Bergabung</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($staffList)): ?>
            <tr><td colspan="6" class="text-center py-4 text-muted">Belum ada staff. Tambah staff baru.</td></tr>
            <?php else: ?>
            <?php foreach ($staffList as $s): ?>
            <tr>
                <td class="fw-semibold"><?= htmlspecialchars($s['nama']) ?></td>
                <td><code><?= htmlspecialchars($s['username']) ?></code></td>
                <td><?= htmlspecialchars($s['email']) ?></td>
                <td>
                    <?php if ($s['role']==='operator'): ?>
                    <span class="badge bg-primary">Operator</span>
                    <?php else: ?>
                    <span class="badge" style="background:var(--gold);">Pemilik</span>
                    <?php endif; ?>
                </td>
                <td class="small text-muted"><?= date('d M Y', strtotime($s['created_at'])) ?></td>
                <td>
                    <form method="POST" onsubmit="return confirm('Hapus staff ini?')">
                        <?= csrfField() ?>
                        <input type="hidden" name="act" value="delete">
                        <input type="hidden" name="uid" value="<?= $s['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Staff -->
<div class="modal fade" id="modalTambah" tabindex="-1">
<div class="modal-dialog"><div class="modal-content">
    <div class="modal-header" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:#fff;border:none;">
        <h5 class="modal-title" style="font-family:var(--font-display);">Tambah Staff Baru</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" style="filter:invert(1);"></button>
    </div>
    <div class="modal-body p-4">
    <form method="POST">
        <?= csrfField() ?><input type="hidden" name="act" value="tambah">
        <div class="mb-3"><label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
        <input type="text" name="nama" class="form-control" required placeholder="Nama staff"></div>
        <div class="mb-3"><label class="form-label">Username <span class="text-danger">*</span></label>
        <input type="text" name="username" class="form-control" required placeholder="Username untuk login"></div>
        <div class="mb-3"><label class="form-label">Email <span class="text-danger">*</span></label>
        <input type="email" name="email" class="form-control" required placeholder="Email"></div>
        <div class="mb-3"><label class="form-label">Password <span class="text-danger">*</span></label>
        <input type="password" name="password" class="form-control" required placeholder="Minimal 6 karakter"></div>
        <div class="mb-3"><label class="form-label">Role <span class="text-danger">*</span></label>
        <select name="role" class="form-select">
            <option value="operator">Operator — Kelola booking & pembayaran</option>
            <option value="pemilik">Pemilik — Lihat laporan & statistik</option>
        </select></div>
        <button type="submit" class="btn btn-maroon w-100"><i class="bi bi-person-plus me-1"></i>Tambah Staff</button>
    </form>
    </div>
</div></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
