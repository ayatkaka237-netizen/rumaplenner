<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireClient();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: '.BASE_URL.'client/riwayat.php'); exit(); }

$stmt = $pdo->prepare("SELECT b.*, p.nama_paket, p.kategori FROM booking b JOIN paket p ON b.id_paket=p.id WHERE b.id=? AND b.id_user=?");
$stmt->execute([$id, $_SESSION['user_id']]);
$b = $stmt->fetch();
if (!$b) { header('Location: '.BASE_URL.'client/riwayat.php'); exit(); }

$dp        = $b['dp_amount'] ?: round($b['total_harga'] * 0.3);
$pelunasan = $b['pelunasan_amount'] ?: round($b['total_harga'] * 0.7);
$sudahDP   = !empty($b['bukti_pembayaran']);
$sudahLunas= !empty($b['bukti_pelunasan']);

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $jenis = $_POST['jenis'] ?? ''; // 'dp' atau 'pelunasan'

    if (!in_array($jenis, ['dp','pelunasan'])) { $error = 'Permintaan tidak valid.'; }
    else {
        $fileKey = $jenis === 'dp' ? 'bukti_pembayaran' : 'bukti_pelunasan';
        if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
            $error = 'Pilih file bukti transfer terlebih dahulu.';
        } else {
            $upload = uploadImage($_FILES[$fileKey], UPLOAD_BAYAR, $jenis);
            if (!$upload['success']) { $error = $upload['message']; }
            else {
                if ($jenis === 'dp') {
                    // Hapus file lama
                    if ($b['bukti_pembayaran'] && file_exists(UPLOAD_BAYAR.$b['bukti_pembayaran'])) unlink(UPLOAD_BAYAR.$b['bukti_pembayaran']);
                    $pdo->prepare("UPDATE booking SET bukti_pembayaran=?, status='Pending', updated_at=CURRENT_TIMESTAMP WHERE id=?")
                        ->execute([$upload['filename'], $id]);
                    $success = 'Bukti DP berhasil diupload! Admin akan memverifikasi dalam 1×24 jam.';
                } else {
                    if ($b['bukti_pelunasan'] && file_exists(UPLOAD_BAYAR.$b['bukti_pelunasan'])) unlink(UPLOAD_BAYAR.$b['bukti_pelunasan']);
                    $pdo->prepare("UPDATE booking SET bukti_pelunasan=?, status_pelunasan='Pending', updated_at=CURRENT_TIMESTAMP WHERE id=?")
                        ->execute([$upload['filename'], $id]);
                    $success = 'Bukti pelunasan berhasil diupload! Admin akan memverifikasi segera.';
                }
                // Reload
                $stmt->execute([$id, $_SESSION['user_id']]);
                $b = $stmt->fetch();
                $sudahDP    = !empty($b['bukti_pembayaran']);
                $sudahLunas = !empty($b['bukti_pelunasan']);
            }
        }
    }
}

// Status step
$step = 1;
if ($sudahDP && in_array($b['status'], ['Confirmed','Completed'])) $step = 2;
if ($sudahLunas) $step = 3;
if ($b['status'] === 'Completed') $step = 4;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pembayaran — <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
<style>
.step-bar { display:flex; align-items:center; margin-bottom:32px; }
.step-item { flex:1; text-align:center; position:relative; }
.step-item:not(:last-child)::after {
    content:''; position:absolute; top:18px; left:55%; width:90%; height:2px;
    background:#e0e0e0; z-index:0;
}
.step-item.done:not(:last-child)::after { background:var(--maroon); }
.step-circle {
    width:36px; height:36px; border-radius:50%; display:inline-flex;
    align-items:center; justify-content:center; font-size:0.85rem; font-weight:700;
    position:relative; z-index:1; border:2px solid #e0e0e0; background:#fff; color:#ccc;
}
.step-item.done  .step-circle { background:var(--maroon); border-color:var(--maroon); color:#fff; }
.step-item.active .step-circle { background:#fff; border-color:var(--maroon); color:var(--maroon); }
.step-label { font-size:0.7rem; color:#aaa; margin-top:6px; display:block; }
.step-item.done .step-label, .step-item.active .step-label { color:var(--maroon); font-weight:600; }

.rek-box {
    background:#fff; border:2px solid rgba(105,27,27,0.12); border-radius:12px;
    padding:18px; text-align:center; cursor:pointer; transition:var(--transition);
    position:relative;
}
.rek-box:hover { border-color:var(--maroon); background:var(--maroon-pale); }
.rek-no { font-size:1.25rem; font-weight:700; color:var(--maroon); letter-spacing:2px; margin:6px 0; }
.copy-btn { position:absolute; top:10px; right:10px; background:none; border:none; color:var(--maroon); font-size:1rem; cursor:pointer; }
.copy-toast { position:fixed; bottom:24px; left:50%; transform:translateX(-50%); background:var(--maroon); color:#fff; padding:10px 24px; border-radius:50px; font-size:0.85rem; z-index:9999; display:none; }

.pay-section { background:#fff; border-radius:var(--radius-lg); border:2px solid rgba(105,27,77,0.1); padding:24px; margin-bottom:20px; }
.pay-section.disabled { opacity:.45; pointer-events:none; }
.pay-section.active-pay { border-color:var(--maroon); }

.drop-zone {
    border:2px dashed rgba(105,27,27,0.25); border-radius:12px;
    padding:32px; text-align:center; cursor:pointer;
    transition:var(--transition); background:var(--off-white);
}
.drop-zone:hover, .drop-zone.dragover { border-color:var(--maroon); background:var(--maroon-pale); }
.drop-zone i { font-size:2.5rem; color:var(--maroon); opacity:.4; }
.bukti-thumb { max-height:180px; border-radius:10px; border:2px solid var(--maroon-pale); margin-top:12px; }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
  <div class="container">
    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>client/riwayat.php">Pesanan Saya</a></li>
        <li class="breadcrumb-item active">Pembayaran</li>
      </ol>
    </nav>
    <h1>Pembayaran Booking</h1>
    <p style="color:rgba(255,255,255,0.75);">Kode: <strong><?= htmlspecialchars($b['kode_booking']) ?></strong></p>
  </div>
</div>

<section class="section-padding">
<div class="container">

<?php if ($error): ?><div class="alert alert-danger mb-4"><i class="bi bi-exclamation-circle me-2"></i><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success mb-4"><i class="bi bi-check-circle me-2"></i><?= $success ?></div><?php endif; ?>

<div class="row g-4">
<!-- ─── KIRI: INFO BOOKING ──────────────── -->
<div class="col-lg-4">
  <!-- Ringkasan -->
  <div class="p-4 rounded-xl mb-4" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:#fff;">
    <div style="font-size:0.72rem;opacity:.7;text-transform:uppercase;letter-spacing:1px;">Paket Wedding</div>
    <div style="font-family:var(--font-display);font-size:1.4rem;margin-bottom:4px;"><?= htmlspecialchars($b['nama_paket']) ?></div>
    <div style="font-size:0.82rem;opacity:.75;margin-bottom:16px;">
      <?= htmlspecialchars($b['nama_mempelai_pria']) ?> &amp; <?= htmlspecialchars($b['nama_mempelai_wanita']) ?>
    </div>
    <div style="background:rgba(255,255,255,0.12);border-radius:10px;padding:14px;">
      <div class="d-flex justify-content-between mb-2">
        <span style="font-size:0.8rem;opacity:.8;">Tanggal Acara</span>
        <span style="font-size:0.85rem;font-weight:600;"><?= date('d M Y', strtotime($b['tanggal_acara'])) ?></span>
      </div>
      <div class="d-flex justify-content-between mb-2">
        <span style="font-size:0.8rem;opacity:.8;">Tamu</span>
        <span style="font-size:0.85rem;font-weight:600;"><?= $b['jumlah_tamu'] ?> orang</span>
      </div>
      <hr style="border-color:rgba(255,255,255,0.2);margin:10px 0;">
      <div class="d-flex justify-content-between mb-2">
        <span style="font-size:0.8rem;opacity:.8;">Total Harga</span>
        <span style="font-family:var(--font-display);font-size:1rem;"><?= formatRupiah($b['total_harga']) ?></span>
      </div>
      <div class="d-flex justify-content-between mb-2">
        <span style="font-size:0.8rem;opacity:.8;">DP (30%)</span>
        <span style="font-family:var(--font-display);font-size:1rem;color:var(--gold);"><?= formatRupiah($dp) ?></span>
      </div>
      <div class="d-flex justify-content-between">
        <span style="font-size:0.8rem;opacity:.8;">Pelunasan (70%)</span>
        <span style="font-family:var(--font-display);font-size:1rem;color:var(--gold);"><?= formatRupiah($pelunasan) ?></span>
      </div>
    </div>
  </div>

  <!-- Rekening Tujuan -->
  <div class="pay-section mb-0">
    <h6 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:14px;">
      <i class="bi bi-bank me-2"></i>Transfer ke Rekening
    </h6>
    <div class="rek-box mb-3" onclick="copyRek('1234567890','bca')">
      <button class="copy-btn" title="Salin nomor rekening"><i class="bi bi-clipboard"></i></button>
      <div style="font-size:0.72rem;color:#aaa;">Bank BCA</div>
      <div class="rek-no" id="bca">1234 5678 90</div>
      <div style="font-size:0.8rem;color:#666;">a.n. <?= OWNER ?></div>
    </div>
    <div class="rek-box" onclick="copyRek('0987654321','mandiri')">
      <button class="copy-btn" title="Salin nomor rekening"><i class="bi bi-clipboard"></i></button>
      <div style="font-size:0.72rem;color:#aaa;">Bank Mandiri</div>
      <div class="rek-no" id="mandiri">0987 6543 21</div>
      <div style="font-size:0.8rem;color:#666;">a.n. <?= OWNER ?></div>
    </div>
    <p style="font-size:0.78rem;color:#aaa;margin-top:12px;margin-bottom:0;">
      <i class="bi bi-info-circle me-1"></i>Transfer sesuai nominal, lalu upload bukti di sebelah kanan.
    </p>
  </div>
</div>

<!-- ─── KANAN: UPLOAD & STATUS ─────────── -->
<div class="col-lg-8">

  <!-- STEP BAR -->
  <div class="step-bar mb-4">
    <div class="step-item <?= $step >= 1 ? 'done' : '' ?>">
      <div class="step-circle"><i class="bi bi-check2"></i></div>
      <span class="step-label">Booking Dibuat</span>
    </div>
    <div class="step-item <?= $step >= 2 ? 'done' : ($step == 1 ? 'active' : '') ?>">
      <div class="step-circle"><?= $step >= 2 ? '<i class="bi bi-check2"></i>' : '2' ?></div>
      <span class="step-label">DP Dikonfirmasi</span>
    </div>
    <div class="step-item <?= $step >= 3 ? 'done' : ($step == 2 ? 'active' : '') ?>">
      <div class="step-circle"><?= $step >= 3 ? '<i class="bi bi-check2"></i>' : '3' ?></div>
      <span class="step-label">Pelunasan</span>
    </div>
    <div class="step-item <?= $step >= 4 ? 'done' : ($step == 3 ? 'active' : '') ?>">
      <div class="step-circle"><?= $step >= 4 ? '<i class="bi bi-check2"></i>' : '4' ?></div>
      <span class="step-label">Selesai</span>
    </div>
  </div>

  <!-- BAGIAN 1: UPLOAD DP -->
  <div class="pay-section <?= $step > 2 ? '' : 'active-pay' ?> mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 style="font-family:var(--font-display);color:var(--maroon);margin:0;">
        <i class="bi bi-1-circle me-2"></i>Down Payment (30%)
      </h5>
      <div>
        <?php if ($sudahDP && in_array($b['status'],['Confirmed','Completed'])): ?>
          <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Terverifikasi</span>
        <?php elseif ($sudahDP): ?>
          <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Menunggu Verifikasi</span>
        <?php else: ?>
          <span class="badge bg-danger"><i class="bi bi-exclamation-circle me-1"></i>Belum Dibayar</span>
        <?php endif; ?>
      </div>
    </div>

    <div class="p-3 rounded-xl mb-3" style="background:var(--maroon-pale);">
      <div class="d-flex justify-content-between align-items-center">
        <span style="font-size:0.85rem;color:#666;">Nominal yang harus ditransfer:</span>
        <span style="font-family:var(--font-display);font-size:1.5rem;color:var(--maroon);font-weight:700;"><?= formatRupiah($dp) ?></span>
      </div>
      <div style="font-size:0.75rem;color:#aaa;margin-top:4px;">Batas waktu: 24 jam setelah booking</div>
    </div>

    <?php if ($sudahDP): ?>
    <div class="text-center">
      <div style="font-size:0.82rem;color:#888;margin-bottom:8px;">Bukti yang diupload:</div>
      <img src="<?= UPLOAD_URL_BAYAR . htmlspecialchars($b['bukti_pembayaran']) ?>" class="bukti-thumb" alt="Bukti DP">
      <?php if (!in_array($b['status'],['Confirmed','Completed'])): ?>
      <div class="mt-3">
        <small style="color:#aaa;">Upload ulang jika gambar tidak jelas:</small>
        <form method="POST" enctype="multipart/form-data" class="mt-2">
          <?= csrfField() ?><input type="hidden" name="jenis" value="dp">
          <div class="d-flex gap-2 justify-content-center">
            <input type="file" name="bukti_pembayaran" class="form-control form-control-sm" accept="image/*" required style="max-width:260px;">
            <button type="submit" class="btn btn-sm btn-outline-maroon">Ganti</button>
          </div>
        </form>
      </div>
      <?php endif; ?>
    </div>
    <?php else: ?>
    <form method="POST" enctype="multipart/form-data">
      <?= csrfField() ?><input type="hidden" name="jenis" value="dp">
      <div class="drop-zone" id="dpZone" onclick="document.getElementById('dpFile').click()" ondragover="dragOver(event,'dpZone')" ondragleave="dragLeave('dpZone')" ondrop="dropFile(event,'dpFile','dpPreview','dpZone')">
        <i class="bi bi-cloud-upload"></i>
        <div style="font-size:0.88rem;color:#888;margin-top:8px;">Klik atau drag foto bukti transfer DP</div>
        <div style="font-size:0.75rem;color:#bbb;margin-top:4px;">JPG, PNG, WEBP · Maks. 5MB</div>
      </div>
      <input type="file" id="dpFile" name="bukti_pembayaran" accept="image/*" required style="display:none;" onchange="previewFile(this,'dpPreview')">
      <div class="text-center"><img id="dpPreview" class="bukti-thumb" style="display:none;" alt="Preview"></div>
      <div class="mt-3 d-flex gap-2">
        <a href="https://wa.me/6281234567890?text=<?= urlencode('Halo Admin, saya sudah transfer DP untuk booking '.$b['kode_booking'].'. Mohon dikonfirmasi.') ?>" target="_blank" class="btn btn-outline-maroon btn-sm">
          <i class="bi bi-whatsapp me-1"></i>Konfirmasi via WA
        </a>
        <button type="submit" class="btn btn-maroon flex-grow-1">
          <i class="bi bi-cloud-upload me-1"></i>Upload Bukti DP
        </button>
      </div>
    </form>
    <?php endif; ?>
  </div>

  <!-- BAGIAN 2: PELUNASAN -->
  <div class="pay-section <?= $step < 2 ? 'disabled' : 'active-pay' ?>">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 style="font-family:var(--font-display);color:var(--maroon);margin:0;">
        <i class="bi bi-2-circle me-2"></i>Pelunasan (70%)
      </h5>
      <div>
        <?php if ($sudahLunas && $b['status'] === 'Completed'): ?>
          <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Lunas</span>
        <?php elseif ($sudahLunas): ?>
          <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Menunggu Verifikasi</span>
        <?php elseif ($step >= 2): ?>
          <span class="badge bg-info text-dark"><i class="bi bi-clock-history me-1"></i>Jatuh Tempo H-7</span>
        <?php else: ?>
          <span class="badge bg-secondary"><i class="bi bi-lock me-1"></i>Belum Bisa Dilakukan</span>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($step < 2): ?>
    <div class="text-center py-4" style="color:#bbb;">
      <i class="bi bi-lock" style="font-size:2.5rem;opacity:.3;"></i>
      <p class="mt-2" style="font-size:0.85rem;">Pelunasan dapat dilakukan setelah DP dikonfirmasi oleh admin</p>
    </div>
    <?php else: ?>
    <div class="p-3 rounded-xl mb-3" style="background:var(--maroon-pale);">
      <div class="d-flex justify-content-between align-items-center">
        <span style="font-size:0.85rem;color:#666;">Nominal pelunasan:</span>
        <span style="font-family:var(--font-display);font-size:1.5rem;color:var(--maroon);font-weight:700;"><?= formatRupiah($pelunasan) ?></span>
      </div>
      <div style="font-size:0.75rem;color:#aaa;margin-top:4px;">
        Jatuh tempo: <?= date('d M Y', strtotime($b['tanggal_acara'] . ' -7 days')) ?> (H-7 acara)
      </div>
    </div>
    <?php if ($sudahLunas): ?>
    <div class="text-center">
      <div style="font-size:0.82rem;color:#888;margin-bottom:8px;">Bukti pelunasan yang diupload:</div>
      <img src="<?= UPLOAD_URL_BAYAR . htmlspecialchars($b['bukti_pelunasan']) ?>" class="bukti-thumb" alt="Bukti Pelunasan">
    </div>
    <?php else: ?>
    <form method="POST" enctype="multipart/form-data">
      <?= csrfField() ?><input type="hidden" name="jenis" value="pelunasan">
      <div class="drop-zone" id="plZone" onclick="document.getElementById('plFile').click()" ondragover="dragOver(event,'plZone')" ondragleave="dragLeave('plZone')" ondrop="dropFile(event,'plFile','plPreview','plZone')">
        <i class="bi bi-cloud-upload"></i>
        <div style="font-size:0.88rem;color:#888;margin-top:8px;">Klik atau drag foto bukti transfer Pelunasan</div>
        <div style="font-size:0.75rem;color:#bbb;margin-top:4px;">JPG, PNG, WEBP · Maks. 5MB</div>
      </div>
      <input type="file" id="plFile" name="bukti_pelunasan" accept="image/*" required style="display:none;" onchange="previewFile(this,'plPreview')">
      <div class="text-center"><img id="plPreview" class="bukti-thumb" style="display:none;" alt="Preview"></div>
      <div class="mt-3 d-flex gap-2">
        <a href="https://wa.me/6281234567890?text=<?= urlencode('Halo Admin, saya sudah melakukan pelunasan untuk booking '.$b['kode_booking'].'. Mohon dikonfirmasi.') ?>" target="_blank" class="btn btn-outline-maroon btn-sm">
          <i class="bi bi-whatsapp me-1"></i>Konfirmasi via WA
        </a>
        <button type="submit" class="btn btn-maroon flex-grow-1">
          <i class="bi bi-cloud-upload me-1"></i>Upload Bukti Pelunasan
        </button>
      </div>
    </form>
    <?php endif; ?>
    <?php endif; ?>
  </div>

  <!-- Catatan Admin -->
  <?php if ($b['catatan_admin']): ?>
  <div class="mt-3 p-3 rounded-xl" style="background:#fff8e1;border:1px solid #ffe082;">
    <div style="font-size:0.8rem;font-weight:600;color:#f57c00;margin-bottom:6px;"><i class="bi bi-chat-square-text me-1"></i>Catatan dari Admin</div>
    <div style="font-size:0.85rem;color:#555;"><?= nl2br(htmlspecialchars($b['catatan_admin'])) ?></div>
  </div>
  <?php endif; ?>

</div><!-- /col -->
</div><!-- /row -->
</div>
</section>

<?php include '../includes/footer.php'; ?>
<a href="https://wa.me/6281234567890?text=<?= urlencode('Halo Admin, saya ingin menanyakan status pembayaran booking '.$b['kode_booking'].'.') ?>" target="_blank" class="wa-float"><i class="bi bi-whatsapp"></i></a>
<div class="copy-toast" id="copyToast">✓ Nomor rekening disalin!</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function previewFile(input, previewId) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        const img = document.getElementById(previewId);
        img.src = e.target.result; img.style.display = 'block';
    };
    reader.readAsDataURL(file);
}
function dragOver(e, zoneId) { e.preventDefault(); document.getElementById(zoneId).classList.add('dragover'); }
function dragLeave(zoneId) { document.getElementById(zoneId).classList.remove('dragover'); }
function dropFile(e, fileId, previewId, zoneId) {
    e.preventDefault(); dragLeave(zoneId);
    const dt = e.dataTransfer;
    const input = document.getElementById(fileId);
    const file = dt.files[0];
    if (!file) return;
    const newDt = new DataTransfer(); newDt.items.add(file);
    input.files = newDt.files;
    previewFile(input, previewId);
}
function copyRek(nomor, id) {
    navigator.clipboard.writeText(nomor.replace(/\s/g,'')).then(() => {
        const t = document.getElementById('copyToast');
        t.style.display = 'block';
        setTimeout(() => t.style.display = 'none', 2000);
    });
}
</script>
</body>
</html>
