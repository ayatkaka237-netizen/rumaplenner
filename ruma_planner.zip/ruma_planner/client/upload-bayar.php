<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireClient();

$booking_id = (int)($_GET['id'] ?? 0);
if (!$booking_id) { header('Location: ' . BASE_URL . 'client/riwayat.php'); exit(); }

$stmt = $pdo->prepare("SELECT b.*, p.nama_paket, p.harga FROM booking b JOIN paket p ON b.id_paket=p.id WHERE b.id=? AND b.id_user=?");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch();
if (!$booking) { header('Location: ' . BASE_URL . 'client/riwayat.php'); exit(); }

$error = '';
showFlash();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    if (!isset($_FILES['bukti_pembayaran']) || $_FILES['bukti_pembayaran']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Silakan pilih file bukti pembayaran.';
    } else {
        $upload = uploadImage($_FILES['bukti_pembayaran'], UPLOAD_BAYAR, 'bayar');
        if (!$upload['success']) {
            $error = $upload['message'];
        } else {
            // Delete old file
            if ($booking['bukti_pembayaran'] && file_exists(UPLOAD_BAYAR . $booking['bukti_pembayaran'])) {
                unlink(UPLOAD_BAYAR . $booking['bukti_pembayaran']);
            }
            $filename = $upload['filename'];
            $stmt = $pdo->prepare("UPDATE booking SET bukti_pembayaran=?, status='Pending' WHERE id=?");
            if ($stmt->execute([$filename, $booking_id])) {
                setFlash('success', 'Bukti pembayaran berhasil diupload! Menunggu verifikasi admin.');
                header('Location: ' . BASE_URL . 'client/riwayat.php');
                exit();
            } else {
                $error = 'Gagal menyimpan. Silakan coba lagi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Pembayaran — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <h1>Upload Bukti Pembayaran</h1>
        <p style="color:rgba(255,255,255,0.75);">Kode Booking: <strong><?= htmlspecialchars($booking['kode_booking']) ?></strong></p>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">

                <!-- Booking Info -->
                <div class="p-4 rounded-xl mb-4" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:white;">
                    <div class="row">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <div style="font-size:0.75rem;opacity:0.7;text-transform:uppercase;letter-spacing:0.5px;">Paket</div>
                            <div style="font-weight:600;"><?= htmlspecialchars($booking['nama_paket']) ?></div>
                        </div>
                        <div class="col-md-6">
                            <div style="font-size:0.75rem;opacity:0.7;text-transform:uppercase;letter-spacing:0.5px;">Mempelai</div>
                            <div style="font-weight:600;"><?= htmlspecialchars($booking['nama_mempelai_pria']) ?> & <?= htmlspecialchars($booking['nama_mempelai_wanita']) ?></div>
                        </div>
                        <div class="col-12 mt-3">
                            <hr style="border-color:rgba(255,255,255,0.15);margin:0 0 12px;">
                        </div>
                        <div class="col-md-4">
                            <div style="font-size:0.75rem;opacity:0.7;">Total Harga</div>
                            <div style="font-family:var(--font-display);font-size:1.1rem;"><?= formatRupiah($booking['total_harga']) ?></div>
                        </div>
                        <div class="col-md-4">
                            <div style="font-size:0.75rem;opacity:0.7;">Bayar DP (30%)</div>
                            <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--gold);font-weight:700;"><?= formatRupiah($booking['dp_amount']) ?></div>
                        </div>
                        <div class="col-md-4">
                            <div style="font-size:0.75rem;opacity:0.7;">Status</div>
                            <div><?= statusBadge($booking['status']) ?></div>
                        </div>
                    </div>
                </div>

                <!-- Rekening Info -->
                <div class="p-4 rounded-xl mb-4" style="background:var(--maroon-pale);border:1px solid rgba(105,27,27,0.15);">
                    <h6 style="font-family:var(--font-display);color:var(--maroon);font-size:1.1rem;margin-bottom:16px;">
                        <i class="bi bi-bank me-2"></i>Transfer ke Rekening
                    </h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div style="background:white;padding:16px;border-radius:10px;text-align:center;">
                                <div style="font-size:0.75rem;color:#888;margin-bottom:4px;">BCA</div>
                                <div style="font-size:1.3rem;font-weight:700;color:var(--maroon);letter-spacing:2px;">1234 5678 90</div>
                                <div style="font-size:0.82rem;color:#666;">a.n. <?= OWNER ?></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div style="background:white;padding:16px;border-radius:10px;text-align:center;">
                                <div style="font-size:0.75rem;color:#888;margin-bottom:4px;">Mandiri</div>
                                <div style="font-size:1.3rem;font-weight:700;color:var(--maroon);letter-spacing:2px;">098 765 4321</div>
                                <div style="font-size:0.82rem;color:#666;">a.n. <?= OWNER ?></div>
                            </div>
                        </div>
                    </div>
                    <p style="font-size:0.82rem;color:#777;margin-top:12px;margin-bottom:0;">
                        <i class="bi bi-info-circle me-1"></i>Transfer sesuai jumlah DP, kemudian upload screenshot/foto bukti transfer di bawah.
                    </p>
                </div>

                <!-- Upload Form -->
                <div class="form-card">
                    <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:20px;">
                        <i class="bi bi-upload me-2"></i>Upload Bukti Transfer
                    </h5>

                    <?php if ($error): ?>
                    <div class="alert alert-danger"><i class="bi bi-exclamation-circle me-2"></i><?= $error ?></div>
                    <?php endif; ?>

                    <?php if ($booking['bukti_pembayaran']): ?>
                    <div class="mb-4">
                        <p class="form-label">Bukti yang sudah diupload:</p>
                        <img src="<?= UPLOAD_URL_BAYAR . htmlspecialchars($booking['bukti_pembayaran']) ?>"
                             alt="Bukti Pembayaran" class="img-thumbnail" style="max-height:200px;">
                        <p class="text-muted mt-2" style="font-size:0.82rem;">Upload ulang untuk mengganti gambar.</p>
                    </div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <?= csrfField() ?>
                        <div class="mb-4">
                            <label class="form-label">File Bukti Pembayaran <span class="text-danger">*</span></label>
                            <input type="file" name="bukti_pembayaran" class="form-control file-with-preview"
                                   data-preview="previewImg" accept="image/jpeg,image/png,image/jpg,image/webp"
                                   <?= !$booking['bukti_pembayaran'] ? 'required' : '' ?>>
                            <div class="form-text">Format: JPG, PNG, WEBP. Maksimal 5MB.</div>
                        </div>
                        <div class="mb-4 text-center" id="previewContainer" style="display:none;">
                            <img id="previewImg" src="" alt="Preview" class="img-thumbnail" style="max-height:250px;display:none;">
                        </div>
                        <div class="d-flex gap-3">
                            <a href="<?= BASE_URL ?>client/riwayat.php" class="btn btn-outline-maroon">
                                <i class="bi bi-arrow-left me-2"></i>Riwayat
                            </a>
                            <button type="submit" class="btn btn-maroon flex-grow-1">
                                <i class="bi bi-cloud-upload me-2"></i>Upload Sekarang
                            </button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
// Show preview container when image selected
document.querySelector('.file-with-preview').addEventListener('change', function() {
    document.getElementById('previewContainer').style.display = 'block';
});
</script>
</body>
</html>
