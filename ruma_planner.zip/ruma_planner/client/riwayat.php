<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireClient();

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT b.*, p.nama_paket, p.kategori FROM booking b JOIN paket p ON b.id_paket=p.id WHERE b.id_user=? ORDER BY b.created_at DESC");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Saya — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <h1>Pesanan Saya</h1>
        <p style="color:rgba(255,255,255,0.75);">Halo, <?= htmlspecialchars($_SESSION['nama']) ?>! Berikut riwayat pemesanan Anda.</p>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <?php showFlash(); ?>

        <?php if (empty($bookings)): ?>
        <div class="text-center py-5">
            <i class="bi bi-calendar-x" style="font-size:4rem;color:#ddd;"></i>
            <h4 class="mt-3" style="color:#aaa;">Belum ada pesanan</h4>
            <p style="color:#bbb;">Yuk, mulai rencanakan pernikahan impian Anda!</p>
            <a href="<?= BASE_URL ?>paket.php" class="btn btn-maroon mt-2">Lihat Paket Wedding</a>
        </div>
        <?php else: ?>
        <div class="row g-4">
            <?php foreach ($bookings as $b): ?>
            <div class="col-12">
                <div class="form-card" style="padding:0;overflow:hidden;">
                    <div class="row g-0">
                        <!-- Left color bar -->
                        <div class="col-auto" style="width:6px;background:var(--maroon);"></div>
                        <div class="col p-4">
                            <div class="row align-items-start g-3">
                                <div class="col-md-7">
                                    <div class="d-flex align-items-center gap-3 mb-2">
                                        <span style="font-family:var(--font-display);font-size:1.2rem;color:var(--maroon);font-weight:600;">
                                            <?= htmlspecialchars($b['nama_mempelai_pria']) ?> & <?= htmlspecialchars($b['nama_mempelai_wanita']) ?>
                                        </span>
                                        <?= statusBadge($b['status']) ?>
                                    </div>
                                    <div class="d-flex flex-wrap gap-3 mb-2">
                                        <span style="font-size:0.83rem;color:#777;">
                                            <i class="bi bi-tag me-1 text-maroon"></i><?= htmlspecialchars($b['nama_paket']) ?>
                                        </span>
                                        <span style="font-size:0.83rem;color:#777;">
                                            <i class="bi bi-calendar3 me-1 text-maroon"></i><?= date('d F Y', strtotime($b['tanggal_acara'])) ?>
                                        </span>
                                        <span style="font-size:0.83rem;color:#777;">
                                            <i class="bi bi-people me-1 text-maroon"></i><?= $b['jumlah_tamu'] ?> tamu
                                        </span>
                                    </div>
                                    <div style="font-size:0.83rem;color:#888;">
                                        <i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars(substr($b['lokasi'], 0, 70)) ?>...
                                    </div>
                                    <div style="font-size:0.78rem;color:#aaa;margin-top:8px;">
                                        Kode: <strong style="color:var(--maroon);"><?= htmlspecialchars($b['kode_booking']) ?></strong>
                                        · Dipesan <?= date('d M Y', strtotime($b['created_at'])) ?>
                                    </div>
                                </div>
                                <div class="col-md-3 text-md-center">
                                    <div style="font-size:0.75rem;color:#aaa;margin-bottom:4px;">Total Harga</div>
                                    <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);font-weight:700;"><?= formatRupiah($b['total_harga']) ?></div>
                                    <div style="font-size:0.78rem;color:#888;">DP: <?= formatRupiah($b['dp_amount']) ?></div>
                                    <?php if ($b['bukti_pembayaran']): ?>
                                        <div class="mt-1"><span class="badge bg-success" style="font-size:0.72rem;"><i class="bi bi-check2 me-1"></i>Bukti Terupload</span></div>
                                    <?php else: ?>
                                        <div class="mt-1"><span class="badge bg-warning text-dark" style="font-size:0.72rem;"><i class="bi bi-exclamation me-1"></i>Belum Upload</span></div>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-2 d-flex flex-column gap-2">
                                    <a href="pembayaran.php?id=<?= $b['id'] ?>" class="btn btn-maroon btn-sm">
                                        <?php if ($b['status']==='Completed'): ?>
                                        <i class="bi bi-receipt me-1"></i>Lihat Pembayaran
                                        <?php elseif ($b['status']==='Confirmed'): ?>
                                        <i class="bi bi-credit-card me-1"></i>Bayar Pelunasan
                                        <?php else: ?>
                                        <i class="bi bi-upload me-1"></i>Upload Pembayaran
                                        <?php endif; ?>
                                    </a>
                                    <?php if ($b['catatan_admin']): ?>
                                    <button class="btn btn-outline-maroon btn-sm" data-bs-toggle="modal" data-bs-target="#modalCatatan<?= $b['id'] ?>">
                                        <i class="bi bi-chat-text me-1"></i>Catatan Admin
                                    </button>
                                    <!-- Modal Catatan Admin -->
                                    <div class="modal fade" id="modalCatatan<?= $b['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header" style="background:var(--maroon);color:white;">
                                                    <h5 class="modal-title"><i class="bi bi-chat-text me-2"></i>Catatan dari Admin</h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><?= nl2br(htmlspecialchars($b['catatan_admin'])) ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="text-center mt-5">
            <a href="<?= BASE_URL ?>paket.php" class="btn btn-outline-maroon">
                <i class="bi bi-plus-circle me-2"></i>Pesan Paket Lain
            </a>
        </div>
    </div>
</section>


<!-- Vendor Bookings -->
<?php
$vb = $pdo->prepare("
    SELECT vb.*, v.nama AS vendor_nama, vk.nama AS kategori, vk.icon, v.no_wa
    FROM vendor_booking vb
    JOIN vendor v ON vb.id_vendor=v.id
    JOIN vendor_kategori vk ON v.id_kategori=vk.id
    WHERE vb.id_user=?
    ORDER BY vb.created_at DESC
");
$vb->execute([$_SESSION['user_id']]);
$vbList = $vb->fetchAll();
?>
<?php if (!empty($vbList)): ?>
<section class="section-padding pt-0">
<div class="container">
<div class="form-card">
  <h4 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:20px;"><i class="bi bi-people me-2"></i>Booking Vendor Saya</h4>
  <div class="table-responsive">
  <table class="table table-hover">
  <thead style="background:var(--maroon-pale);"><tr><th>Vendor</th><th>Kategori</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($vbList as $vb): ?>
  <tr>
    <td><strong><?= htmlspecialchars($vb['vendor_nama']) ?></strong></td>
    <td><span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= htmlspecialchars($vb['kategori']) ?></span></td>
    <td><?= date('d M Y', strtotime($vb['tanggal'])) ?></td>
    <td><?php $colors=['pending'=>'warning','confirmed'=>'success','cancelled'=>'danger']; ?><span class="badge bg-<?= $colors[$vb['status']] ?>"><?= ucfirst($vb['status']) ?></span></td>
    <td><a href="https://wa.me/<?= preg_replace('/[^0-9]/','', $vb['no_wa']) ?>?text=<?= urlencode('Halo, saya ingin konfirmasi booking vendor untuk tanggal '.$vb['tanggal'].'. Mohon bantuannya.') ?>" target="_blank" class="btn btn-sm" style="background:#25D366;color:#fff;"><i class="bi bi-whatsapp me-1"></i>Konfirmasi</a></td>
  </tr>
  <?php endforeach; ?>
  </tbody>
  </table>
  </div>
</div>
</div>
</section>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
