<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . 'index.php');
    exit();
}

$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $nama     = trim($_POST['nama'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $no_hp    = trim($_POST['no_hp'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    // Validasi
    if (empty($nama) || empty($username) || empty($email) || empty($password)) {
        $error = 'Semua field wajib diisi.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
        $error = 'Username hanya boleh huruf, angka, underscore (3–30 karakter).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } elseif ($password !== $confirm) {
        $error = 'Konfirmasi password tidak cocok.';
    } else {
        // Cek duplikat
        $check = $pdo->prepare("SELECT id FROM users WHERE username=? OR email=?");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            $error = 'Username atau email sudah terdaftar.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (nama, username, email, password, no_hp, role) VALUES (?,?,?,?,?,'client')");
            if ($stmt->execute([$nama, $username, $email, $hashed, $no_hp])) {
                setFlash('success', 'Registrasi berhasil! Silakan masuk dengan akun Anda.');
                header('Location: ' . BASE_URL . 'login.php');
                exit();
            } else {
                $error = 'Terjadi kesalahan. Silakan coba lagi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card" style="max-width:520px;">
        <div class="text-center mb-4">
            <a href="<?= BASE_URL ?>index.php">
                <img src="<?= BASE_URL ?>assets/images/logo.jpg" alt="Ruma Planner" class="auth-logo">
            </a>
            <h2 class="auth-title">Buat Akun Baru</h2>
            <p style="color:#888;font-size:0.9rem;">Daftarkan diri Anda untuk memesan paket wedding</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <?= csrfField() ?>
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" name="nama" class="form-control" placeholder="Nama lengkap Anda"
                           value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Username <span class="text-danger">*</span></label>
                    <input type="text" name="username" class="form-control" placeholder="username_unik"
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                    <div class="form-text">Huruf, angka, underscore. 3–30 karakter.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">No. HP</label>
                    <input type="text" name="no_hp" class="form-control" placeholder="08xxxxxxxxxx"
                           value="<?= htmlspecialchars($_POST['no_hp'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Email <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control" placeholder="email@contoh.com"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Password <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="password" name="password" id="pw1" class="form-control auth-pass"
                               placeholder="Min. 6 karakter" required minlength="6">
                        <span class="input-group-text auth-icon" style="cursor:pointer;" onclick="togglePassword('pw1','icon1')">
                            <i class="bi bi-eye" id="icon1" style="color:#888;"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Konfirmasi Password <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="password" name="confirm_password" id="pw2" class="form-control auth-pass"
                               placeholder="Ulangi password" required>
                        <span class="input-group-text auth-icon" style="cursor:pointer;" onclick="togglePassword('pw2','icon2')">
                            <i class="bi bi-eye" id="icon2" style="color:#888;"></i>
                        </span>
                    </div>
                </div>
                <div class="col-12 mt-2">
                    <div class="d-grid">
                        <button type="submit" class="btn btn-maroon" style="padding:14px;">
                            <i class="bi bi-person-plus me-2"></i>Daftar Sekarang
                        </button>
                    </div>
                </div>
            </div>
        </form>

        <div class="mt-4 text-center" style="border-top:1px solid #f0eeec;padding-top:16px;">
            <p style="font-size:0.88rem;color:#888;margin:0;">
                Sudah punya akun?
                <a href="<?= BASE_URL ?>login.php" style="color:var(--maroon);font-weight:600;text-decoration:none;">Masuk Sekarang</a>
            </p>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePassword(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);
    if (input.type === 'password') { input.type = 'text'; icon.className = 'bi bi-eye-slash'; }
    else { input.type = 'password'; icon.className = 'bi bi-eye'; }
}
</script>
</body>
</html>
