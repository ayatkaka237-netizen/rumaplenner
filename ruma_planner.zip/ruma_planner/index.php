<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

// Ambil paket unggulan
$paket_result = $pdo->query("SELECT * FROM paket WHERE is_active=1 ORDER BY harga LIMIT 4");
$pakets = $paket_result->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> — <?= SITE_TAGLINE ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<!-- HERO -->
<section class="hero-section" id="beranda">
    <div class="hero-ornament"></div>
    <div class="container hero-content">
        <div class="row">
            <div class="col-lg-7">
                <img src="<?= BASE_URL ?>assets/images/logo.jpg" alt="Ruma Planner" class="hero-logo fade-in-up">
                <span class="hero-tagline fade-in-up delay-1"><?= SITE_TAGLINE ?></span>
                <h1 class="hero-title fade-in-up delay-2">
                    Wujudkan<br>Pernikahan<br><span style="color:var(--gold)">Impian Anda</span>
                </h1>
                <p class="hero-desc fade-in-up delay-3">
                    Kami hadir untuk menjadikan hari terbahagia dalam hidup Anda menjadi momen yang tak terlupakan. Dengan sentuhan elegan dan layanan profesional terbaik.
                </p>
                <div class="d-flex gap-3 flex-wrap fade-in-up delay-4">
                    <a href="paket.php" class="btn btn-gold">
                        <i class="bi bi-heart me-2"></i>Lihat Paket Wedding
                    </a>
                    <a href="kontak.php" class="btn btn-outline-light">
                        <i class="bi bi-chat me-2"></i>Konsultasi Gratis
                    </a>
                </div>
                <div class="hero-stats fade-in-up delay-5">
                    <div class="stat-item">
                        <div class="stat-num"><span class="counter" data-target="150">0</span>+</div>
                        <div class="stat-label">Event Sukses</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-num"><span class="counter" data-target="5">0</span></div>
                        <div class="stat-label">Tahun Pengalaman</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-num"><span class="counter" data-target="98">0</span>%</div>
                        <div class="stat-label">Kepuasan Klien</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- LAYANAN -->
<section class="section-padding bg-white">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle">Apa yang Kami Tawarkan</span>
            <h2 class="section-title">Layanan Unggulan Kami</h2>
            <div class="divider-gold"></div>
        </div>
        <div class="row g-4">
            <?php
            $services = [
                ['icon' => 'bi-flower1', 'title' => 'Dekorasi Elegan', 'desc' => 'Dekorasi premium dengan sentuhan artistik yang disesuaikan dengan tema dan keinginan Anda.'],
                ['icon' => 'bi-camera-video', 'title' => 'Dokumentasi Premium', 'desc' => 'Tim fotografer dan videografer profesional untuk mengabadikan setiap momen berharga.'],
                ['icon' => 'bi-people', 'title' => 'Koordinator Acara', 'desc' => 'Tim koordinator berpengalaman yang memastikan setiap detail berjalan sempurna.'],
                ['icon' => 'bi-cup-hot', 'title' => 'Catering Premium', 'desc' => 'Sajian kuliner berkualitas tinggi dengan menu yang dapat disesuaikan selera tamu.'],
                ['icon' => 'bi-music-note-beamed', 'title' => 'Entertainment', 'desc' => 'Hiburan pilihan dari band live, DJ, hingga pertunjukan seni tradisional.'],
                ['icon' => 'bi-chat-heart', 'title' => 'Konsultasi Gratis', 'desc' => 'Sesi konsultasi tanpa biaya untuk merencanakan hari pernikahan impian Anda.'],
            ];
            foreach ($services as $s):
            ?>
            <div class="col-md-4 col-sm-6">
                <div class="text-center p-4 rounded-xl h-100" style="border:1px solid rgba(105,27,27,0.08);transition:all .3s ease;" 
                     onmouseover="this.style.background='#f5e8e8';this.style.borderColor='rgba(105,27,27,0.2)'" 
                     onmouseout="this.style.background='';this.style.borderColor='rgba(105,27,27,0.08)'">
                    <div class="mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle" 
                         style="width:64px;height:64px;background:var(--maroon-pale);">
                        <i class="bi <?= $s['icon'] ?>" style="font-size:1.6rem;color:var(--maroon);"></i>
                    </div>
                    <h5 class="mb-2" style="font-family:var(--font-display);color:var(--maroon);"><?= $s['title'] ?></h5>
                    <p class="mb-0" style="font-size:0.88rem;color:#666;"><?= $s['desc'] ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- PAKET WEDDING -->
<section class="section-padding" style="background:var(--off-white);">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle">Pilihan Terbaik untuk Anda</span>
            <h2 class="section-title">Paket Wedding Kami</h2>
            <div class="divider-gold"></div>
            <p class="text-muted mt-3">Pilih paket yang sesuai dengan impian dan anggaran Anda</p>
        </div>
        <div class="row g-4">
            <?php foreach ($pakets as $p): ?>
            <div class="col-lg-3 col-md-6">
                <div class="paket-card">
                    <div class="paket-card-img">
                        <?php if ($p['foto'] && file_exists(UPLOAD_PAKET . $p['foto'])): ?>
                            <img src="<?= UPLOAD_URL_PAKET . htmlspecialchars($p['foto']) ?>" alt="<?= htmlspecialchars($p['nama_paket']) ?>">
                        <?php else: ?>
                            <div class="paket-card-img-placeholder text-center">
                                <i class="bi bi-house-heart" style="font-size:3rem;color:rgba(255,255,255,0.4);display:block;"></i>
                                <div style="color:rgba(255,255,255,0.5);font-size:0.75rem;margin-top:8px;">Ruma Planner</div>
                            </div>
                        <?php endif; ?>
                        <span class="badge-kategori"><?= htmlspecialchars($p['kategori']) ?></span>
                    </div>
                    <div class="paket-card-body">
                        <h5 class="paket-card-title"><?= htmlspecialchars($p['nama_paket']) ?></h5>
                        <div class="paket-harga"><?= formatRupiah($p['harga']) ?> <small>/ Acara</small></div>
                        <p style="font-size:0.85rem;color:#666;margin-bottom:12px;">Max <?= $p['max_tamu'] ?> tamu</p>
                        <?php
                        $fasilitas = explode('|', $p['fasilitas']);
                        $max_show = 4;
                        ?>
                        <ul class="fasilitas-list">
                            <?php foreach (array_slice($fasilitas, 0, $max_show) as $f): ?>
                                <li><?= htmlspecialchars(trim($f)) ?></li>
                            <?php endforeach; ?>
                            <?php if (count($fasilitas) > $max_show): ?>
                                <li style="color:var(--maroon);font-weight:500;">+<?= count($fasilitas) - $max_show ?> lainnya...</li>
                            <?php endif; ?>
                        </ul>
                        <div class="d-grid gap-2 mt-3">
                            <a href="detail-paket.php?id=<?= $p['id'] ?>" class="btn btn-outline-maroon btn-sm">Lihat Detail</a>
                            <a href="<?= isLoggedIn() ? 'client/form-booking.php?paket=' . $p['id'] : 'login.php' ?>" class="btn btn-maroon btn-sm">Pesan Sekarang</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-5">
            <a href="paket.php" class="btn btn-maroon">
                <i class="bi bi-grid me-2"></i>Lihat Semua Paket
            </a>
        </div>
    </div>
</section>

<!-- TENTANG -->
<section class="section-padding bg-white" id="tentang">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-5">
                <div class="position-relative">
                    <div style="background:linear-gradient(135deg,var(--maroon),var(--maroon-light));border-radius:20px;padding:50px 40px;text-align:center;color:white;">
                        <img src="<?= BASE_URL ?>assets/images/logo.jpg" alt="Ruma Planner" style="width:140px;margin-bottom:24px;">
                        <h3 style="font-family:var(--font-script);font-size:2rem;color:var(--gold);"><?= SITE_TAGLINE ?></h3>
                        <p style="opacity:0.85;margin-top:12px;">Dipercaya oleh ratusan pasangan untuk mewujudkan hari paling berkesan dalam hidup mereka.</p>
                    </div>
                    <div style="position:absolute;top:-20px;right:-20px;width:80px;height:80px;background:var(--gold);border-radius:50%;opacity:0.15;"></div>
                    <div style="position:absolute;bottom:-15px;left:-15px;width:60px;height:60px;background:var(--maroon);border-radius:50%;opacity:0.15;"></div>
                </div>
            </div>
            <div class="col-lg-7">
                <span class="section-subtitle">Kenali Kami Lebih Dekat</span>
                <h2 class="section-title">Tentang Ruma Planner</h2>
                <div class="divider-gold" style="margin:16px 0;"></div>
                <p style="color:#666;line-height:1.9;margin-bottom:16px;">
                    <strong>Ruma Planner</strong> adalah wedding organizer profesional yang didirikan dengan satu tujuan: menjadikan hari pernikahan Anda sebagai momen terindah yang akan selalu dikenang seumur hidup.
                </p>
                <p style="color:#666;line-height:1.9;margin-bottom:24px;">
                    Dipimpin oleh <strong><?= OWNER ?></strong>, kami telah dipercaya mengelola lebih dari 150 pernikahan dengan tingkat kepuasan klien 98%. Setiap detail kami perhatikan dengan penuh cinta dan dedikasi.
                </p>
                <div class="row g-3 mb-4">
                    <?php
                    $keunggulan = [
                        ['icon'=>'bi-award','text'=>'Tim Berpengalaman 5+ Tahun'],
                        ['icon'=>'bi-shield-check','text'=>'Bergaransi & Terpercaya'],
                        ['icon'=>'bi-patch-check','text'=>'Paket Transparan & Fleksibel'],
                        ['icon'=>'bi-headset','text'=>'Layanan 24/7 Siap Membantu'],
                    ];
                    foreach ($keunggulan as $k):
                    ?>
                    <div class="col-6">
                        <div class="d-flex gap-2 align-items-center">
                            <i class="bi <?= $k['icon'] ?>" style="color:var(--maroon);font-size:1.1rem;min-width:24px;"></i>
                            <span style="font-size:0.88rem;"><?= $k['text'] ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <a href="kontak.php" class="btn btn-maroon">
                    <i class="bi bi-chat-dots me-2"></i>Konsultasi Sekarang
                </a>
            </div>
        </div>
    </div>
</section>


<!-- VENDOR HIGHLIGHT -->
<section class="section-padding" style="background:var(--off-white);">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle">Mitra Terpercaya Kami</span>
            <h2 class="section-title">Direktori Vendor Wedding</h2>
            <div class="divider-gold"></div>
            <p class="text-muted mt-3">Temukan vendor terbaik untuk melengkapi hari pernikahan impian Anda</p>
        </div>
        <?php
        $kategoriHighlight = $pdo->query("SELECT vk.*, COUNT(v.id) AS jumlah FROM vendor_kategori vk LEFT JOIN vendor v ON v.id_kategori=vk.id AND v.is_active=1 GROUP BY vk.id ORDER BY vk.urutan LIMIT 8")->fetchAll();
        ?>
        <div class="row g-3 mb-5">
            <?php foreach ($kategoriHighlight as $kat): ?>
            <div class="col-6 col-md-3">
                <a href="vendor.php?kategori=<?= $kat['slug'] ?>" class="d-flex align-items-center gap-3 p-3 rounded-xl text-decoration-none" style="background:#fff;border:1px solid rgba(105,27,27,0.07);transition:var(--transition);" onmouseover="this.style.background='var(--maroon-pale)';this.style.borderColor='var(--maroon)'" onmouseout="this.style.background='#fff';this.style.borderColor='rgba(105,27,27,0.07)'">
                    <div style="width:48px;height:48px;background:var(--maroon-pale);border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                        <i class="bi <?= htmlspecialchars($kat['icon']) ?>" style="font-size:1.3rem;color:var(--maroon);"></i>
                    </div>
                    <div>
                        <div style="font-weight:600;font-size:0.88rem;color:var(--text-dark);"><?= htmlspecialchars($kat['nama']) ?></div>
                        <div style="font-size:0.75rem;color:var(--maroon);"><?= $kat['jumlah'] ?> vendor</div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php
        $topVendors = $pdo->query("SELECT v.*, vk.nama AS nama_kategori, vk.icon AS kategori_icon FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id WHERE v.is_active=1 ORDER BY v.rating DESC, v.total_booking DESC LIMIT 3")->fetchAll();
        ?>
        <div class="row g-4">
            <?php foreach ($topVendors as $tv): ?>
            <div class="col-md-4">
                <div style="background:#fff;border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-sm);border:1px solid rgba(105,27,27,0.07);transition:var(--transition);" onmouseover="this.style.transform='translateY(-4px)';this.style.boxShadow='var(--shadow-md)'" onmouseout="this.style.transform='';this.style.boxShadow='var(--shadow-sm)'">
                    <div style="height:140px;background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));display:flex;align-items:center;justify-content:center;position:relative;">
                        <i class="bi <?= htmlspecialchars($tv['kategori_icon']) ?>" style="font-size:3rem;color:rgba(255,255,255,0.25);"></i>
                        <?php if ($tv['badge']): ?><span style="position:absolute;top:10px;left:10px;background:var(--gold);color:#fff;padding:3px 10px;border-radius:50px;font-size:0.68rem;font-weight:700;"><?= htmlspecialchars($tv['badge']) ?></span><?php endif; ?>
                    </div>
                    <div style="padding:18px;">
                        <div style="font-size:0.72rem;color:var(--maroon);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;"><?= htmlspecialchars($tv['nama_kategori']) ?></div>
                        <h5 style="font-family:var(--font-display);color:var(--text-dark);margin-bottom:6px;"><?= htmlspecialchars($tv['nama']) ?></h5>
                        <div style="color:var(--gold);font-size:0.85rem;margin-bottom:10px;"><?php for($i=1;$i<=5;$i++) echo $i<=$tv['rating']?'★':'☆'; ?> <small style="color:#888;">(<?= $tv['total_review'] ?>)</small></div>
                        <div style="font-family:var(--font-display);font-size:1.2rem;color:var(--maroon);font-weight:700;margin-bottom:12px;"><?= formatRupiah($tv['harga_mulai']) ?></div>
                        <a href="vendor-detail.php?id=<?= $tv['id'] ?>" class="btn btn-maroon btn-sm w-100">Lihat Detail & Kalender</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-5">
            <a href="vendor.php" class="btn btn-maroon"><i class="bi bi-grid me-2"></i>Lihat Semua Vendor</a>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="section-padding" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));">
    <div class="container text-center">
        <span class="section-subtitle">Mulai Perjalanan Anda</span>
        <h2 class="section-title" style="color:white;">Siap Merencanakan Hari Istimewa Anda?</h2>
        <p style="color:rgba(255,255,255,0.8);max-width:500px;margin:16px auto 32px;">
            Hubungi kami sekarang dan dapatkan konsultasi gratis untuk merancang pernikahan impian Anda bersama Ruma Planner.
        </p>
        <div class="d-flex gap-3 justify-content-center flex-wrap">
            <a href="paket.php" class="btn btn-gold">
                <i class="bi bi-heart me-2"></i>Pilih Paket
            </a>
            <a href="kontak.php" class="btn btn-outline-light">
                <i class="bi bi-whatsapp me-2"></i>Chat WhatsApp
            </a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

<!-- Floating WhatsApp -->
<a href="https://wa.me/6281234567890?text=Halo%2C%20saya%20ingin%20bertanya%20mengenai%20paket%20wedding%20Ruma%20Planner." target="_blank" class="wa-float" title="Chat Admin Ruma Planner"><i class="bi bi-whatsapp"></i></a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
