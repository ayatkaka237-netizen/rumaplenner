<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

$kategori_filter = trim($_GET['kategori'] ?? '');
$harga_max       = (int)($_GET['harga_max'] ?? 0);
$sort            = trim($_GET['sort'] ?? 'harga_asc');

$params = [];
$where  = "WHERE is_active=1";
$allowedKat = ['Intimate','Reguler','Premium','Exclusive'];
if ($kategori_filter && in_array($kategori_filter, $allowedKat)) {
    $where .= " AND kategori=?";
    $params[] = $kategori_filter;
}
if ($harga_max > 0) {
    $where .= " AND harga<=?";
    $params[] = $harga_max;
}
$order = match($sort) {
    'harga_desc' => 'ORDER BY harga DESC',
    'nama_asc'   => 'ORDER BY nama_paket ASC',
    default      => 'ORDER BY harga ASC',
};

$stmt = $pdo->prepare("SELECT * FROM paket $where $order");
$stmt->execute($params);
$pakets = $stmt->fetchAll();
$kategori_list = $allowedKat;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paket Wedding — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <nav aria-label="breadcrumb" class="mb-3">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Beranda</a></li>
                <li class="breadcrumb-item active">Paket Wedding</li>
            </ol>
        </nav>
        <h1>Paket Wedding</h1>
        <p style="color:rgba(255,255,255,0.75);margin-top:8px;">Temukan paket yang sempurna untuk hari istimewa Anda</p>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="form-card mb-5" style="padding:24px 32px;">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Kategori Paket</label>
                    <select name="kategori" class="form-select">
                        <option value="">Semua Kategori</option>
                        <?php foreach ($kategori_list as $k): ?>
                        <option value="<?= $k ?>" <?= $kategori_filter === $k ? 'selected' : '' ?>><?= $k ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Harga Maksimal</label>
                    <select name="harga_max" class="form-select">
                        <option value="">Semua Harga</option>
                        <option value="20000000" <?= $harga_max==20000000?'selected':'' ?>>s.d. Rp 20 Juta</option>
                        <option value="50000000" <?= $harga_max==50000000?'selected':'' ?>>s.d. Rp 50 Juta</option>
                        <option value="80000000" <?= $harga_max==80000000?'selected':'' ?>>s.d. Rp 80 Juta</option>
                        <option value="150000000" <?= $harga_max==150000000?'selected':'' ?>>s.d. Rp 150 Juta</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Urutkan</label>
                    <select name="sort" class="form-select">
                        <option value="harga_asc" <?= $sort==='harga_asc'?'selected':'' ?>>Harga Terendah</option>
                        <option value="harga_desc" <?= $sort==='harga_desc'?'selected':'' ?>>Harga Tertinggi</option>
                        <option value="nama_asc" <?= $sort==='nama_asc'?'selected':'' ?>>Nama A-Z</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-maroon flex-grow-1"><i class="bi bi-search me-1"></i>Filter</button>
                    <a href="paket.php" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>

        <div class="mb-4">
            <p class="text-muted mb-0">Menampilkan <strong><?= count($pakets) ?></strong> paket<?= $kategori_filter ? ' kategori <strong>'.$kategori_filter.'</strong>' : '' ?></p>
        </div>

        <?php if (empty($pakets)): ?>
        <div class="text-center py-5">
            <i class="bi bi-search" style="font-size:3rem;color:#ccc;"></i>
            <h4 class="mt-3" style="color:#999;">Tidak ada paket ditemukan</h4>
            <a href="paket.php" class="btn btn-maroon mt-3">Lihat Semua Paket</a>
        </div>
        <?php else: ?>
        <div class="row g-4">
            <?php foreach ($pakets as $p): ?>
            <div class="col-lg-3 col-md-6">
                <div class="paket-card">
                    <div class="paket-card-img">
                        <?php if ($p['foto'] && file_exists(UPLOAD_PAKET . $p['foto'])): ?>
                            <img src="<?= UPLOAD_URL_PAKET . htmlspecialchars($p['foto']) ?>" alt="<?= htmlspecialchars($p['nama_paket']) ?>">
                        <?php else: ?>
                            <div class="paket-card-img-placeholder"><i class="bi bi-house-heart" style="font-size:3rem;color:rgba(255,255,255,0.4);display:block;"></i></div>
                        <?php endif; ?>
                        <span class="badge-kategori"><?= htmlspecialchars($p['kategori']) ?></span>
                    </div>
                    <div class="paket-card-body">
                        <h5 class="paket-card-title"><?= htmlspecialchars($p['nama_paket']) ?></h5>
                        <div class="paket-harga"><?= formatRupiah($p['harga']) ?> <small>/ Acara</small></div>
                        <p style="font-size:0.85rem;color:#666;"><i class="bi bi-people me-1"></i>Max <?= $p['max_tamu'] ?> tamu</p>
                        <p style="font-size:0.85rem;color:#777;margin-bottom:12px;"><?= htmlspecialchars(mb_substr($p['deskripsi'], 0, 80)) ?>...</p>
                        <div class="d-grid gap-2">
                            <a href="detail-paket.php?id=<?= $p['id'] ?>" class="btn btn-outline-maroon btn-sm">Detail Paket</a>
                            <a href="<?= isLoggedIn() ? 'client/form-booking.php?paket='.$p['id'] : 'login.php?redirect='.urlencode('client/form-booking.php?paket='.$p['id']) ?>" class="btn btn-maroon btn-sm">Pesan Sekarang</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

<!-- Floating WhatsApp -->
<a href="https://wa.me/6281234567890?text=Halo%2C%20saya%20ingin%20bertanya%20mengenai%20paket%20wedding%20Ruma%20Planner." target="_blank" class="wa-float" title="Chat Admin Ruma Planner"><i class="bi bi-whatsapp"></i></a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
