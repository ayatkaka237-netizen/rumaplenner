<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: '.BASE_URL.'vendor.php'); exit(); }

$stmt = $pdo->prepare("
    SELECT v.*, vk.nama AS nama_kategori, vk.slug AS kategori_slug, vk.icon AS kategori_icon
    FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id
    WHERE v.id=? AND v.is_active=1
");
$stmt->execute([$id]);
$v = $stmt->fetch();
if (!$v) { header('Location: '.BASE_URL.'vendor.php'); exit(); }

// Booked dates for this vendor
$booked = $pdo->prepare("SELECT tanggal, status FROM vendor_booking WHERE id_vendor=? AND status IN ('confirmed','pending')");
$booked->execute([$id]);
$bookedDates = [];
foreach ($booked->fetchAll() as $b) {
    $bookedDates[$b['tanggal']] = $b['status'];
}

// Reviews
$reviews = $pdo->prepare("SELECT vr.*, u.nama AS nama_user FROM vendor_review vr JOIN users u ON vr.id_user=u.id WHERE vr.id_vendor=? ORDER BY vr.created_at DESC LIMIT 10");
$reviews->execute([$id]);
$reviewList = $reviews->fetchAll();

// Related vendors same category
$related = $pdo->prepare("SELECT * FROM vendor WHERE id_kategori=? AND id!=? AND is_active=1 LIMIT 3");
$related->execute([$v['id_kategori'], $id]);
$relatedList = $related->fetchAll();

// Wishlist
$isWishlisted = false;
if (isLoggedIn()) {
    $wl = $pdo->prepare("SELECT id FROM vendor_wishlist WHERE id_vendor=? AND id_user=?");
    $wl->execute([$id, $_SESSION['user_id']]);
    $isWishlisted = (bool)$wl->fetch();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($v['nama']) ?> — <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
<style>
.vendor-hero{background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));padding:120px 0 60px;color:#fff;}
.calendar-wrap{background:#fff;border-radius:var(--radius-lg);padding:24px;box-shadow:var(--shadow-sm);border:1px solid rgba(105,27,27,0.08);}
.cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;}
.cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;text-align:center;}
.cal-day-name{font-size:0.7rem;font-weight:600;color:#999;padding:6px 0;text-transform:uppercase;}
.cal-day{border-radius:8px;padding:8px 4px;font-size:0.82rem;cursor:pointer;transition:all .2s;border:2px solid transparent;}
.cal-day.available{background:#d4edda;color:#155724;border-color:#c3e6cb;}
.cal-day.available:hover{background:#28a745;color:#fff;}
.cal-day.booked{background:#f8d7da;color:#721c24;border-color:#f5c6cb;cursor:not-allowed;}
.cal-day.pending{background:#fff3cd;color:#856404;border-color:#ffeeba;cursor:not-allowed;}
.cal-day.selected{background:var(--maroon)!important;color:#fff!important;border-color:var(--maroon)!important;}
.cal-day.other-month{opacity:.3;}
.cal-day.today{font-weight:700;box-shadow:0 0 0 2px var(--gold);}
.legend-dot{width:12px;height:12px;border-radius:3px;display:inline-block;}
.review-card{background:#fff;border-radius:var(--radius);padding:18px;border:1px solid rgba(105,27,27,0.07);margin-bottom:12px;}
.avatar-circle{width:40px;height:40px;border-radius:50%;background:var(--maroon-pale);display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--maroon);}
</style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="vendor-hero">
<div class="container">
  <nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb" style="--bs-breadcrumb-divider-color:rgba(255,255,255,0.5);">
      <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php" style="color:rgba(255,255,255,0.7);">Beranda</a></li>
      <li class="breadcrumb-item"><a href="<?= BASE_URL ?>vendor.php?kategori=<?= $v['kategori_slug'] ?>" style="color:rgba(255,255,255,0.7);"><?= htmlspecialchars($v['nama_kategori']) ?></a></li>
      <li class="breadcrumb-item active" style="color:#fff;"><?= htmlspecialchars($v['nama']) ?></li>
    </ol>
  </nav>
  <div class="row align-items-center g-4">
    <div class="col-lg-8">
      <?php if ($v['badge']): ?>
      <span class="badge mb-2" style="background:var(--gold);font-size:0.78rem;">
        <i class="bi bi-award me-1"></i><?= htmlspecialchars($v['badge']) ?>
      </span>
      <?php endif; ?>
      <h1 style="font-family:var(--font-display);font-size:2.8rem;margin-bottom:8px;"><?= htmlspecialchars($v['nama']) ?></h1>
      <div class="d-flex flex-wrap gap-3 align-items-center mb-3">
        <span style="background:rgba(255,255,255,0.15);padding:5px 14px;border-radius:50px;font-size:0.82rem;">
          <i class="bi <?= htmlspecialchars($v['kategori_icon']) ?> me-1"></i><?= htmlspecialchars($v['nama_kategori']) ?>
        </span>
        <span style="color:var(--gold);">
          <?php for($i=1;$i<=5;$i++) echo $i<=$v['rating']?'★':'☆'; ?>
          <span style="color:#fff;font-size:0.85rem;margin-left:4px;"><?= number_format($v['rating'],1) ?> (<?= $v['total_review'] ?> ulasan)</span>
        </span>
        <span style="font-size:0.85rem;opacity:0.8;"><i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($v['lokasi']) ?></span>
      </div>
      <div style="font-family:var(--font-display);font-size:2rem;color:var(--gold);font-weight:700;">
        <?= formatRupiah($v['harga_mulai']) ?> <small style="font-size:0.9rem;color:rgba(255,255,255,0.7);font-family:var(--font-body);"><?= htmlspecialchars($v['harga_satuan']) ?></small>
      </div>
    </div>
    <div class="col-lg-4 text-lg-end">
      <div class="d-flex flex-wrap gap-2 justify-content-lg-end">
        <button onclick="toggleWishlist(<?= $v['id'] ?>, this)" class="btn btn-outline-light <?= $isWishlisted?'active':'' ?>">
          <i class="bi <?= $isWishlisted?'bi-heart-fill':'bi-heart' ?> me-1"></i><?= $isWishlisted?'Disimpan':'Simpan' ?>
        </button>
        <a href="https://wa.me/<?= preg_replace('/[^0-9]/','', $v['no_wa']) ?>?text=<?= urlencode('Halo '.$v['nama'].', saya ingin bertanya mengenai layanan wedding. Apakah masih tersedia?') ?>" target="_blank" class="btn btn-gold">
          <i class="bi bi-whatsapp me-1"></i>Chat Vendor
        </a>
      </div>
      <?php if ($v['instagram']): ?>
      <div class="mt-2"><small style="opacity:0.7;"><i class="bi bi-instagram me-1"></i><?= htmlspecialchars($v['instagram']) ?></small></div>
      <?php endif; ?>
    </div>
  </div>
</div>
</div>

<section class="section-padding">
<div class="container">
  <div class="row g-4">
    <!-- Main Content -->
    <div class="col-lg-8">
      <!-- Tentang -->
      <div class="form-card mb-4">
        <h4 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-info-circle me-2"></i>Tentang Vendor</h4>
        <p style="color:#555;line-height:1.9;"><?= nl2br(htmlspecialchars($v['deskripsi'])) ?></p>
        <div class="row g-3 mt-2">
          <div class="col-sm-4 text-center p-3" style="background:var(--maroon-pale);border-radius:var(--radius);">
            <div style="font-family:var(--font-display);font-size:2rem;color:var(--maroon);font-weight:700;"><?= $v['total_booking'] ?>+</div>
            <div style="font-size:0.8rem;color:#666;">Total Booking</div>
          </div>
          <div class="col-sm-4 text-center p-3" style="background:var(--maroon-pale);border-radius:var(--radius);">
            <div style="font-family:var(--font-display);font-size:2rem;color:var(--maroon);font-weight:700;"><?= number_format($v['rating'],1) ?></div>
            <div style="font-size:0.8rem;color:#666;">Rating</div>
          </div>
          <div class="col-sm-4 text-center p-3" style="background:var(--maroon-pale);border-radius:var(--radius);">
            <div style="font-family:var(--font-display);font-size:2rem;color:var(--maroon);font-weight:700;"><?= $v['total_review'] ?></div>
            <div style="font-size:0.8rem;color:#666;">Ulasan</div>
          </div>
        </div>
      </div>

      <!-- Kalender Booking -->
      <div class="form-card mb-4" id="kalender">
        <h4 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:4px;"><i class="bi bi-calendar3 me-2"></i>Kalender Ketersediaan</h4>
        <p style="font-size:0.85rem;color:#888;margin-bottom:20px;">Pilih tanggal wedding Anda untuk mengecek ketersediaan vendor</p>
        <div class="d-flex gap-3 flex-wrap mb-3">
          <span class="d-flex align-items-center gap-2 fs-sm"><span class="legend-dot" style="background:#d4edda;border:1px solid #c3e6cb;"></span><small>Tersedia</small></span>
          <span class="d-flex align-items-center gap-2"><span class="legend-dot" style="background:#f8d7da;border:1px solid #f5c6cb;"></span><small>Full Booked</small></span>
          <span class="d-flex align-items-center gap-2"><span class="legend-dot" style="background:#fff3cd;border:1px solid #ffeeba;"></span><small>Pending</small></span>
          <span class="d-flex align-items-center gap-2"><span class="legend-dot" style="background:var(--maroon);"></span><small>Dipilih</small></span>
        </div>
        <div class="calendar-wrap">
          <div class="cal-header">
            <button class="btn btn-sm btn-outline-maroon" id="prevMonth"><i class="bi bi-chevron-left"></i></button>
            <h5 id="calTitle" style="font-family:var(--font-display);color:var(--maroon);margin:0;"></h5>
            <button class="btn btn-sm btn-outline-maroon" id="nextMonth"><i class="bi bi-chevron-right"></i></button>
          </div>
          <div class="cal-grid" id="calGrid"></div>
        </div>
        <div id="selectedDateInfo" class="mt-3 p-3 rounded-xl" style="background:var(--maroon-pale);display:none;">
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <div style="font-size:0.8rem;color:#888;">Tanggal Dipilih</div>
              <div style="font-family:var(--font-display);font-size:1.2rem;color:var(--maroon);font-weight:600;" id="selectedDateText"></div>
            </div>
            <span class="availability-badge avail-green" id="availBadge"><i class="bi bi-circle-fill me-1" style="font-size:0.5rem;"></i>Tersedia</span>
          </div>
          <div class="mt-2">
            <a href="#" id="bookNowBtn" class="btn btn-maroon btn-sm">
              <i class="bi bi-calendar-check me-1"></i>Booking Tanggal Ini
            </a>
          </div>
        </div>
      </div>

      <!-- Reviews -->
      <div class="form-card mb-4">
        <h4 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:20px;"><i class="bi bi-star me-2"></i>Ulasan Customer</h4>
        <?php if (empty($reviewList)): ?>
        <div class="text-center py-4 text-muted"><i class="bi bi-chat-square" style="font-size:2rem;opacity:0.3;"></i><p class="mt-2">Belum ada ulasan</p></div>
        <?php else: ?>
        <?php foreach ($reviewList as $r): ?>
        <div class="review-card">
          <div class="d-flex gap-3 align-items-start">
            <div class="avatar-circle"><?= strtoupper(substr($r['nama_user'],0,1)) ?></div>
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between">
                <strong><?= htmlspecialchars($r['nama_user']) ?></strong>
                <small class="text-muted"><?= date('d M Y', strtotime($r['created_at'])) ?></small>
              </div>
              <div style="color:var(--gold);margin:4px 0;">
                <?php for($i=1;$i<=5;$i++) echo $i<=$r['rating']?'★':'☆'; ?>
              </div>
              <p style="font-size:0.88rem;color:#555;margin:0;"><?= htmlspecialchars($r['komentar']) ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
        <?php if (isLoggedIn()): ?>
        <form method="POST" action="api/review.php" class="mt-3 p-3" style="background:var(--off-white);border-radius:var(--radius);">
          <input type="hidden" name="vendor_id" value="<?= $v['id'] ?>">
          <h6 style="color:var(--maroon);">Tulis Ulasan</h6>
          <div class="mb-2">
            <label class="form-label">Rating</label>
            <select name="rating" class="form-select form-select-sm">
              <?php for($i=5;$i>=1;$i--): ?><option value="<?= $i ?>"><?= $i ?> Bintang</option><?php endfor; ?>
            </select>
          </div>
          <textarea name="komentar" class="form-control mb-2" rows="2" placeholder="Ceritakan pengalaman Anda..."></textarea>
          <button type="submit" class="btn btn-maroon btn-sm">Kirim Ulasan</button>
        </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
      <!-- Booking Card -->
      <div class="form-card mb-4 sticky-top" style="top:90px;">
        <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-calendar-check me-2"></i>Booking Vendor Ini</h5>
        <div class="mb-3">
          <label class="form-label">Tanggal Wedding</label>
          <input type="date" id="quickDate" class="form-control" min="<?= date('Y-m-d', strtotime('+7 days')) ?>" onchange="quickCheck(this.value)">
        </div>
        <div id="quickResult" class="mb-3" style="display:none;"></div>
        <button onclick="checkAndBook()" class="btn btn-maroon w-100 mb-2" id="bookBtn">
          <i class="bi bi-check-circle me-1"></i>Cek & Booking
        </button>
        <a href="https://wa.me/<?= preg_replace('/[^0-9]/','', $v['no_wa']) ?>?text=<?= urlencode('Halo '.$v['nama'].', saya ingin booking untuk pernikahan saya. Apakah masih tersedia?') ?>" target="_blank" class="btn btn-outline-maroon w-100">
          <i class="bi bi-whatsapp me-1"></i>Konfirmasi via WhatsApp
        </a>
        <hr>
        <div style="font-size:0.83rem;color:#666;">
          <div class="d-flex gap-2 mb-2"><i class="bi bi-shield-check text-success"></i><span>Booking aman & terjamin</span></div>
          <div class="d-flex gap-2 mb-2"><i class="bi bi-clock text-warning"></i><span>Konfirmasi dalam 24 jam</span></div>
          <div class="d-flex gap-2"><i class="bi bi-telephone text-primary"></i><span><?= htmlspecialchars($v['no_wa']) ?></span></div>
        </div>
      </div>

      <!-- Related Vendors -->
      <?php if ($relatedList): ?>
      <div class="form-card">
        <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:16px;"><i class="bi bi-grid me-2"></i>Vendor Serupa</h5>
        <?php foreach ($relatedList as $rel): ?>
        <a href="vendor-detail.php?id=<?= $rel['id'] ?>" class="d-flex gap-3 align-items-center mb-3 text-decoration-none" style="padding:12px;background:var(--off-white);border-radius:var(--radius);transition:var(--transition);" onmouseover="this.style.background='var(--maroon-pale)'" onmouseout="this.style.background='var(--off-white)'">
          <div style="width:48px;height:48px;background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            <i class="bi <?= htmlspecialchars($v['kategori_icon']) ?>" style="color:rgba(255,255,255,0.7);font-size:1.2rem;"></i>
          </div>
          <div>
            <div style="font-weight:600;color:var(--text-dark);font-size:0.9rem;"><?= htmlspecialchars($rel['nama']) ?></div>
            <div style="color:var(--maroon);font-size:0.8rem;"><?= formatRupiah($rel['harga_mulai']) ?></div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</section>

<a href="https://wa.me/6281234567890?text=<?= urlencode('Halo Admin Ruma Planner, saya ingin bertanya mengenai vendor '.$v['nama'].'.') ?>" target="_blank" class="wa-float" title="Chat Admin">
  <i class="bi bi-whatsapp"></i>
</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
const bookedDates = <?= json_encode($bookedDates) ?>;
const vendorId    = <?= $v['id'] ?>;
let currentYear   = new Date().getFullYear();
let currentMonth  = new Date().getMonth();
let selectedDate  = null;

function renderCalendar(year, month) {
  const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
  document.getElementById('calTitle').textContent = months[month] + ' ' + year;
  const grid = document.getElementById('calGrid');
  grid.innerHTML = '';
  ['Min','Sen','Sel','Rab','Kam','Jum','Sab'].forEach(d => {
    const el = document.createElement('div');
    el.className = 'cal-day-name'; el.textContent = d; grid.appendChild(el);
  });
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  const today = new Date(); today.setHours(0,0,0,0);
  for (let i = 0; i < firstDay; i++) {
    const el = document.createElement('div'); el.className='cal-day other-month'; grid.appendChild(el);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const el = document.createElement('div');
    const dateStr = year + '-' + String(month+1).padStart(2,'0') + '-' + String(d).padStart(2,'0');
    const dateObj = new Date(year, month, d);
    el.textContent = d;
    if (bookedDates[dateStr] === 'confirmed') {
      el.className = 'cal-day booked'; el.title = 'Full Booked';
    } else if (bookedDates[dateStr] === 'pending') {
      el.className = 'cal-day pending'; el.title = 'Pending Booking';
    } else if (dateObj <= today) {
      el.className = 'cal-day other-month'; el.style.cursor='not-allowed';
    } else {
      el.className = 'cal-day available'; el.title = 'Tersedia';
      el.onclick = () => selectDate(dateStr, el);
    }
    if (dateStr === selectedDate) el.classList.add('selected');
    if (d === today.getDate() && month === today.getMonth() && year === today.getFullYear())
      el.classList.add('today');
    grid.appendChild(el);
  }
}

function selectDate(dateStr, el) {
  document.querySelectorAll('.cal-day.selected').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
  selectedDate = dateStr;
  const [y,m,d] = dateStr.split('-');
  const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
  document.getElementById('selectedDateText').textContent = d + ' ' + months[parseInt(m)-1] + ' ' + y;
  document.getElementById('selectedDateInfo').style.display = 'block';
  document.getElementById('bookNowBtn').href = '<?= BASE_URL ?>' + (<?= isLoggedIn() ? 'true' : 'false' ?> ? 'vendor-booking.php?vendor='+vendorId+'&tanggal='+dateStr : 'login.php');
  document.getElementById('quickDate').value = dateStr;
}

document.getElementById('prevMonth').onclick = () => { currentMonth--; if(currentMonth<0){currentMonth=11;currentYear--;} renderCalendar(currentYear,currentMonth); };
document.getElementById('nextMonth').onclick = () => { currentMonth++; if(currentMonth>11){currentMonth=0;currentYear++;} renderCalendar(currentYear,currentMonth); };
renderCalendar(currentYear, currentMonth);

function quickCheck(dateStr) {
  const resultDiv = document.getElementById('quickResult');
  if (!dateStr) { resultDiv.style.display='none'; return; }
  const status = bookedDates[dateStr];
  if (status === 'confirmed') {
    resultDiv.innerHTML = '<div class="availability-badge avail-red w-100 justify-content-center py-2"><i class="bi bi-x-circle me-1"></i>FULL BOOKED — Tanggal ini tidak tersedia</div>';
    document.getElementById('bookBtn').disabled = true;
  } else if (status === 'pending') {
    resultDiv.innerHTML = '<div class="availability-badge avail-yellow w-100 justify-content-center py-2"><i class="bi bi-clock me-1"></i>PENDING — Sedang dalam proses booking</div>';
    document.getElementById('bookBtn').disabled = false;
  } else {
    resultDiv.innerHTML = '<div class="availability-badge avail-green w-100 justify-content-center py-2"><i class="bi bi-check-circle me-1"></i>TERSEDIA — Tanggal ini masih kosong!</div>';
    document.getElementById('bookBtn').disabled = false;
  }
  resultDiv.style.display = 'block';
  selectedDate = dateStr;
  const dt = new Date(dateStr+'T00:00:00');
  const months=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'];
  currentYear = dt.getFullYear(); currentMonth = dt.getMonth();
  renderCalendar(currentYear, currentMonth);
}

function checkAndBook() {
  const d = document.getElementById('quickDate').value;
  if (!d) { alert('Pilih tanggal terlebih dahulu!'); return; }
  const status = bookedDates[d];
  if (status === 'confirmed') { alert('Maaf, tanggal ini sudah Full Booked!'); return; }
  const isLoggedIn = <?= isLoggedIn() ? 'true' : 'false' ?>;
  window.location.href = isLoggedIn ? '<?= BASE_URL ?>vendor-booking.php?vendor='+vendorId+'&tanggal='+d : '<?= BASE_URL ?>login.php';
}

function toggleWishlist(vendorId, btn) {
  fetch('api/wishlist.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({vendor_id: vendorId}) })
  .then(r => r.json()).then(data => {
    if (data.login_required) { window.location.href='<?= BASE_URL ?>login.php'; return; }
    const icon = btn.querySelector('i');
    if (data.action==='added') { icon.className='bi bi-heart-fill me-1'; btn.innerHTML='<i class="bi bi-heart-fill me-1"></i>Disimpan'; }
    else { icon.className='bi bi-heart me-1'; btn.innerHTML='<i class="bi bi-heart me-1"></i>Simpan'; }
  });
}
</script>
</body>
</html>
