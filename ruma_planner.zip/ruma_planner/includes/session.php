<?php
// =====================================================
// SESSION HELPER - Ruma Planner
// Role: admin | operator | pemilik | client
// =====================================================

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

if (!defined('BASE_URL')) require_once __DIR__ . '/config.php';

// ── Cek Login ──────────────────────────────────────
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}
function getRole() {
    return $_SESSION['role'] ?? '';
}
function isAdmin() {
    return isLoggedIn() && getRole() === 'admin';
}
function isOperator() {
    return isLoggedIn() && getRole() === 'operator';
}
function isPemilik() {
    return isLoggedIn() && getRole() === 'pemilik';
}
function isClient() {
    return isLoggedIn() && getRole() === 'client';
}
// Admin ATAU Operator bisa akses panel
function isStaff() {
    return isLoggedIn() && in_array(getRole(), ['admin', 'operator', 'pemilik']);
}

// ── Require Functions ──────────────────────────────
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'login.php?redirect=' . urlencode($_SERVER['REQUEST_URI'] ?? ''));
        exit();
    }
}
function requireAdmin() {
    if (!isAdmin()) {
        if (!isLoggedIn()) { header('Location: ' . BASE_URL . 'login.php'); exit(); }
        header('Location: ' . BASE_URL . 'admin/dashboard.php');
        exit();
    }
}
function requireOperator() {
    if (!isOperator()) {
        if (!isLoggedIn()) { header('Location: ' . BASE_URL . 'login.php'); exit(); }
        header('Location: ' . BASE_URL . 'admin/dashboard.php');
        exit();
    }
}
function requirePemilik() {
    if (!isPemilik()) {
        if (!isLoggedIn()) { header('Location: ' . BASE_URL . 'login.php'); exit(); }
        header('Location: ' . BASE_URL . 'admin/dashboard.php');
        exit();
    }
}
function requireStaff() {
    if (!isStaff()) {
        if (isClient()) { header('Location: ' . BASE_URL . 'client/riwayat.php'); exit(); }
        header('Location: ' . BASE_URL . 'login.php');
        exit();
    }
}
function requireClient() {
    if (!isClient()) {
        if (isStaff()) { header('Location: ' . BASE_URL . 'admin/dashboard.php'); exit(); }
        header('Location: ' . BASE_URL . 'login.php');
        exit();
    }
}

// ── CSRF ───────────────────────────────────────────
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrfToken()) . '">';
}
function verifyCsrf() {
    $token = $_POST['csrf_token'] ?? '';
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
function requireCsrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !verifyCsrf()) {
        setFlash('error', 'Sesi form tidak valid. Silakan coba lagi.');
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? BASE_URL . 'index.php'));
        exit();
    }
}

// ── Flash Messages ─────────────────────────────────
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
function showFlash() {
    $flash = getFlash();
    if ($flash) {
        $class = match($flash['type']) {
            'success' => 'alert-success',
            'error'   => 'alert-danger',
            'warning' => 'alert-warning',
            default   => 'alert-info',
        };
        echo '<div class="alert ' . $class . ' alert-dismissible fade show" role="alert">
            ' . htmlspecialchars($flash['message']) . '
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>';
    }
}
