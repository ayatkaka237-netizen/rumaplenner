<?php
// =====================================================
// KONEKSI DATABASE - Ruma Planner (PDO + SQLite)
// Tidak perlu XAMPP / MySQL — berjalan langsung!
// =====================================================

define('DB_PATH', __DIR__ . '/../database/ruma_planner.db');

if (!is_dir(__DIR__ . '/../database')) {
    mkdir(__DIR__ . '/../database', 0775, true);
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA journal_mode=WAL');
    $pdo->exec('PRAGMA foreign_keys=ON');
} catch (PDOException $e) {
    die('<div style="font-family:sans-serif;padding:20px;background:#fff0f0;border-left:4px solid #691B1B;margin:20px;">
        <h3>Koneksi Database Gagal</h3><p>' . htmlspecialchars($e->getMessage()) . '</p></div>');
}

initDatabase($pdo);

function initDatabase($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        no_hp TEXT,
        role TEXT NOT NULL DEFAULT 'client',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS paket (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_paket TEXT NOT NULL,
        kategori TEXT NOT NULL,
        harga REAL NOT NULL,
        deskripsi TEXT,
        fasilitas TEXT,
        foto TEXT,
        max_tamu INTEGER DEFAULT 100,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS booking (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kode_booking TEXT NOT NULL UNIQUE,
        id_user INTEGER NOT NULL,
        id_paket INTEGER NOT NULL,
        nama_mempelai_pria TEXT NOT NULL,
        nama_mempelai_wanita TEXT NOT NULL,
        tanggal_acara DATE NOT NULL,
        lokasi TEXT NOT NULL,
        jumlah_tamu INTEGER NOT NULL,
        catatan TEXT,
        total_harga REAL NOT NULL,
        dp_amount REAL DEFAULT 0,
        bukti_pembayaran TEXT,
        status TEXT DEFAULT 'Pending',
        catatan_admin TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (id_paket) REFERENCES paket(id) ON DELETE CASCADE
    )");

    // Add pelunasan columns if not exist (upgrade safe)
    try { $pdo->exec("ALTER TABLE booking ADD COLUMN bukti_pelunasan TEXT"); } catch(Exception $e) {}
    try { $pdo->exec("ALTER TABLE booking ADD COLUMN pelunasan_amount REAL DEFAULT 0"); } catch(Exception $e) {}
    try { $pdo->exec("ALTER TABLE booking ADD COLUMN status_pelunasan TEXT DEFAULT 'Belum'"); } catch(Exception $e) {}

    $pdo->exec("CREATE TABLE IF NOT EXISTS kontak (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        email TEXT,
        no_hp TEXT NOT NULL,
        pesan TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        tanggal DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // ── VENDOR SYSTEM ──────────────────────────────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS vendor_kategori (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        icon TEXT DEFAULT 'bi-person-badge',
        urutan INTEGER DEFAULT 0
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS vendor (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_kategori INTEGER NOT NULL,
        nama TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        deskripsi TEXT,
        harga_mulai REAL DEFAULT 0,
        harga_satuan TEXT DEFAULT 'per acara',
        foto_utama TEXT,
        gallery TEXT,
        rating REAL DEFAULT 5.0,
        total_review INTEGER DEFAULT 0,
        total_booking INTEGER DEFAULT 0,
        no_wa TEXT,
        instagram TEXT,
        lokasi TEXT,
        badge TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_kategori) REFERENCES vendor_kategori(id)
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS vendor_booking (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_booking INTEGER,
        id_vendor INTEGER NOT NULL,
        id_user INTEGER NOT NULL,
        tanggal DATE NOT NULL,
        status TEXT DEFAULT 'pending',
        catatan TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_vendor) REFERENCES vendor(id),
        FOREIGN KEY (id_user) REFERENCES users(id)
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS vendor_review (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_vendor INTEGER NOT NULL,
        id_user INTEGER NOT NULL,
        rating INTEGER DEFAULT 5,
        komentar TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_vendor) REFERENCES vendor(id),
        FOREIGN KEY (id_user) REFERENCES users(id)
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS vendor_wishlist (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_vendor INTEGER NOT NULL,
        id_user INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(id_vendor, id_user),
        FOREIGN KEY (id_vendor) REFERENCES vendor(id),
        FOREIGN KEY (id_user) REFERENCES users(id)
    )");

    seedDefaultData($pdo);
    seedVendorData($pdo);
}

function seedDefaultData($pdo) {
    $cek = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($cek == 0) {
        $adminPass    = password_hash('admin123', PASSWORD_DEFAULT);
        $operatorPass = password_hash('operator123', PASSWORD_DEFAULT);
        $pemilikPass  = password_hash('pemilik123', PASSWORD_DEFAULT);
        $clientPass   = password_hash('client123', PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("INSERT INTO users (nama, username, email, password, role) VALUES (?,?,?,?,?)");
        $stmt->execute(['Administrator', 'admin', 'admin@rumaplanner.com', $adminPass, 'admin']);
        $stmt->execute(['Operator Wedding', 'operator', 'operator@rumaplanner.com', $operatorPass, 'operator']);
        $stmt->execute(['Pemilik Ruma Planner', 'pemilik', 'pemilik@rumaplanner.com', $pemilikPass, 'pemilik']);

        $stmt2 = $pdo->prepare("INSERT INTO users (nama, username, email, password, no_hp, role) VALUES (?,?,?,?,?,?)");
        $stmt2->execute(['Budi Santoso', 'budi', 'budi@email.com', $clientPass, '081234567890', 'client']);
    }

    $cekPaket = $pdo->query("SELECT COUNT(*) FROM paket")->fetchColumn();
    if ($cekPaket == 0) {
        $pakets = [
            ['Intimate Wedding','Intimate',15000000,'Paket pernikahan intimate untuk momen sakral bersama orang-orang terkasih.','Dekorasi Minimalis Premium|Dokumentasi Foto & Video|MC Profesional|Catering 50 Pax|Bunga Segar|Sound System|Koordinator Hari H','paket_1.jpg',50],
            ['Silver Wedding','Reguler',35000000,'Paket pernikahan reguler dengan dekorasi elegan dan layanan lengkap.','Dekorasi Elegan|Foto & Video Cinematic|MC Profesional|Catering 150 Pax|Bunga Segar|Pelaminan|Sound System|Lighting|Koordinator|Undangan Digital','paket_2.jpg',150],
            ['Gold Wedding','Premium',65000000,'Paket premium dengan sentuhan mewah dan tim profesional berpengalaman.','Dekorasi Mewah Premium|Foto & Video Full Package|MC & Entertainer|Catering 300 Pax|Bunga Import|Pelaminan Custom|Sound System Premium|Lighting Show|Wedding Organizer Full|Undangan Fisik & Digital|Souvenir','paket_3.jpg',300],
            ['Royal Wedding','Exclusive',120000000,'Pengalaman pernikahan eksklusif layaknya keluarga kerajaan.','Dekorasi Royal Exclusive|Foto & Video International Style|MC Celebrity|Catering 500 Pax Premium|Bunga Import Rare|Pelaminan Grand Custom|Sound System Concert Grade|Lighting & Pyrotechnic|Full Wedding Organizer|Undangan Eksklusif|Souvenir Premium|Honeymoon Package|Bridal Package|Live Music','paket_4.jpg',500],
        ];
        $stmt = $pdo->prepare("INSERT INTO paket (nama_paket,kategori,harga,deskripsi,fasilitas,foto,max_tamu) VALUES (?,?,?,?,?,?,?)");
        foreach ($pakets as $p) $stmt->execute($p);
    }
}

// Helper functions
function sanitize($pdo, $data) {
    return htmlspecialchars(strip_tags(trim($data)));
}
function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}
function generateKodeBooking() {
    return 'RP-' . strtoupper(date('Ymd')) . '-' . strtoupper(substr(uniqid(), -5));
}
function statusBadge($status) {
    $badges = ['Pending'=>'warning','Diproses'=>'info','Lunas'=>'primary','Selesai'=>'success','Dibatalkan'=>'danger'];
    $class = $badges[$status] ?? 'secondary';
    return '<span class="badge bg-' . $class . '">' . htmlspecialchars($status) . '</span>';
}
function uploadImage($file, $dir, $prefix = 'img') {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) return ['success'=>false,'message'=>'File tidak valid'];
    if ($file['size'] > 5*1024*1024) return ['success'=>false,'message'=>'Ukuran file terlalu besar (max 5MB)'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    $extMap = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/jpg'=>'jpg'];
    if (!isset($extMap[$mime])) return ['success'=>false,'message'=>'Tipe file tidak didukung'];
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $filename = $prefix.'_'.date('YmdHis').'_'.bin2hex(random_bytes(4)).'.'.$extMap[$mime];
    $target = rtrim($dir,'/\\').DIRECTORY_SEPARATOR.$filename;
    if (move_uploaded_file($file['tmp_name'], $target)) return ['success'=>true,'filename'=>$filename];
    return ['success'=>false,'message'=>'Gagal menyimpan file'];
}

function seedVendorData($pdo) {
    $cek = $pdo->query("SELECT COUNT(*) FROM vendor_kategori")->fetchColumn();
    if ($cek > 0) return;

    // Kategori vendor
    $kategoriList = [
        ['MUA / Make Up Artist','mua','bi-brush',1],
        ['Photographer','photographer','bi-camera',2],
        ['Gedung / Venue','gedung','bi-building',3],
        ['Catering','catering','bi-cup-hot',4],
        ['Dekorasi','dekorasi','bi-flower1',5],
        ['Musik / Band','musik','bi-music-note-beamed',6],
        ['MC','mc','bi-mic',7],
        ['Videografer','videografer','bi-camera-video',8],
    ];
    $stmtK = $pdo->prepare("INSERT INTO vendor_kategori (nama,slug,icon,urutan) VALUES (?,?,?,?)");
    foreach ($kategoriList as $k) $stmtK->execute($k);

    // Sample vendors per category
    $vendors = [
        // MUA - id_kategori=1
        [1,'Sari Beauty Studio','sari-beauty','MUA profesional berpengalaman 8 tahun. Spesialis riasan pengantin adat dan modern.', 1500000,'per sesi','vendor_sari_beauty.jpg','','4.9',45,120,'628112233445','@sari_beauty','Padangsidimpuan','Best Vendor'],
        [1,'Maharani Makeup','maharani-makeup','Tim MUA bersertifikat internasional. Hasil natural dan tahan lama hingga 12 jam.', 1800000,'per sesi','vendor_maharani_mua.jpg','','4.8',38,95,'628122334456','@maharani_mua','Padangsidimpuan','Trending'],
        [1,'Cantik Studio MUA','cantik-studio','Riasan glamour dan natural sesuai keinginan. Tersedia paket lengkap dengan hairstylist.',1200000,'per sesi','vendor_cantik_studio.jpg','','4.7',29,67,'628133445567','@cantik_studio','Padangsidimpuan',''],

        // Photographer - id_kategori=2
        [2,'Arif Photography','arif-photo','Fotografer wedding profesional. Spesialis foto outdoor dan indoor dengan teknik cinematic.',2500000,'per acara','vendor_arif_photo.jpg','','4.9',62,180,'628144556678','@arif_photography','Padangsidimpuan','Most Booked'],
        [2,'Lentera Studio','lentera-studio','Studio fotografi premium. Tim lengkap dengan 2 fotografer dan 1 videografer.',3500000,'per acara','vendor_lentera_studio.jpg','','4.8',51,140,'628155667789','@lentera_studio','Padangsidimpuan','Best Vendor'],
        [2,'Moment Capture','moment-capture','Gaya dokumentasi jurnalistik modern. Natural, candid, dan berkesan untuk selamanya.',2000000,'per acara','vendor_moment_capture.jpg','','4.7',34,89,'628166778890','@moment_capture','Padangsidimpuan','Trending'],

        // Gedung - id_kategori=3
        [3,'Grand Ballroom Mahkota','grand-mahkota','Ballroom mewah kapasitas 500 tamu. Dilengkapi sound system, AC sentral, dan parkir luas.',15000000,'per hari','vendor_grand_mahkota.jpg','','4.9',28,75,'628177889901','@grand_mahkota','Padangsidimpuan','Best Vendor'],
        [3,'Taman Sari Garden','taman-sari','Venue outdoor asri dengan taman bunga tropis. Cocok untuk intimate dan outdoor wedding.',8000000,'per hari','vendor_taman_sari.jpg','','4.8',22,58,'628188990012','@taman_sari_venue','Padangsidimpuan','Trending'],
        [3,'Griya Pernikahan Indah','griya-indah','Gedung semi-indoor elegan kapasitas 300 tamu. Lokasi strategis dan akses mudah.',10000000,'per hari','vendor_griya_indah.jpg','','4.7',19,49,'628199001123','@griya_indah','Padangsidimpuan',''],

        // Catering - id_kategori=4
        [4,'Dapur Bunda Catering','dapur-bunda','Catering premium dengan chef berpengalaman. Menu beragam dari masakan Padang hingga internasional.',500000,'per 100 pax','vendor_dapur_bunda.jpg','','4.9',55,160,'628100112234','@dapur_bunda','Padangsidimpuan','Most Booked'],
        [4,'Berkah Catering','berkah-catering','Spesialis catering halal bersertifikat. Rasa autentik, penyajian rapi, dan pelayanan ramah.',400000,'per 100 pax','vendor_berkah_catering.jpg','','4.7',41,110,'628101223345','@berkah_catering','Padangsidimpuan',''],
        [4,'Royal Kitchen','royal-kitchen','Catering eksklusif dengan live cooking station. Cocok untuk paket premium dan royal wedding.',800000,'per 100 pax','vendor_royal_kitchen.jpg','','4.8',33,88,'628102334456','@royal_kitchen','Padangsidimpuan','Trending'],

        // Dekorasi - id_kategori=5
        [5,'Bunga & Karya Dekor','bunga-karya','Spesialis dekorasi pelaminan adat dan modern. Menggunakan bunga segar impor dan lokal.',3000000,'per acara','vendor_bunga_karya.jpg','','4.9',47,135,'628103445567','@bunga_karya','Padangsidimpuan','Best Vendor'],
        [5,'Elegan Dekorasi','elegan-dekor','Desain dekorasi minimalis modern yang instagramable. Setiap detail dikerjakan dengan teliti.',2500000,'per acara','vendor_elegan_dekor.jpg','','4.8',39,102,'628104556678','@elegan_dekorasi','Padangsidimpuan','Trending'],
        [5,'Mahkota Pelaminan','mahkota-pelaminan','Pelaminan custom berbagai tema: adat, modern, boho, rustic. Tim profesional dan berpengalaman.',4000000,'per acara','vendor_mahkota_pelaminan.jpg','','4.7',28,72,'628105667789','@mahkota_pelaminan','Padangsidimpuan',''],

        // Musik/Band - id_kategori=6
        [6,'Harmoni Band','harmoni-band','Band pernikahan profesional. Repertoar lengkap dari pop, jazz, hingga lagu daerah Batak.',4000000,'per acara','vendor_harmoni_band.jpg','','4.9',35,98,'628106778890','@harmoni_band','Padangsidimpuan','Most Booked'],
        [6,'Melodi Indah Trio','melodi-indah','Trio akustik elegan. Cocok untuk intimate wedding dan acara cocktail mewah.',2500000,'per acara','vendor_melodi_indah.jpg','','4.8',27,71,'628107889901','@melodi_indah','Padangsidimpuan','Trending'],
        [6,'Seruling Emas Orchestra','seruling-emas','Orkestra mini 8 musisi. Pengalaman di lebih dari 200 wedding bergengsi.',6000000,'per acara','vendor_seruling_emas.jpg','','4.9',18,52,'628108990012','@seruling_emas','Padangsidimpuan','Best Vendor'],

        // MC - id_kategori=7
        [7,'Rizky MC Profesional','rizky-mc','MC wedding bilingual (Indonesia-Batak). Energik, humoris, dan profesional.',1500000,'per acara','vendor_rizky_mc.jpg','','4.9',60,175,'628109001123','@rizky_mc','Padangsidimpuan','Most Booked'],
        [7,'Dian Presenter','dian-presenter','MC elegan dan berpengalaman untuk wedding formal dan intimate.',1200000,'per acara','vendor_dian_presenter.jpg','','4.8',44,128,'628110112234','@dian_presenter','Padangsidimpuan','Trending'],

        // Videografer - id_kategori=8
        [8,'Sinema Wedding','sinema-wedding','Videografer cinematic dengan teknik drone dan stabilizer. Edit premium dengan musik.',3000000,'per acara','vendor_sinema_wedding.jpg','','4.9',50,145,'628111223345','@sinema_wedding','Padangsidimpuan','Best Vendor'],
        [8,'Kenangan Visual','kenangan-visual','Dokumentasi video pendek dan feature film. Gaya modern dan emosional.',2500000,'per acara','vendor_kenangan_visual.jpg','','4.8',38,102,'628112334456','@kenangan_visual','Padangsidimpuan','Trending'],
    ];

    $stmtV = $pdo->prepare("INSERT INTO vendor (id_kategori,nama,slug,deskripsi,harga_mulai,harga_satuan,foto_utama,gallery,rating,total_review,total_booking,no_wa,instagram,lokasi,badge) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach ($vendors as $v) $stmtV->execute($v);

    // ── SEED: Dummy Users Tambahan ────────────────────────────────────────────
    $dummyUsers = [
        ['Aulia Rahmawati','aulia','aulia@email.com','081234111111'],
        ['Dimas Pratama','dimas','dimas@email.com','081234222222'],
        ['Siti Nurhaliza','siti','siti@email.com','081234333333'],
    ];
    $stmtU = $pdo->prepare("INSERT OR IGNORE INTO users (nama,username,email,password,no_hp,role) VALUES (?,?,?,?,?,'client')");
    $pass = password_hash('client123', PASSWORD_DEFAULT);
    foreach ($dummyUsers as $u) $stmtU->execute([$u[0],$u[1],$u[2],$pass,$u[3]]);

    // ── SEED: Dummy Bookings ──────────────────────────────────────────────────
    $clientId  = $pdo->query("SELECT id FROM users WHERE username='budi' LIMIT 1")->fetchColumn();
    $auliaId   = $pdo->query("SELECT id FROM users WHERE username='aulia' LIMIT 1")->fetchColumn();
    $dimasId   = $pdo->query("SELECT id FROM users WHERE username='dimas' LIMIT 1")->fetchColumn();
    $sitiId    = $pdo->query("SELECT id FROM users WHERE username='siti' LIMIT 1")->fetchColumn();

    $paketIds  = $pdo->query("SELECT id FROM paket ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
    if (count($paketIds) >= 4) {
        $dummyBookings = [
            // kode, id_user, id_paket, pria, wanita, tgl, lokasi, tamu, catatan, total, dp, bukti, status, catatan_admin
            ['RP-20260610-AA001',$auliaId,$paketIds[3],'Ahmad Fauzi','Aulia Rahmawati','2026-09-15','Grand Ballroom Mahkota, Padangsidimpuan',350,'Mohon dekorasi tema gold dan putih.',120000000,36000000,'bukti_dp_demo1.jpg','Selesai','Telah selesai dilaksanakan. Terima kasih.'],
            ['RP-20260615-BB002',$dimasId,$paketIds[2],'Dimas Pratama','Rizka Amelia','2026-10-20','Griya Pernikahan Indah, Padangsidimpuan',250,'Tema pernikahan adat Batak.',65000000,19500000,'bukti_dp_demo2.jpg','Lunas','Pembayaran lunas. Persiapan berjalan baik.'],
            ['RP-20260618-CC003',$sitiId,$paketIds[1],'Reza Mahendra','Siti Nurhaliza','2026-11-05','Taman Sari Garden, Padangsidimpuan',130,'Outdoor wedding, mohon siapkan tenda cadangan.',35000000,10500000,'bukti_dp_demo3.jpg','Diproses','Bukti DP diterima. Tim sedang mempersiapkan.'],
            ['RP-20260620-DD004',$clientId,$paketIds[0],'Budi Santoso','Rini Wulandari','2026-12-12','Rumah pribadi, Jl. Merdeka No. 10',45,'Intimate wedding keluarga inti saja.',15000000,4500000,'','Pending',''],
            ['RP-20260622-EE005',$auliaId,$paketIds[1],'Fajar Nugroho','Dewi Lestari','2026-08-30','Hotel Grand Angkasa, Padangsidimpuan',100,'',35000000,10500000,'bukti_dp_demo4.jpg','Dibatalkan','Dibatalkan atas permintaan client.'],
        ];
        $stmtBk = $pdo->prepare("INSERT OR IGNORE INTO booking (kode_booking,id_user,id_paket,nama_mempelai_pria,nama_mempelai_wanita,tanggal_acara,lokasi,jumlah_tamu,catatan,total_harga,dp_amount,bukti_pembayaran,status,catatan_admin) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        foreach ($dummyBookings as $bk) $stmtBk->execute($bk);
    }

    // ── SEED: Dummy Vendor Bookings (kalender terisi) ─────────────────────────
    $allVendorIds = $pdo->query("SELECT id FROM vendor ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
    $stmtVB = $pdo->prepare("INSERT OR IGNORE INTO vendor_booking (id_vendor,id_user,tanggal,status,catatan) VALUES (?,?,?,?,?)");
    $futureDates = [
        '2026-07-12','2026-07-19','2026-07-26',
        '2026-08-02','2026-08-09','2026-08-16',
        '2026-09-06','2026-09-13','2026-09-20',
        '2026-10-04','2026-10-11','2026-10-18',
    ];
    foreach ($allVendorIds as $i => $vid) {
        $dates = array_slice($futureDates, $i % 4, 3);
        foreach ($dates as $j => $d) {
            $uid   = [$clientId,$auliaId,$dimasId,$sitiId][$j % 4];
            $stat  = $j === 0 ? 'confirmed' : ($j === 1 ? 'confirmed' : 'pending');
            $stmtVB->execute([$vid, $uid, $d, $stat, '']);
        }
    }

    // ── SEED: Dummy Reviews ───────────────────────────────────────────────────
    $reviews = [
        // vendor_id (index), user_id, rating, komentar
        [1,$clientId,5,'Sangat puas! Riasan tahan lama dari pagi hingga malam. Highly recommended!'],
        [1,$auliaId,5,'Sari Beauty memang terbaik. Hasilnya natural dan cantik sekali.'],
        [1,$dimasId,4,'Bagus, tapi datang agak telat. Overall memuaskan.'],
        [2,$sitiId,5,'Maharani Makeup luar biasa! Terlihat beda kelas.'],
        [2,$clientId,5,'Makeup bertahan 12 jam, sempurna untuk hari spesial kami.'],
        [3,$auliaId,4,'Cantik Studio oke, harga terjangkau dengan hasil yang baik.'],
        [4,$dimasId,5,'Arif Photography mengabadikan momen dengan sangat indah. Video cinematic!'],
        [4,$sitiId,5,'Setiap foto terasa bercerita. Tim sangat ramah dan profesional.'],
        [4,$clientId,5,'Best photographer di Padangsidimpuan! Booking jauh-jauh hari.'],
        [5,$auliaId,5,'Lentera Studio wow banget hasilnya. Worth every penny!'],
        [5,$dimasId,4,'Kualitas foto dan video sangat premium. Puas!'],
        [6,$sitiId,5,'Moment Capture berhasil menangkap momen natural yang kami inginkan.'],
        [7,$clientId,5,'Grand Ballroom Mahkota megah sekali. Tamu kami sangat terkesan.'],
        [7,$auliaId,5,'Fasilitas lengkap, AC dingin, parkir luas. Sempurna!'],
        [8,$dimasId,5,'Taman Sari Garden romantis banget untuk outdoor wedding kami.'],
        [9,$sitiId,4,'Griya Indah elegan dan strategis. Staff ramah.'],
        [10,$clientId,5,'Dapur Bunda cateringnya enak banget! Semua tamu puji masakannya.'],
        [10,$auliaId,5,'Menu lengkap dan penyajian rapi. Sangat profesional!'],
        [11,$dimasId,4,'Berkah Catering halal dan lezat. Porsi cukup.'],
        [12,$sitiId,5,'Royal Kitchen live cooking stationnya keren! Tamu suka banget.'],
        [13,$clientId,5,'Bunga & Karya dekorasinya cantik banget. Persis seperti yang kami impikan!'],
        [13,$auliaId,5,'Dekorasi pelaminan mewah dengan bunga segar. Luar biasa!'],
        [14,$dimasId,5,'Elegan Dekorasi minimalis modern, sangat instagramable!'],
        [15,$sitiId,4,'Mahkota Pelaminan bagus, tema adat sangat autentik.'],
        [16,$clientId,5,'Harmoni Band keren! Lagu daerah Batak dibawakan dengan sempurna.'],
        [17,$auliaId,5,'Melodi Indah Trio suasananya jadi romantic banget. Love it!'],
        [18,$dimasId,5,'Seruling Emas Orchestra wow! Tamu sangat terhibur.'],
        [19,$sitiId,5,'Rizky MC energiknya luar biasa! Acara jadi sangat meriah.'],
        [19,$clientId,5,'MC terbaik yang pernah kami lihat. Semua tamu terhibur!'],
        [20,$auliaId,5,'Dian Presenter elegannya pas banget untuk intimate wedding kami.'],
        [21,$dimasId,5,'Sinema Wedding hasilnya sinematik banget! Drone shotnya keren.'],
        [21,$sitiId,5,'Video wedding kami seperti film. Sangat puas!'],
        [22,$clientId,5,'Kenangan Visual gaya editnya modern dan emosional. Suka banget!'],
    ];

    $stmtVendorIds = $pdo->query("SELECT id FROM vendor ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
    $stmtR  = $pdo->prepare("INSERT OR IGNORE INTO vendor_review (id_vendor,id_user,rating,komentar) VALUES (?,?,?,?)");
    foreach ($reviews as $rv) {
        $vidx = $rv[0] - 1;
        if (isset($stmtVendorIds[$vidx])) {
            $stmtR->execute([$stmtVendorIds[$vidx], $rv[1], $rv[2], $rv[3]]);
        }
    }
    // Update rating dan total_review semua vendor
    $allVids = $pdo->query("SELECT id FROM vendor")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($allVids as $vid) {
        $row = $pdo->prepare("SELECT AVG(rating) as avg_r, COUNT(*) as cnt FROM vendor_review WHERE id_vendor=?");
        $row->execute([$vid]);
        $data = $row->fetch();
        if ($data['cnt'] > 0) {
            $pdo->prepare("UPDATE vendor SET rating=?, total_review=? WHERE id=?")->execute([round($data['avg_r'],1), $data['cnt'], $vid]);
        }
    }

    // ── SEED: Dummy Kontak ────────────────────────────────────────────────────
    $kontaks = [
        ['Hana Safitri','hana@email.com','081288881111','Saya ingin bertanya mengenai paket Gold Wedding untuk 250 tamu. Apakah bisa custom dekorasi tema vintage?',1],
        ['Irfan Maulana','irfan@email.com','081277772222','Kami berencana menikah Desember 2026. Apakah Royal Wedding masih tersedia? Berapa DP minimalnya?',1],
        ['Yesi Pratiwi','yesi@email.com','081266663333','Boleh minta info lengkap paket Intimate Wedding? Kami ingin acara yang simpel tapi berkesan.',0],
        ['Bagas Kurniawan','bagas@email.com','081255554444','Apakah vendor Arif Photography bisa di-booking untuk 2 hari (akad + resepsi)?',0],
    ];
    $stmtK = $pdo->prepare("INSERT OR IGNORE INTO kontak (nama,email,no_hp,pesan,is_read) VALUES (?,?,?,?,?)");
    foreach ($kontaks as $k) $stmtK->execute($k);
}
