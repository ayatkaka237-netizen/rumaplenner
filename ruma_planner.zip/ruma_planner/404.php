<?php require_once 'includes/koneksi.php'; require_once 'includes/session.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Halaman Tidak Ditemukan | Ruma Planner</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root { --maroon: #6B1B1B; --gold: #B8860B; }
        body { background: linear-gradient(135deg, #fff5f5 0%, #fff9f0 100%); min-height: 100vh; display: flex; align-items: center; }
        .error-number { font-size: 8rem; font-weight: 900; color: var(--maroon); opacity: 0.12; line-height: 1; position: absolute; top: 0; left: 50%; transform: translateX(-50%); }
        .error-icon { font-size: 5rem; color: var(--maroon); }
        .btn-primary-custom { background: var(--maroon); border: none; color: #fff; padding: .75rem 2rem; border-radius: 50px; font-weight: 600; text-decoration: none; display: inline-block; transition: .2s; }
        .btn-primary-custom:hover { background: #4a1212; color: #fff; transform: translateY(-2px); box-shadow: 0 6px 20px rgba(107,27,27,.3); }
        .btn-outline-custom { border: 2px solid var(--maroon); color: var(--maroon); padding: .7rem 2rem; border-radius: 50px; font-weight: 600; text-decoration: none; display: inline-block; transition: .2s; }
        .btn-outline-custom:hover { background: var(--maroon); color: #fff; }
        .card-link { background:#fff; border-radius:16px; padding:1.5rem; text-decoration:none; color:inherit; border:1.5px solid #f0e0e0; transition:.2s; display:block; }
        .card-link:hover { border-color:var(--maroon); transform:translateY(-3px); box-shadow:0 8px 24px rgba(107,27,27,.1); }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-7 col-md-9 text-center">
            <div class="position-relative mb-4" style="height:120px;">
                <div class="error-number">404</div>
                <div class="d-flex align-items-center justify-content-center h-100">
                    <i class="bi bi-map error-icon"></i>
                </div>
            </div>
            <h1 class="fw-bold mb-2" style="color:var(--maroon)">Halaman Tidak Ditemukan</h1>
            <p class="text-muted mb-5 fs-5">Sepertinya halaman yang kamu cari sudah dipindahkan,<br>dihapus, atau memang tidak pernah ada.</p>

            <div class="d-flex gap-3 justify-content-center flex-wrap mb-5">
                <a href="<?= BASE_URL ?>" class="btn-primary-custom"><i class="bi bi-house-heart me-2"></i>Ke Beranda</a>
                <a href="javascript:history.back()" class="btn-outline-custom"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
            </div>

            <p class="text-muted small mb-3 fw-semibold text-uppercase" style="letter-spacing:.1em">Atau mungkin kamu mencari ini?</p>
            <div class="row g-3 text-start">
                <div class="col-sm-6">
                    <a href="<?= BASE_URL ?>paket" class="card-link">
                        <div class="d-flex align-items-center gap-3">
                            <div style="width:44px;height:44px;background:#fff5f5;border-radius:12px;display:flex;align-items:center;justify-content:center;">
                                <i class="bi bi-box-heart-fill" style="color:var(--maroon);font-size:1.3rem;"></i>
                            </div>
                            <div>
                                <div class="fw-semibold" style="color:var(--maroon)">Paket Pernikahan</div>
                                <div class="small text-muted">Lihat pilihan paket kami</div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm-6">
                    <a href="<?= BASE_URL ?>vendor" class="card-link">
                        <div class="d-flex align-items-center gap-3">
                            <div style="width:44px;height:44px;background:#fff5f5;border-radius:12px;display:flex;align-items:center;justify-content:center;">
                                <i class="bi bi-shop" style="color:var(--maroon);font-size:1.3rem;"></i>
                            </div>
                            <div>
                                <div class="fw-semibold" style="color:var(--maroon)">Marketplace Vendor</div>
                                <div class="small text-muted">Temukan vendor terbaik</div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm-6">
                    <a href="<?= BASE_URL ?>kontak" class="card-link">
                        <div class="d-flex align-items-center gap-3">
                            <div style="width:44px;height:44px;background:#fff5f5;border-radius:12px;display:flex;align-items:center;justify-content:center;">
                                <i class="bi bi-chat-heart" style="color:var(--maroon);font-size:1.3rem;"></i>
                            </div>
                            <div>
                                <div class="fw-semibold" style="color:var(--maroon)">Hubungi Kami</div>
                                <div class="small text-muted">Ada pertanyaan? Chat kami</div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm-6">
                    <a href="<?= BASE_URL ?>login" class="card-link">
                        <div class="d-flex align-items-center gap-3">
                            <div style="width:44px;height:44px;background:#fff5f5;border-radius:12px;display:flex;align-items:center;justify-content:center;">
                                <i class="bi bi-person-heart" style="color:var(--maroon);font-size:1.3rem;"></i>
                            </div>
                            <div>
                                <div class="fw-semibold" style="color:var(--maroon)">Masuk / Daftar</div>
                                <div class="small text-muted">Login ke akun kamu</div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

            <p class="mt-5 text-muted small">
                <i class="bi bi-heart-fill text-danger"></i>
                <a href="<?= BASE_URL ?>" style="color:var(--maroon);text-decoration:none;font-weight:600;">Ruma Planner</a>
                &mdash; From Dream, to a Moment
            </p>
        </div>
    </div>
</div>
</body>
</html>
