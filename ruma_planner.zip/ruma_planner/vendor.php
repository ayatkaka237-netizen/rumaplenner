<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

$kategori_slug = trim($_GET['kategori'] ?? '');
$search        = trim($_GET['q'] ?? '');
$sort          = trim($_GET['sort'] ?? 'rating');
$harga_min     = (int)($_GET['harga_min'] ?? 0);
$harga_max     = (int)($_GET['harga_max'] ?? 0);

// Ambil semua kategori
$kategoris = $pdo->query("SELECT * FROM vendor_kategori ORDER BY urutan")->fetchAll();

// Build query
$params = [];
$where  = "WHERE v.is_active=1";

if ($kategori_slug) {
    $where .= " AND vk.slug=?";
    $params[] = $kategori_slug;
}
if ($search) {
    $where .= " AND (v.nama LIKE ? OR v.deskripsi LIKE ? OR v.lokasi LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($harga_min > 0) {
    $where .= " AND v.harga_mulai >= ?";
    $params[] = $harga_min;
}
if ($harga_max > 0) {
    $where .= " AND v.harga_mulai <= ?";
    $params[] = $harga_max;
}

$order = match($sort) {
    'harga_asc'    => 'ORDER BY v.harga_mulai ASC',
    'harga_desc'   => 'ORDER BY v.harga_mulai DESC',
    'nama'         => 'ORDER BY v.nama ASC',
    'most_booked'  => 'ORDER BY v.total_booking DESC',
    default        => 'ORDER BY v.rating DESC, v.total_review DESC',
};

$stmt = $pdo->prepare("
    SELECT v.*, vk.nama AS nama_kategori, vk.slug AS kategori_slug, vk.icon AS kategori_icon
    FROM vendor v
    JOIN vendor_kategori vk ON v.id_kategori = vk.id
    $where $order
");
$stmt->execute($params);
$vendors = $stmt->fetchAll();

// Wishlist user
$wishlistIds = [];
if (isLoggedIn()) {
    $wl = $pdo->prepare("SELECT id_vendor FROM vendor_wishlist WHERE id_user=?");
    $wl->execute([$_SESSION['user_id']]);
    $wishlistIds = $wl->fetchAll(PDO::FETCH_COLUMN);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Wedding — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <style>
    .vendor-card {
        background: #fff;
        border-radius: var(--radius-lg);
        overflow: hidden;
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        border: 1px solid rgba(105,27,27,0.07);
        position: relative;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .vendor-card:hover {
        transform: translateY(-6px);
        box-shadow: var(--shadow-lg);
    }
    .vendor-card-img {
        height: 200px;
        background: linear-gradient(135deg, var(--maroon-dark), var(--maroon-light));
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }
    .vendor-card-img i { font-size: 4rem; color: rgba(255,255,255,0.3); }
    .vendor-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        padding: 4px 12px;
        border-radius: 50px;
        font-size: 0.7rem;
        font-weight: 600;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }
    .badge-best    { background: var(--gold); color: #fff; }
    .badge-trending{ background: #17a2b8; color: #fff; }
    .badge-most    { background: #6f42c1; color: #fff; }
    .vendor-wishlist-btn {
        position: absolute;
        top: 12px;
        right: 12px;
        width: 36px; height: 36px;
        background: rgba(255,255,255,0.9);
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer;
        border: none;
        transition: var(--transition);
        font-size: 1.1rem;
        color: #ccc;
    }
    .vendor-wishlist-btn:hover, .vendor-wishlist-btn.active { color: #e74c3c; }
    .vendor-card-body {
        padding: 20px;
        flex: 1;
        display: flex;
        flex-direction: column;
    }
    .vendor-kategori-tag {
        font-size: 0.72rem;
        color: var(--maroon);
        text-transform: uppercase;
        letter-spacing: 1px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 5px;
        margin-bottom: 6px;
    }
    .vendor-name { font-family: var(--font-display); font-size: 1.2rem; color: var(--text-dark); margin-bottom: 4px; font-weight: 600; }
    .vendor-rating { display: flex; align-items: center; gap: 6px; margin-bottom: 10px; }
    .stars { color: var(--gold); font-size: 0.85rem; }
    .vendor-desc { font-size: 0.83rem; color: #666; line-height: 1.6; flex: 1; margin-bottom: 14px;
        display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
    .vendor-harga { font-family: var(--font-display); font-size: 1.3rem; color: var(--maroon); font-weight: 700; }
    .vendor-harga small { font-size: 0.7rem; color: #999; font-family: var(--font-body); }
    .availability-badge {
        display: inline-flex; align-items: center; gap: 5px;
        padding: 4px 10px; border-radius: 50px; font-size: 0.72rem; font-weight: 600;
    }
    .avail-green { background: #d4edda; color: #155724; }
    .avail-red   { background: #f8d7da; color: #721c24; }
    .avail-yellow{ background: #fff3cd; color: #856404; }
    .filter-sidebar {
        background: #fff; border-radius: var(--radius-lg);
        padding: 28px; box-shadow: var(--shadow-sm);
        border: 1px solid rgba(105,27,27,0.07);
    }
    .kategori-pill {
        display: flex; align-items: center; gap: 8px;
        padding: 10px 16px; border-radius: 50px;
        border: 2px solid rgba(105,27,27,0.12);
        background: #fff; cursor: pointer; text-decoration: none;
        color: var(--text-dark); font-size: 0.85rem;
        transition: var(--transition); margin-bottom: 8px; width: 100%;
    }
    .kategori-pill:hover, .kategori-pill.active {
        border-color: var(--maroon); background: var(--maroon-pale); color: var(--maroon); font-weight: 600;
    }
    .kategori-pill i { font-size: 1rem; color: var(--maroon); }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <nav aria-label="breadcrumb" class="mb-3">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Beranda</a></li>
                <li class="breadcrumb-item active">Vendor Wedding</li>
            </ol>
        </nav>
        <h1>Direktori Vendor</h1>
        <p style="color:rgba(255,255,255,0.75);">Temukan vendor terbaik untuk pernikahan impian Anda</p>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <!-- Search bar -->
        <div class="form-card mb-4" style="padding:20px 28px;">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-5">
                    <label class="form-label fw-semibold">Cari Vendor</label>
                    <div class="input-group">
                        <span class="input-group-text" style="background:var(--maroon-pale);border-color:rgba(105,27,27,0.2);">
                            <i class="bi bi-search" style="color:var(--maroon);"></i>
                        </span>
                        <input type="text" name="q" class="form-control" placeholder="Cari nama vendor, kategori..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Harga Min</label>
                    <select name="harga_min" class="form-select">
                        <option value="">Semua</option>
                        <option value="500000" <?= $harga_min==500000?'selected':'' ?>>Rp 500rb+</option>
                        <option value="1000000" <?= $harga_min==1000000?'selected':'' ?>>Rp 1jt+</option>
                        <option value="3000000" <?= $harga_min==3000000?'selected':'' ?>>Rp 3jt+</option>
                        <option value="5000000" <?= $harga_min==5000000?'selected':'' ?>>Rp 5jt+</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Harga Max</label>
                    <select name="harga_max" class="form-select">
                        <option value="">Semua</option>
                        <option value="1500000" <?= $harga_max==1500000?'selected':'' ?>>s.d. Rp 1,5jt</option>
                        <option value="3000000" <?= $harga_max==3000000?'selected':'' ?>>s.d. Rp 3jt</option>
                        <option value="5000000" <?= $harga_max==5000000?'selected':'' ?>>s.d. Rp 5jt</option>
                        <option value="10000000" <?= $harga_max==10000000?'selected':'' ?>>s.d. Rp 10jt</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Urutkan</label>
                    <select name="sort" class="form-select">
                        <option value="rating" <?= $sort=='rating'?'selected':'' ?>>Rating Tertinggi</option>
                        <option value="most_booked" <?= $sort=='most_booked'?'selected':'' ?>>Paling Banyak Dipesan</option>
                        <option value="harga_asc" <?= $sort=='harga_asc'?'selected':'' ?>>Harga Terendah</option>
                        <option value="harga_desc" <?= $sort=='harga_desc'?'selected':'' ?>>Harga Tertinggi</option>
                        <option value="nama" <?= $sort=='nama'?'selected':'' ?>>Nama A-Z</option>
                    </select>
                </div>
                <div class="col-md-1">
                    <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategori_slug) ?>">
                    <button type="submit" class="btn btn-maroon w-100"><i class="bi bi-search"></i></button>
                </div>
            </form>
        </div>

        <div class="row g-4">
            <!-- Sidebar Kategori -->
            <div class="col-lg-3">
                <div class="filter-sidebar sticky-top" style="top:90px;">
                    <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:18px;">
                        <i class="bi bi-grid me-2"></i>Kategori Vendor
                    </h5>
                    <a href="vendor.php?sort=<?= $sort ?>&q=<?= urlencode($search) ?>"
                       class="kategori-pill <?= !$kategori_slug ? 'active' : '' ?>">
                        <i class="bi bi-grid-3x3-gap"></i> Semua Kategori
                    </a>
                    <?php foreach ($kategoris as $kat): ?>
                    <a href="vendor.php?kategori=<?= $kat['slug'] ?>&sort=<?= $sort ?>&q=<?= urlencode($search) ?>"
                       class="kategori-pill <?= $kategori_slug == $kat['slug'] ? 'active' : '' ?>">
                        <i class="bi <?= $kat['icon'] ?>"></i> <?= htmlspecialchars($kat['nama']) ?>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Vendor Grid -->
            <div class="col-lg-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h5 class="mb-0" style="font-family:var(--font-display);color:var(--maroon);">
                            <?= $kategori_slug ? htmlspecialchars(array_column($kategoris,'nama','slug')[$kategori_slug] ?? 'Vendor') : 'Semua Vendor' ?>
                        </h5>
                        <small class="text-muted"><?= count($vendors) ?> vendor ditemukan</small>
                    </div>
                    <?php if ($search || $kategori_slug): ?>
                    <a href="vendor.php" class="btn btn-sm btn-outline-maroon">
                        <i class="bi bi-x me-1"></i>Reset Filter
                    </a>
                    <?php endif; ?>
                </div>

                <?php if (empty($vendors)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-search" style="font-size:4rem;color:#ddd;"></i>
                    <h5 class="mt-3 text-muted">Vendor tidak ditemukan</h5>
                    <p class="text-muted">Coba ubah filter pencarian Anda</p>
                </div>
                <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($vendors as $v): ?>
                    <div class="col-md-6 col-xl-4">
                        <div class="vendor-card">
                            <!-- Image -->
                            <div class="vendor-card-img">
                                <i class="bi <?= htmlspecialchars($v['kategori_icon']) ?>"></i>
                                <!-- Badge -->
                                <?php if ($v['badge']): ?>
                                <span class="vendor-badge <?=
                                    $v['badge']=='Best Vendor' ? 'badge-best' :
                                    ($v['badge']=='Trending' ? 'badge-trending' : 'badge-most') ?>">
                                    <i class="bi <?= $v['badge']=='Best Vendor'?'bi-award':'bi-fire' ?> me-1"></i>
                                    <?= htmlspecialchars($v['badge']) ?>
                                </span>
                                <?php endif; ?>
                                <!-- Wishlist -->
                                <button class="vendor-wishlist-btn <?= in_array($v['id'], $wishlistIds) ? 'active' : '' ?>"
                                        onclick="toggleWishlist(<?= $v['id'] ?>, this)"
                                        title="<?= in_array($v['id'], $wishlistIds) ? 'Hapus dari wishlist' : 'Tambah ke wishlist' ?>">
                                    <i class="bi <?= in_array($v['id'], $wishlistIds) ? 'bi-heart-fill' : 'bi-heart' ?>"></i>
                                </button>
                            </div>
                            <!-- Body -->
                            <div class="vendor-card-body">
                                <div class="vendor-kategori-tag">
                                    <i class="bi <?= htmlspecialchars($v['kategori_icon']) ?>"></i>
                                    <?= htmlspecialchars($v['nama_kategori']) ?>
                                </div>
                                <div class="vendor-name"><?= htmlspecialchars($v['nama']) ?></div>
                                <div class="vendor-rating">
                                    <span class="stars">
                                        <?php for ($i=1;$i<=5;$i++) echo $i<=$v['rating']?'★':'☆'; ?>
                                    </span>
                                    <small style="color:#888;"><?= number_format($v['rating'],1) ?> (<?= $v['total_review'] ?> ulasan)</small>
                                </div>
                                <p class="vendor-desc"><?= htmlspecialchars($v['deskripsi']) ?></p>
                                <div class="d-flex justify-content-between align-items-end mt-auto">
                                    <div>
                                        <div class="vendor-harga">
                                            <?= formatRupiah($v['harga_mulai']) ?>
                                            <small><?= htmlspecialchars($v['harga_satuan']) ?></small>
                                        </div>
                                        <small style="color:#888;font-size:0.72rem;">
                                            <i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($v['lokasi']) ?>
                                        </small>
                                    </div>
                                    <span class="availability-badge avail-green" id="avail-<?= $v['id'] ?>">
                                        <i class="bi bi-circle-fill" style="font-size:0.5rem;"></i> Tersedia
                                    </span>
                                </div>
                                <div class="d-grid gap-2 mt-3">
                                    <a href="vendor-detail.php?id=<?= $v['id'] ?>" class="btn btn-maroon btn-sm">
                                        <i class="bi bi-eye me-1"></i>Lihat Detail & Kalender
                                    </a>
                                    <a href="https://wa.me/<?= preg_replace('/[^0-9]/','',$v['no_wa']) ?>?text=<?= urlencode('Halo, saya ingin bertanya mengenai layanan ' . $v['nama'] . ' dari Ruma Planner.') ?>"
                                       target="_blank" class="btn btn-outline-maroon btn-sm">
                                        <i class="bi bi-whatsapp me-1"></i>Chat Vendor
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

<!-- Floating WhatsApp -->
<a href="https://wa.me/6281234567890?text=<?= urlencode('Halo, saya ingin bertanya mengenai paket wedding Ruma Planner.') ?>"
   target="_blank" class="wa-float" title="Chat Admin Ruma Planner">
    <i class="bi bi-whatsapp"></i>
</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
function toggleWishlist(vendorId, btn) {
    fetch('api/wishlist.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({vendor_id: vendorId})
    })
    .then(r => r.json())
    .then(data => {
        if (data.login_required) {
            window.location.href = '<?= BASE_URL ?>login.php';
            return;
        }
        const icon = btn.querySelector('i');
        if (data.action === 'added') {
            btn.classList.add('active');
            icon.className = 'bi bi-heart-fill';
        } else {
            btn.classList.remove('active');
            icon.className = 'bi bi-heart';
        }
    });
}
</script>
</body>
</html>
